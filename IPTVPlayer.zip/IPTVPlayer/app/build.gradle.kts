plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "pt.iptv.player"
    compileSdk = 35
    defaultConfig {
        applicationId = "pt.iptv.player"
        minSdk = 21
        targetSdk = 35
        versionCode = 58
        versionName = "9.1"
    }
    // Chave de assinatura: vem dos Secrets do GitHub (nunca fica no repositório)
    signingConfigs {
        create("eco") {
            storeFile = file(System.getenv("ECO_KEYSTORE_FILE") ?: "eco.keystore")
            storePassword = System.getenv("ECO_KS_PASS") ?: ""
            keyAlias = "eco"
            keyPassword = System.getenv("ECO_KS_PASS") ?: ""
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("eco")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    val media3 = "1.5.1"
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("io.coil-kt:coil:2.7.0")   // capas de filmes e séries
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.conscrypt:conscrypt-android:2.5.2")   // https em Androids antigos
}
