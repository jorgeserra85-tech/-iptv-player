package pt.iptv.player

/** Campo de texto: o teclado só abre ao carregar em OK (evita teclados de box que falham ao abrir sozinhos). */
fun android.widget.EditText.keyboardOnlyOnOk() {
    showSoftInputOnFocus = false
    val open = {
        requestFocus()
        post {
            try {
                (context.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .showSoftInput(this, 0)
            } catch (_: Exception) {}
        }
    }
    setOnClickListener { open() }
    setOnKeyListener { _, code, e ->
        if (code == android.view.KeyEvent.KEYCODE_DPAD_CENTER || code == android.view.KeyEvent.KEYCODE_ENTER) {
            if (e.action == android.view.KeyEvent.ACTION_UP) open(); true
        } else false
    }
}
