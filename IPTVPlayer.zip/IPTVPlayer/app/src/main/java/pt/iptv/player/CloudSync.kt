package pt.iptv.player

import android.content.Context
import org.json.JSONArray

/** Liga favoritos e "continuar a ver" à conta (Supabase), para seguirem entre aparelhos. */
object CloudSync {
    private fun prefs(c: Context) = c.getSharedPreferences("cloudsync", Context.MODE_PRIVATE)
    private val FAV_KINDS = listOf("live", "vod", "series")
    private fun syncedKey(kind: String) = "fav_${kind}_${Session.providerId}_${Session.user}"

    /** Puxa o estado da conta e junta ao local. Depois envia o "continuar" juntado de volta. Corre em thread. */
    fun pull(c: Context) {
        val pid = Session.providerId; val user = Session.user
        if (pid <= 0 || user.isEmpty()) return
        Thread {
            try {
                val remote = Api.cloudGet(pid, user)
                // Favoritos: por kind, a escrita mais recente ganha
                for (k in FAV_KINDS) {
                    val r = remote["fav_$k"] ?: continue
                    if (r.second > prefs(c).getLong(syncedKey(k), 0L)) {
                        Favs.replace(c, k, jsonToSet(r.first))
                        prefs(c).edit().putLong(syncedKey(k), r.second).apply()
                    }
                }
                // Continuar a ver: junta por chave (a mais recente ganha)
                remote["resume"]?.let { Resume.mergeFrom(c, it.first) }
                pushResume(c)        // devolve a união ao servidor
            } catch (_: Exception) {}
        }.start()
    }

    fun pushFavs(c: Context, kind: String) {
        val pid = Session.providerId; val user = Session.user
        if (pid <= 0 || user.isEmpty()) return
        Thread {
            try {
                val json = JSONArray(Favs.all(c, kind).toList()).toString()
                val ms = Api.cloudSet(pid, user, "fav_$kind", json)
                if (ms > 0) prefs(c).edit().putLong(syncedKey(kind), ms).apply()
            } catch (_: Exception) {}
        }.start()
    }

    fun pushResume(c: Context) {
        val pid = Session.providerId; val user = Session.user
        if (pid <= 0 || user.isEmpty()) return
        Thread { try { Api.cloudSet(pid, user, "resume", Resume.accountBlob(c)) } catch (_: Exception) {} }.start()
    }

    private fun jsonToSet(s: String): Set<String> = try {
        val a = JSONArray(s); (0 until a.length()).map { a.getString(it) }.toSet()
    } catch (_: Exception) { emptySet() }
}
