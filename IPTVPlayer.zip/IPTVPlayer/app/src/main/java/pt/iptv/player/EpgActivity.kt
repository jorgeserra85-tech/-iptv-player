package pt.iptv.player

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/** Guia de programação de um canal, com acesso às gravações (catch-up). */
class EpgActivity : AppCompatActivity() {
    companion object {
        var channel: Channel? = null
        var channelIndex = 0
    }

    private var items: List<Programme> = emptyList()
    private val now get() = System.currentTimeMillis() / 1000
    private val dayFmt = SimpleDateFormat("EEE dd/MM", Locale("pt", "PT"))
    private val hourFmt = SimpleDateFormat("HH:mm", Locale("pt", "PT"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ch: Channel = channel ?: run { finish(); return }
        val sid: String = ch.streamId ?: run { finish(); return }
        setContentView(R.layout.activity_epg)
        findViewById<TextView>(R.id.title).text = ch.name
        findViewById<TextView>(R.id.sub).text =
            if (ch.archive) "Com gravações automáticas" + (if (ch.archiveDays > 0) " (${ch.archiveDays} dias)" else "")
            else "Sem gravações neste canal"
        findViewById<Button>(R.id.backBtn).setOnClickListener { finish() }
        findViewById<Button>(R.id.liveBtn).setOnClickListener { playLive() }

        val status = findViewById<TextView>(R.id.status)
        val list = findViewById<ListView>(R.id.epgList)
        val adapter = EpgAdapter(ch)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onProgramme(ch, items[pos]) }

        lifecycleScope.launch {
            val all = withContext(Dispatchers.IO) { Api.epg(sid) }
            val days = if (ch.archiveDays > 0) ch.archiveDays else 7
            val from = if (ch.archive) now - days * 86400L else now - 3 * 3600L
            items = all.filter { it.end > from }
            adapter.notifyDataSetChanged()
            if (items.isEmpty()) {
                status.text = "Este canal não tem guia de programação."
            } else {
                status.text = if (ch.archive) "Toque num programa passado para ver a gravação." else "Programação"
                val cur = items.indexOfFirst { it.start <= now && it.end > now }
                if (cur >= 0) list.setSelection((cur - 1).coerceAtLeast(0))
            }
        }
    }

    private fun canWatch(ch: Channel, p: Programme): Boolean {
        if (p.end > now) return false
        if (p.hasArchive) return true
        val days = if (ch.archiveDays > 0) ch.archiveDays else 7
        return ch.archive && p.start > now - days * 86400L
    }

    private fun playLive() {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", channelIndex))
    }

    private fun onProgramme(ch: Channel, p: Programme) {
        when {
            p.start <= now && p.end > now -> playLive()
            canWatch(ch, p) -> startActivity(Intent(this, PlayerActivity::class.java)
                .putStringArrayListExtra("urls", ArrayList(Api.catchupUrls(ch.streamId!!, p)))
                .putExtra("title", "${ch.name} · ${p.title}")
                .putExtra("sub", "Gravação de ${dayFmt.format(Date(p.start * 1000))} às ${hourFmt.format(Date(p.start * 1000))}"))
            p.start > now -> Toast.makeText(this, "Este programa ainda não começou", Toast.LENGTH_SHORT).show()
            else -> Toast.makeText(this, "Este programa não tem gravação", Toast.LENGTH_SHORT).show()
        }
    }

    inner class EpgAdapter(private val ch: Channel) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(pos: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: layoutInflater.inflate(R.layout.item_epg, parent, false)
            val p = items[pos]
            val s = Date(p.start * 1000); val e = Date(p.end * 1000)
            v.findViewById<TextView>(R.id.time).text = "${dayFmt.format(s)} · ${hourFmt.format(s)}–${hourFmt.format(e)}"
            v.findViewById<TextView>(R.id.ptitle).text = p.title
            val d = v.findViewById<TextView>(R.id.pdesc)
            d.text = p.desc; d.visibility = if (p.desc.isBlank()) View.GONE else View.VISIBLE
            val tag = v.findViewById<TextView>(R.id.tag)
            val live = p.start <= now && p.end > now
            when {
                live -> { tag.text = "AO VIVO"; tag.setTextColor(Color.parseColor("#FF6B6B")); tag.visibility = View.VISIBLE }
                canWatch(ch, p) -> { tag.text = "▶ GRAVAÇÃO"; tag.setTextColor(Color.parseColor("#3DDC97")); tag.visibility = View.VISIBLE }
                else -> tag.visibility = View.GONE
            }
            v.alpha = if (p.end <= now && !canWatch(ch, p)) 0.55f else 1f
            return v
        }
    }
}
