package pt.iptv.player

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Guia TV: o que está a dar agora e a seguir em todos os canais da lista. */
class NowNextActivity : AppCompatActivity() {
    companion object { var channels: List<Channel> = emptyList(); var groupName = "" }

    private val info = HashMap<String, Pair<Programme?, Programme?>>()
    private val loading = HashSet<String>()
    private val sem = Semaphore(4)
    private val hm = SimpleDateFormat("HH:mm", Locale.getDefault())
    private lateinit var list: ListView
    private lateinit var adapter: BaseAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (channels.isEmpty() || !Store.restoreSession(this)) { finish(); return }
        setContentView(R.layout.activity_nownext)
        findViewById<Button>(R.id.backBtn).setOnClickListener { finish() }
        if (groupName.isNotBlank()) findViewById<TextView>(R.id.title).text = "📅 Guia TV · $groupName"
        list = findViewById(R.id.list)
        adapter = Adapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> play(pos) }
        list.setOnItemLongClickListener { _, _, pos, _ -> fullGuide(pos); true }
        list.requestFocus()
    }

    private fun play(pos: Int) {
        val go = {
            MainActivity.playlist = channels
            startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", pos))
        }
        if (Parental.channelLocked(channels[pos])) Parental.ask(this) { go() } else go()
    }

    private fun fullGuide(pos: Int) {
        val ch = channels[pos]
        if (ch.streamId == null) return
        val go = {
            MainActivity.playlist = channels
            EpgActivity.channel = ch; EpgActivity.channelIndex = pos
            startActivity(Intent(this, EpgActivity::class.java))
        }
        if (Parental.channelLocked(ch)) Parental.ask(this) { go() } else go()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (e.action == KeyEvent.ACTION_UP && list.selectedItemPosition >= 0) fullGuide(list.selectedItemPosition)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> { if (e.action == KeyEvent.ACTION_UP) finish(); return true }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun load(ch: Channel) {
        val sid = ch.streamId ?: return
        if (sid in info || !loading.add(sid)) return
        lifecycleScope.launch {
            val r = sem.withPermit { withContext(Dispatchers.IO) { Api.nowNext(sid) } }
            info[sid] = r; loading.remove(sid)
            adapter.notifyDataSetChanged()
        }
    }

    inner class Adapter : BaseAdapter() {
        override fun getCount() = channels.size
        override fun getItem(p: Int) = channels[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: layoutInflater.inflate(R.layout.item_nownext, parent, false)
            val ch = channels[p]
            val locked = Parental.channelLocked(ch)
            v.findViewById<TextView>(R.id.name).text = (if (locked) "🔒 " else "") + "${p + 1}. ${ch.name}"
            v.findViewById<ImageView>(R.id.logo).load(ch.logo)
            val nowV = v.findViewById<TextView>(R.id.now)
            val nextV = v.findViewById<TextView>(R.id.next)
            val bar = v.findViewById<ProgressBar>(R.id.bar)
            val sid = ch.streamId
            val r = sid?.let { info[it] }
            when {
                sid == null -> { nowV.text = "Sem guia"; nextV.text = ""; bar.visibility = View.INVISIBLE }
                r == null -> { nowV.text = "A carregar…"; nextV.text = ""; bar.visibility = View.INVISIBLE; load(ch) }
                else -> {
                    val (cur, next) = r
                    if (cur != null) {
                        nowV.text = "Agora: ${cur.title}  (${hm.format(Date(cur.start * 1000))}–${hm.format(Date(cur.end * 1000))})"
                        val now = System.currentTimeMillis() / 1000
                        bar.progress = (((now - cur.start) * 100) / (cur.end - cur.start).coerceAtLeast(1)).toInt()
                        bar.visibility = View.VISIBLE
                    } else { nowV.text = "Agora: sem informação"; bar.visibility = View.INVISIBLE }
                    nextV.text = next?.let { "A seguir: ${it.title}  (${hm.format(Date(it.start * 1000))})" } ?: ""
                }
            }
            return v
        }
    }
}
