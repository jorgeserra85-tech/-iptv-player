package pt.iptv.player

import android.content.Context
import org.conscrypt.Conscrypt
import java.io.ByteArrayInputStream
import java.security.KeyStore
import java.security.Security
import java.security.cert.CertificateException
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * Ligações https em aparelhos antigos (ex.: boxes com Android 6):
 * - Conscrypt traz TLS e cifras modernas;
 * - uma lista de certificados atualizada (Mozilla) complementa a do sistema, que está desatualizada.
 */
object Tls {
    var trustManager: X509TrustManager? = null
    var socketFactory: SSLSocketFactory? = null

    fun install(c: Context) {
        try { Security.insertProviderAt(Conscrypt.newProvider(), 1) } catch (_: Throwable) {}
        try {
            val system = trustManagerFor(null)
            val ks = KeyStore.getInstance(KeyStore.getDefaultType()).apply { load(null, null) }
            val cf = CertificateFactory.getInstance("X.509")
            val pem = c.resources.openRawResource(R.raw.cacerts).bufferedReader().use { it.readText() }
            Regex("-----BEGIN CERTIFICATE-----[\\s\\S]+?-----END CERTIFICATE-----").findAll(pem)
                .forEachIndexed { i, m ->
                    try {
                        ks.setCertificateEntry("eco$i", cf.generateCertificate(ByteArrayInputStream(m.value.toByteArray())))
                    } catch (_: Exception) {}
                }
            val bundled = trustManagerFor(ks)
            val tm = object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) =
                    system.checkClientTrusted(chain, authType)
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                    try { system.checkServerTrusted(chain, authType) }
                    catch (e: CertificateException) { bundled.checkServerTrusted(chain, authType) }
                }
                override fun getAcceptedIssuers(): Array<X509Certificate> = system.acceptedIssuers + bundled.acceptedIssuers
            }
            val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf(tm), null) }
            trustManager = tm
            socketFactory = ctx.socketFactory
            HttpsURLConnection.setDefaultSSLSocketFactory(ctx.socketFactory)   // usado pela app e pelo leitor
        } catch (_: Throwable) {}
    }

    private fun trustManagerFor(ks: KeyStore?): X509TrustManager {
        val f = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        f.init(ks)
        return f.trustManagers.filterIsInstance<X509TrustManager>().first()
    }
}
