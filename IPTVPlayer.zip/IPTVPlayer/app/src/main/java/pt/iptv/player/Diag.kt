package pt.iptv.player

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Histórico de diagnóstico da app, enviado ao painel para dar apoio sem ver o ecrã. */
object Diag {
    private const val MAX = 15
    private lateinit var app: Context

    fun init(c: Context) { app = c.applicationContext }

    private fun prefs() = app.getSharedPreferences("diag", Context.MODE_PRIVATE)

    private fun add(type: String, text: String) {
        if (!::app.isInitialized) return
        val arr = events()
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("k", type).put("m", text.take(160)))
        while (arr.length() > MAX) arr.remove(0)
        prefs().edit().putString("events", arr.toString()).apply()
    }

    private fun events(): JSONArray = try { JSONArray(prefs().getString("events", "[]")) } catch (e: Exception) { JSONArray() }

    /** Erro de reprodução. */
    fun error(text: String) { add("erro", text); Presence.report(error = text) }

    /** Canal abriu em [ms] milissegundos. */
    fun opened(channel: String, ms: Long) { add("abriu", "$channel em ${ms / 1000.0}s") }

    /** Tudo o que a app sabe agora (para o relatório). */
    fun snapshot(): String = JSONObject()
        .put("events", events())
        .put("fmt", app.getSharedPreferences("last", Context.MODE_PRIVATE).getString("fmt_${Session.providerId}", "?"))
        .toString()
}
