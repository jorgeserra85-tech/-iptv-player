package pt.iptv.player

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageView

/** Imagem com formato de capa de filme (altura = 1,5 × largura) e cantos arredondados. */
class PosterView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : AppCompatImageView(c, a) {
    init { clipToOutline = true }
    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        super.onMeasure(widthSpec, heightSpec)
        val w = measuredWidth
        setMeasuredDimension(w, (w * 1.5f).toInt())
    }
}
