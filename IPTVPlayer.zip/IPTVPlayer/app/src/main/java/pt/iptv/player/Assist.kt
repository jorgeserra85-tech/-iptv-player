package pt.iptv.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Assistência à distância: executa os pedidos feitos no painel para este aparelho. */
object Assist {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var busy = false

    fun rpc(fn: String, body: String): String? = try {
        val c = URL("${Config.SUPABASE_URL}/rest/v1/rpc/$fn").openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("apikey", Config.SUPABASE_KEY)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val t = if (code in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
        c.disconnect(); t
    } catch (e: Exception) { null }

    /** Vai buscar os pedidos pendentes (chamado a cada 15 s com a app aberta). */
    fun poll(c: Context) {
        if (busy) return
        busy = true
        Thread {
            try {
                val txt = rpc("device_commands_take", JSONObject().put("p_device", Presence.deviceId()).toString())
                val arr = try { JSONArray(txt ?: "[]") } catch (e: Exception) { JSONArray() }
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val cmd = o.optString("command")
                    val p = o.optJSONObject("payload") ?: JSONObject()
                    main.post { run(c, cmd, p) }
                }
            } finally { busy = false }
        }.start()
    }

    private fun current(): Activity? = SleepTimer.current?.get()?.takeIf { !it.isFinishing }

    private fun notice(text: String) {
        val a = current() ?: return
        Toast.makeText(a, "🛠 Assistência do fornecedor: $text", Toast.LENGTH_LONG).show()
    }

    private fun run(c: Context, cmd: String, p: JSONObject) {
        when (cmd) {
            "play_channel" -> playChannel(c, p.optString("key"), p.optString("name"))
            "switch_profile" -> switchProfile(c, p.optLong("pid"), p.optString("user"), p.optString("name"))
            "reload" -> { notice("a atualizar a lista de canais"); reload(c) }
            "update" -> { notice("a atualizar a app"); current()?.let { Updater.manual(it) } }
            "clear_pin" -> { Parental.clearPin(c); notice("PIN de adultos apagado. Na próxima vez crie um novo.") }
            "speed" -> { notice("a testar a velocidade da internet"); speedTest() }
            "report" -> { Presence.report(diag = Diag.snapshot()); speedTest(silent = true) }
            "message" -> current()?.let {
                AlertDialog.Builder(it).setTitle("📣 Mensagem do fornecedor")
                    .setMessage(p.optString("text")).setPositiveButton("OK", null).show()
            }
        }
    }

    private fun playChannel(c: Context, key: String, name: String) {
        if (MainActivity.channelsToShow.isEmpty() && Store.restoreSession(c))
            MainActivity.channelsToShow = Store.loadChannels(c, Session.providerId, Session.user) ?: emptyList()
        val ch = MainActivity.channelsToShow.filter { !it.custom }.firstOrNull { Api.channelKey(it) == key }
        if (ch == null) { notice("o canal $name não existe neste aparelho"); return }
        notice("a abrir ${ch.name}")
        // Fecha o leitor atual e abre o novo através da lista de canais (Back volta à lista)
        (current() as? PlayerActivity)?.finish()
        val i = Intent(c, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("assistPlayKey", key)
        c.startActivity(i)
    }

    /** Muda o aparelho para outro perfil já guardado (servidor + utilizador). */
    private fun switchProfile(c: Context, pid: Long, user: String, name: String) {
        val exists = Profiles.all(c).any { it.providerId == pid && it.user == user }
        if (!exists) { notice("o servidor $name não está guardado neste aparelho"); return }
        notice("a mudar para ${name.ifBlank { "outro servidor" }}")
        val i = Intent(c, LoginActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            .putExtra("switchPid", pid)
            .putExtra("switchUser", user)
        c.startActivity(i)
    }

    private fun reload(c: Context) {
        VodRepo.clearMemory()
        val i = Intent(c, LoginActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            .putExtra("forceAuto", true)
        c.startActivity(i)
    }

    /** Descarrega até 4 MB do ficheiro da app e mede a velocidade. */
    fun speedTest(silent: Boolean = false) {
        Thread {
            val mbps = try {
                val c = URL(Updater.APK_URL + "?t=" + System.currentTimeMillis()).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 15000
                c.instanceFollowRedirects = true
                val start = System.nanoTime(); var total = 0L
                c.inputStream.use { inp ->
                    val buf = ByteArray(32 * 1024)
                    while (total < 4_000_000) { val n = inp.read(buf); if (n < 0) break; total += n }
                }
                c.disconnect()
                val secs = (System.nanoTime() - start) / 1e9
                if (secs > 0 && total > 200_000) total * 8 / secs / 1_000_000 else null
            } catch (e: Exception) { null }
            Presence.report(speedMbps = mbps ?: -1.0, diag = Diag.snapshot())
            if (!silent) main.post {
                current()?.let {
                    Toast.makeText(it, if (mbps != null) "Velocidade: ${"%.1f".format(mbps)} Mbps" else "Não foi possível medir a velocidade", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
