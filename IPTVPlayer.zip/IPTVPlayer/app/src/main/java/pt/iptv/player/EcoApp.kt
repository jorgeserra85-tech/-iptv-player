package pt.iptv.player

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import okhttp3.OkHttpClient

class EcoApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Tls.install(this)
        Presence.init(this)
    }

    // Capas de filmes/séries: usar as mesmas ligações seguras (para https em aparelhos antigos)
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .okHttpClient {
            val b = OkHttpClient.Builder()
            val sf = Tls.socketFactory; val tm = Tls.trustManager
            if (sf != null && tm != null) b.sslSocketFactory(sf, tm)
            b.build()
        }
        .crossfade(true)
        .build()
}
