package pt.iptv.player

import android.content.Context

/** Guarda onde o utilizador ficou em filmes e episódios, para continuar mais tarde. */
object Resume {
    private fun prefs(c: Context) = c.getSharedPreferences("resume", Context.MODE_PRIVATE)
    private fun base() = Session.server + "|" + Session.user

    fun movieKey(id: String) = "m|${base()}|$id"
    fun episodeKey(id: String) = "e|${base()}|$id"
    fun seriesKey(id: String) = "s|${base()}|$id"

    /** Posição guardada em ms (null = nunca visto ou já terminado). */
    fun position(c: Context, key: String): Long? =
        prefs(c).getString(key, null)?.split("|")?.getOrNull(0)?.toLongOrNull()?.takeIf { it > 0 }

    fun duration(c: Context, key: String): Long =
        prefs(c).getString(key, null)?.split("|")?.getOrNull(1)?.toLongOrNull() ?: 0L

    /** Quando foi visto pela última vez (0 = nunca). */
    fun time(c: Context, key: String): Long =
        prefs(c).getString(key, null)?.split("|")?.getOrNull(2)?.toLongOrNull() ?: 0L

    fun watched(c: Context, key: String) = prefs(c).getString(key, null)?.startsWith("-1") == true

    fun save(c: Context, key: String, pos: Long, dur: Long, seriesKey: String?) {
        if (pos < 10_000) return                                  // menos de 10 s: não vale a pena
        val now = System.currentTimeMillis()
        val done = dur > 0 && (pos > dur - 120_000 || pos > dur * 0.95)
        prefs(c).edit().apply {
            putString(key, if (done) "-1|$dur|$now" else "$pos|$dur|$now")
            if (seriesKey != null) putString(seriesKey, "$now")
        }.apply()
    }

    fun markWatched(c: Context, key: String, dur: Long) {
        prefs(c).edit().putString(key, "-1|$dur|${System.currentTimeMillis()}").apply()
    }

    /** IDs de filmes a meio, do mais recente para o mais antigo. */
    fun moviesInProgress(c: Context): List<String> = recent(c, "m|${base()}|") { v -> !v.startsWith("-1") }

    /** IDs de séries vistas recentemente. */
    fun recentSeries(c: Context): List<String> = recent(c, "s|${base()}|") { true }

    private fun recent(c: Context, prefix: String, ok: (String) -> Boolean): List<String> =
        prefs(c).all.entries
            .filter { it.key.startsWith(prefix) && (it.value as? String)?.let(ok) == true }
            .sortedByDescending { (it.value as String).split("|").last().toLongOrNull() ?: 0L }
            .map { it.key.removePrefix(prefix) }

    /** Todas as entradas desta conta, em JSON, para sincronizar com a conta. */
    fun accountBlob(c: Context): String {
        val b = base()
        val o = org.json.JSONObject()
        prefs(c).all.forEach { (k, v) ->
            if (v is String && (k.startsWith("m|$b|") || k.startsWith("e|$b|") || k.startsWith("s|$b|"))) o.put(k, v)
        }
        return o.toString()
    }

    /** Junta o estado vindo da conta: por cada chave, fica a marca mais recente. */
    fun mergeFrom(c: Context, blobJson: String) {
        val o = try { org.json.JSONObject(blobJson) } catch (_: Exception) { return }
        val e = prefs(c).edit(); var changed = false
        o.keys().forEach { k ->
            val rv = o.optString(k)
            val rt = rv.split("|").getOrNull(2)?.toLongOrNull() ?: 0L
            val lt = prefs(c).getString(k, null)?.split("|")?.getOrNull(2)?.toLongOrNull() ?: 0L
            if (rt > lt && rv.isNotEmpty()) { e.putString(k, rv); changed = true }
        }
        if (changed) e.apply()
    }

    fun fmt(ms: Long): String {
        val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }
}
