package pt.iptv.player

import android.app.Activity
import android.content.Intent
import android.view.View

/** Separadores TV / FILMES / SÉRIES. 0 = TV, 1 = Filmes, 2 = Séries. */
object Tabs {
    fun setup(a: Activity, current: Int) {
        listOf(R.id.tabTv, R.id.tabMovies, R.id.tabSeries).forEachIndexed { i, id ->
            val v = a.findViewById<View>(id) ?: return@forEachIndexed
            v.isActivated = i == current
            v.setOnClickListener { go(a, current, i) }
        }
    }

    private fun go(a: Activity, from: Int, to: Int) {
        if (from == to) return
        if (to == 0) { a.finish(); return }           // o ecrã de TV está sempre por baixo
        a.startActivity(Intent(a, VodActivity::class.java)
            .putExtra(VodActivity.EXTRA_MODE, if (to == 1) VodActivity.MOVIES else VodActivity.SERIES))
        if (from != 0) a.finish()
        @Suppress("DEPRECATION") a.overridePendingTransition(0, 0)
    }

    fun goProfiles(a: Activity) {
        a.startActivity(Intent(a, LoginActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }
}
