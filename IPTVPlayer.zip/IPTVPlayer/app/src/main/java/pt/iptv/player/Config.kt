package pt.iptv.player

object Config {
    const val SUPABASE_URL = "https://lintzyocyzkdxjjllhoh.supabase.co"
    const val SUPABASE_KEY = "sb_publishable_CP8imQ0ag4fmSl8NkKKvgQ_ck7Rt5hB"
}
