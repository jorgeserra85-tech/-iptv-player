package pt.iptv.player

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Ficha de um filme (botão VER) ou de uma série (temporadas e episódios). */
class DetailActivity : AppCompatActivity() {
    private lateinit var item: VodItem
    private var seasons: java.util.TreeMap<Int, MutableList<Episode>> = java.util.TreeMap()
    private var currentSeason: Int? = null
    private var seasonChips = ArrayList<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        item = VodActivity.selected ?: run { finish(); return }
        setContentView(R.layout.activity_detail)
        findViewById<Button>(R.id.backBtn).setOnClickListener { finish() }

        // mostra logo o que já sabemos da lista
        show(VodInfo(item.name, item.plot, "", "", "", item.year, "", item.rating, item.cover, null))

        val play = findViewById<Button>(R.id.playBtn)
        if (!item.series) {
            play.visibility = View.VISIBLE
            play.setOnClickListener { playMovie() }
            play.requestFocus()
        }
        updatePlayButton()

        val progress = findViewById<View>(R.id.progress)
        lifecycleScope.launch {
            try {
                if (item.series) {
                    val (info, s) = withContext(Dispatchers.IO) { Api.seriesInfo(item) }
                    show(info); seasons = s
                    showSeasons()
                    updatePlayButton()
                } else {
                    withContext(Dispatchers.IO) { Api.movieInfo(item) }?.let { show(it) }
                }
            } catch (e: Exception) {
                if (item.series) Toast.makeText(this@DetailActivity, "Não foi possível carregar os episódios", Toast.LENGTH_LONG).show()
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    private fun show(i: VodInfo) {
        findViewById<TextView>(R.id.title).text = i.title.ifBlank { item.name }
        val meta = listOfNotNull(
            i.year.takeIf { it.isNotBlank() },
            i.duration.takeIf { it.isNotBlank() },
            if (i.rating > 0) "★ " + String.format(Locale.US, "%.1f", i.rating) else null
        ).joinToString("  ·  ")
        findViewById<TextView>(R.id.meta).text = meta
        findViewById<TextView>(R.id.genre).text = i.genre
        findViewById<TextView>(R.id.plot).text = i.plot.ifBlank { item.plot }
        val credits = listOfNotNull(
            i.director.takeIf { it.isNotBlank() }?.let { "Realização: $it" },
            i.cast.takeIf { it.isNotBlank() }?.let { "Elenco: $it" }
        ).joinToString("\n")
        findViewById<TextView>(R.id.credits).text = credits
        val cover = i.cover ?: item.cover
        findViewById<ImageView>(R.id.cover).load(cover) { crossfade(true); placeholder(R.drawable.poster_placeholder); error(R.drawable.poster_placeholder) }
        (i.backdrop ?: cover)?.let { findViewById<ImageView>(R.id.backdrop).load(it) { crossfade(true) } }
    }

    override fun onResume() {
        super.onResume()
        updatePlayButton()
        currentSeason?.let { showEpisodes(it) }     // atualiza "visto até…"
    }

    private fun updatePlayButton() {
        val play = findViewById<Button>(R.id.playBtn)
        if (!item.series) {
            val pos = Resume.position(this, Resume.movieKey(item.id))
            play.text = if (pos != null) "▶  CONTINUAR (${Resume.fmt(pos)})" else "▶  VER FILME"
            return
        }
        // Série: continuar no último episódio visto (ou no seguinte, se já terminou)
        val eps = seasons.values.flatten()
        val last = eps.maxByOrNull { Resume.time(this, Resume.episodeKey(it.id)) }
        if (last == null || Resume.time(this, Resume.episodeKey(last.id)) == 0L) { play.visibility = View.GONE; return }
        val target = if (Resume.watched(this, Resume.episodeKey(last.id))) eps.getOrNull(eps.indexOf(last) + 1) ?: last else last
        play.visibility = View.VISIBLE
        play.text = "▶  CONTINUAR " + (if (target.season > 0) "T${target.season} E${target.num}" else "EP. ${target.num}")
        play.setOnClickListener { playEpisode(target) }
    }

    private fun playMovie() {
        startActivity(Intent(this, PlayerActivity::class.java)
            .putStringArrayListExtra("urls", arrayListOf(Api.movieUrl(item)))
            .putExtra("title", item.name)
            .putExtra("sub", "Filme")
            .putExtra("vod", true)
            .putExtra("resumeKey", Resume.movieKey(item.id)))
    }

    private fun playEpisode(e: Episode) {
        startActivity(Intent(this, PlayerActivity::class.java)
            .putStringArrayListExtra("urls", arrayListOf(Api.episodeUrl(e)))
            .putExtra("title", item.name)
            .putExtra("sub", (if (e.season > 0) "T${e.season} E${e.num} · " else "") + e.title)
            .putExtra("vod", true)
            .putExtra("resumeKey", Resume.episodeKey(e.id))
            .putExtra("seriesKey", Resume.seriesKey(item.id)))
    }

    private fun showSeasons() {
        val box = findViewById<LinearLayout>(R.id.seasonsBox)
        box.removeAllViews()
        if (seasons.isEmpty()) {
            findViewById<TextView>(R.id.seasonsTitle).apply { text = "Sem episódios disponíveis"; visibility = View.VISIBLE }
            return
        }
        findViewById<View>(R.id.seasonsTitle).visibility = View.VISIBLE
        seasonChips.clear()
        // abre na temporada do último episódio visto
        val lastSeen = seasons.values.flatten().maxByOrNull { Resume.time(this, Resume.episodeKey(it.id)) }
            ?.takeIf { Resume.time(this, Resume.episodeKey(it.id)) > 0 }?.season
        val first = lastSeen?.takeIf { it in seasons } ?: seasons.firstKey()
        for (s in seasons.keys) {
            val chip = layoutInflater.inflate(R.layout.item_season, box, false) as TextView
            chip.text = if (s > 0) "Temporada $s" else "Episódios"
            chip.setOnClickListener { seasonChips.forEach { it.isActivated = it === chip }; showEpisodes(s) }
            chip.isActivated = s == first
            seasonChips += chip; box.addView(chip)
        }
        showEpisodes(first)
    }

    private fun showEpisodes(season: Int) {
        currentSeason = season
        val box = findViewById<LinearLayout>(R.id.episodesBox)
        box.removeAllViews()
        for (e in seasons[season] ?: emptyList()) {
            val v = layoutInflater.inflate(R.layout.item_episode, box, false)
            v.findViewById<TextView>(R.id.epTitle).text = (if (e.num > 0) "${e.num}. " else "") + e.title
            val key = Resume.episodeKey(e.id)
            val progress = when {
                Resume.watched(this, key) -> "✓ Visto"
                Resume.position(this, key) != null -> "Visto até ${Resume.fmt(Resume.position(this, key)!!)}"
                else -> ""
            }
            v.findViewById<TextView>(R.id.epMeta).text = listOf(
                if (e.season > 0) "T${e.season} · E${e.num}" else "", e.duration, progress).filter { it.isNotBlank() }.joinToString("  ·  ")
            val plot = v.findViewById<TextView>(R.id.epPlot)
            plot.text = e.plot; plot.visibility = if (e.plot.isBlank()) View.GONE else View.VISIBLE
            v.findViewById<ImageView>(R.id.thumb).load(e.image ?: item.cover) {
                crossfade(true); placeholder(R.drawable.poster_placeholder); error(R.drawable.poster_placeholder)
            }
            v.setOnClickListener { playEpisode(e) }
            box.addView(v)
        }
    }
}
