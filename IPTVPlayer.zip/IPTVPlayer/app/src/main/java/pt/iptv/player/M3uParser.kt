package pt.iptv.player

data class Channel(
    val name: String,
    val url: String,
    val group: String,
    val logo: String?,
    val userAgent: String? = null,
    val referer: String? = null,
    val streamId: String? = null,
    val archive: Boolean = false,
    val archiveDays: Int = 0,
    val custom: Boolean = false        // cópia num grupo personalizado do painel
)

object M3uParser {
    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var group = ""
        var logo: String? = null
        var ua: String? = null
        var ref: String? = null
        for (raw in text.lineSequence()) {
            val line = raw.trim().removePrefix("﻿")
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val attrs = attrRegex.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    // nome = texto depois da última vírgula fora de aspas
                    var inQuote = false; var comma = -1
                    for (i in line.indices) {
                        val c = line[i]
                        if (c == '"') inQuote = !inQuote
                        else if (c == ',' && !inQuote) comma = i
                    }
                    name = if (comma >= 0) line.substring(comma + 1).trim() else attrs["tvg-name"]
                    if (name.isNullOrBlank()) name = attrs["tvg-name"] ?: "Sem nome"
                    group = attrs["group-title"] ?: group.ifEmpty { "" }
                    logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() }
                    attrs["http-user-agent"]?.let { ua = it }
                    attrs["http-referrer"]?.let { ref = it }
                }
                line.startsWith("#EXTGRP:", ignoreCase = true) -> group = line.substringAfter(':').trim()
                line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                    val opt = line.substringAfter(':')
                    when {
                        opt.startsWith("http-user-agent=", true) -> ua = opt.substringAfter('=')
                        opt.startsWith("http-referrer=", true) -> ref = opt.substringAfter('=')
                    }
                }
                line.startsWith("#") -> Unit
                else -> {
                    out += Channel(name ?: line.substringAfterLast('/'), line,
                        group.ifBlank { "Sem grupo" }, logo, ua, ref)
                    name = null; logo = null; ua = null; ref = null; group = ""
                }
            }
        }
        return out
    }
}
