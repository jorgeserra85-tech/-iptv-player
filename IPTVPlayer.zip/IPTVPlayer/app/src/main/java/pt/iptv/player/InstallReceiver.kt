package pt.iptv.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.widget.Toast

/** Recebe o resultado da instalação da atualização. */
class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                // o Android pede confirmação: abrir o ecrã "Instalar"
                @Suppress("DEPRECATION")
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT) ?: return
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { c.startActivity(confirm) }
                catch (e: Exception) { Toast.makeText(c, "Abra o link da app para instalar a atualização.", Toast.LENGTH_LONG).show() }
            }
            PackageInstaller.STATUS_SUCCESS -> {}
            else -> {
                // A instalação silenciosa falhou (Play Protect, verificação do sistema, etc.).
                // Em vez de mostrar o erro e obrigar a repetir, abre o instalador clássico "Instalar".
                Toast.makeText(c, "A abrir o instalador…", Toast.LENGTH_SHORT).show()
                Updater.fallbackToClassic(c)
            }
        }
    }
}
