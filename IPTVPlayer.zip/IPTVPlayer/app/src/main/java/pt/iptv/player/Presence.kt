package pt.iptv.player

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Sinal de presença para o painel ("quem está a usar a app").
 * Envia: aparelho, versão, servidor, utilizador (nunca a palavra-passe) e o que está a ver.
 */
object Presence {
    @Volatile private var watching = ""
    private var started = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var app: Context

    private val tick = object : Runnable {
        override fun run() { ping(); handler.postDelayed(this, 60_000) }
    }
    private val poll = object : Runnable {
        override fun run() { Assist.poll(app); handler.postDelayed(this, 15_000) }
    }

    fun init(a: Application) {
        app = a.applicationContext
        a.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(x: Activity) {
                if (started++ == 0) {
                    handler.removeCallbacks(tick); handler.postDelayed(tick, 2_000)
                    handler.removeCallbacks(poll); handler.postDelayed(poll, 5_000)
                }
            }
            override fun onActivityStopped(x: Activity) {
                if (--started <= 0) { started = 0; handler.removeCallbacks(tick); handler.removeCallbacks(poll) }
            }
            override fun onActivityCreated(x: Activity, b: Bundle?) {}
            override fun onActivityResumed(x: Activity) { SleepTimer.current = java.lang.ref.WeakReference(x) }
            override fun onActivityPaused(x: Activity) {}
            override fun onActivitySaveInstanceState(x: Activity, b: Bundle) {}
            override fun onActivityDestroyed(x: Activity) {}
        })
    }

    /** O que está a fazer agora (ex.: "TV: RTP 1"). Envia logo. */
    fun set(what: String) {
        if (what == watching) return
        watching = what
        ping()
    }

    /** Código de 6 algarismos que o cliente diz ao telefone para encontrares o aparelho. */
    fun assistCode(): String {
        if (!::app.isInitialized) return ""
        val h = deviceId().hashCode().toLong() and 0x7fffffff
        return String.format("%06d", h % 1_000_000)
    }

    fun deviceId(): String {
        val p = app.getSharedPreferences("presence", Context.MODE_PRIVATE)
        return p.getString("id", null) ?: UUID.randomUUID().toString().also { p.edit().putString("id", it).apply() }
    }

    private fun appVersion() = try { app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    private fun body(pid: Long, title: String, user: String): String = JSONObject()
        .put("p_device", deviceId())
        .put("p_provider", if (pid > 0) pid else JSONObject.NULL)
        .put("p_provider_name", title)
        .put("p_user", user)
        .put("p_model", (Build.MANUFACTURER + " " + Build.MODEL).trim())
        .put("p_android", Build.VERSION.RELEASE ?: "")
        .put("p_version", appVersion())
        .put("p_watching", watching)
        .put("p_exp", Session.expIso)
        .toString()

    /** Envia o código de assistência, o último erro, a velocidade e o diagnóstico. */
    fun report(error: String? = null, speedMbps: Double? = null, diag: String? = null) {
        if (!::app.isInitialized) return
        val b = JSONObject().put("p_device", deviceId()).put("p_code", assistCode())
            .put("p_error", error ?: JSONObject.NULL).put("p_speed", speedMbps ?: JSONObject.NULL)
            .put("p_diag", diag ?: JSONObject.NULL).toString()
        Thread { Assist.rpc("device_report", b) }.start()
    }

    /** Envia o sinal e devolve true se o aparelho estiver bloqueado no painel (null = sem resposta). */
    fun send(pid: Long, title: String, user: String): Boolean? = try {
        val c = URL("${Config.SUPABASE_URL}/rest/v1/rpc/device_ping").openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("apikey", Config.SUPABASE_KEY)
        c.outputStream.use { it.write(body(pid, title, user).toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val txt = if (code in 200..299) c.inputStream.bufferedReader().use { it.readText() }.trim() else ""
        c.disconnect()
        if (code in 200..299) txt == "true" else null
    } catch (e: Exception) { null }

    fun ping() {
        if (!::app.isInitialized || Session.user.isEmpty()) return
        val pid = Session.providerId; val t = Session.title; val u = Session.user
        Thread {
            if (send(pid, t, u) == true) handler.post { kickOut() }
        }.start()
    }

    /** Aparelho bloqueado no painel: avisar e fechar a app. */
    fun kickOut() {
        val a = SleepTimer.current?.get() ?: return
        if (a.isFinishing) return
        try {
            android.app.AlertDialog.Builder(a)
                .setTitle("⛔ Aparelho bloqueado")
                .setMessage("Este aparelho foi bloqueado pelo fornecedor do serviço. Contacte-o para mais informações.")
                .setCancelable(false)
                .setPositiveButton("OK") { _, _ -> a.finishAffinity() }
                .show()
        } catch (_: Exception) { a.finishAffinity() }
    }
}
