package pt.iptv.player

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Sinal de presença para o painel ("quem está a usar a app").
 * Envia: aparelho, versão, servidor, utilizador (nunca a palavra-passe) e o que está a ver.
 */
object Presence {
    @Volatile private var watching = ""
    private var started = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var app: Context

    private val tick = object : Runnable {
        override fun run() { ping(); handler.postDelayed(this, 60_000) }
    }

    fun init(a: Application) {
        app = a.applicationContext
        a.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(x: Activity) {
                if (started++ == 0) { handler.removeCallbacks(tick); handler.postDelayed(tick, 2_000) }
            }
            override fun onActivityStopped(x: Activity) {
                if (--started <= 0) { started = 0; handler.removeCallbacks(tick) }
            }
            override fun onActivityCreated(x: Activity, b: Bundle?) {}
            override fun onActivityResumed(x: Activity) {}
            override fun onActivityPaused(x: Activity) {}
            override fun onActivitySaveInstanceState(x: Activity, b: Bundle) {}
            override fun onActivityDestroyed(x: Activity) {}
        })
    }

    /** O que está a fazer agora (ex.: "TV: RTP 1"). Envia logo. */
    fun set(what: String) {
        if (what == watching) return
        watching = what
        ping()
    }

    private fun deviceId(): String {
        val p = app.getSharedPreferences("presence", Context.MODE_PRIVATE)
        return p.getString("id", null) ?: UUID.randomUUID().toString().also { p.edit().putString("id", it).apply() }
    }

    private fun appVersion() = try { app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

    fun ping() {
        if (!::app.isInitialized || Session.user.isEmpty()) return
        val body = JSONObject()
            .put("p_device", deviceId())
            .put("p_provider", if (Session.providerId > 0) Session.providerId else JSONObject.NULL)
            .put("p_provider_name", Session.title)
            .put("p_user", Session.user)
            .put("p_model", (Build.MANUFACTURER + " " + Build.MODEL).trim())
            .put("p_android", Build.VERSION.RELEASE ?: "")
            .put("p_version", appVersion())
            .put("p_watching", watching)
            .toString()
        Thread {
            try {
                val c = URL("${Config.SUPABASE_URL}/rest/v1/rpc/device_ping").openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("apikey", Config.SUPABASE_KEY)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                c.responseCode; c.disconnect()
            } catch (_: Exception) {}
        }.start()
    }
}
