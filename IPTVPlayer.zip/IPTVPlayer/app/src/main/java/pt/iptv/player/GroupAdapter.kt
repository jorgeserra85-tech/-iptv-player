package pt.iptv.player

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView

/** Lista de grupos à esquerda: o grupo onde está o cursor do comando fica branco. */
class GroupAdapter(private val ctx: Context, private val list: ListView) : BaseAdapter() {
    var labels: List<String> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }
    var onSelect: ((Int) -> Unit)? = null
    private var focusPos = -1
    private var listFocused = false

    init {
        list.adapter = this
        list.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                focusPos = pos; restyle(); onSelect?.invoke(pos)
            }
            override fun onNothingSelected(p: AdapterView<*>?) { focusPos = -1; restyle() }
        }
        list.setOnFocusChangeListener { _, has ->
            listFocused = has
            if (has) focusPos = list.selectedItemPosition
            restyle()
        }
    }

    override fun getCount() = labels.size
    override fun getItem(p: Int) = labels[p]
    override fun getItemId(p: Int) = p.toLong()

    override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
        val v = (convert ?: LayoutInflater.from(ctx).inflate(R.layout.item_group, parent, false)) as TextView
        v.text = labels[p]
        style(v, p)
        return v
    }

    private fun style(v: TextView, p: Int) {
        val hi = listFocused && p == focusPos
        v.setBackgroundResource(if (hi) R.drawable.group_focus_bg else R.drawable.group_bg)
        if (hi) v.setTextColor(0xFF08150F.toInt())
        else v.setTextColor(ctx.resources.getColorStateList(R.color.group_text))
    }

    /** Atualiza só os itens visíveis (sem mexer na posição do cursor). */
    private fun restyle() {
        for (i in 0 until list.childCount) {
            val c = list.getChildAt(i) as? TextView ?: continue
            style(c, list.firstVisiblePosition + i)
        }
    }
}
