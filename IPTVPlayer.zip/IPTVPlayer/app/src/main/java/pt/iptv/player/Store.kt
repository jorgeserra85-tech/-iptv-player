package pt.iptv.player

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Memória da app no aparelho:
 * - sessão atual (para voltar ao sítio certo se o Android fechar a app);
 * - cópia da lista de canais e de filmes/séries (para abrir logo, sem esperar pela internet).
 */
object Store {
    // ---------- Sessão ----------
    fun saveSession(c: Context) {
        c.getSharedPreferences("session", Context.MODE_PRIVATE).edit()
            .putString("server", Session.server).putString("user", Session.user).putString("pass", Session.pass)
            .putLong("pid", Session.providerId).putString("title", Session.title).putString("sub", Session.sub)
            .putString("exp", Session.expIso).apply()
    }

    /** Repõe a sessão guardada. false se não houver. */
    fun restoreSession(c: Context): Boolean {
        if (Session.user.isNotEmpty()) return true
        val p = c.getSharedPreferences("session", Context.MODE_PRIVATE)
        val user = p.getString("user", null) ?: return false
        Session.server = p.getString("server", "") ?: ""
        Session.user = user; Session.pass = p.getString("pass", "") ?: ""
        Session.providerId = p.getLong("pid", 0); Session.title = p.getString("title", "") ?: ""
        Session.sub = p.getString("sub", "") ?: ""; Session.expIso = p.getString("exp", "") ?: ""
        return Session.server.isNotEmpty()
    }

    private fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(60)
    private fun file(c: Context, name: String) = File(c.filesDir, "cache_" + safe(name) + ".json")
    fun profileKey(pid: Long, user: String) = "${pid}_$user"

    // ---------- Canais ----------
    fun saveChannels(c: Context, pid: Long, user: String, channels: List<Channel>) {
        try {
            val arr = JSONArray()
            channels.forEach { ch ->
                arr.put(JSONObject().put("n", ch.name).put("u", ch.url).put("g", ch.group)
                    .put("l", ch.logo ?: "").put("s", ch.streamId ?: "").put("a", ch.archive).put("d", ch.archiveDays)
                    .put("ua", ch.userAgent ?: "").put("r", ch.referer ?: ""))
            }
            val o = JSONObject()
                .put("server", Session.server).put("title", Session.title).put("sub", Session.sub).put("exp", Session.expIso)
                .put("channels", arr)
                .put("lockedLive", JSONArray(Parental.lockedGroupsOf("live").toList()))
                .put("lockedCh", JSONArray(Parental.lockedChannelKeys().toList()))
            file(c, "ch_" + profileKey(pid, user)).writeText(o.toString())
        } catch (_: Exception) {}
    }

    /** Lê a lista de canais guardada (e repõe os cadeados). null se não houver. */
    fun loadChannels(c: Context, pid: Long, user: String): List<Channel>? = try {
        val f = file(c, "ch_" + profileKey(pid, user))
        if (!f.exists()) null else {
            val o = JSONObject(f.readText())
            val arr = o.getJSONArray("channels")
            val list = (0 until arr.length()).map { i ->
                val j = arr.getJSONObject(i)
                Channel(j.optString("n"), j.optString("u"), j.optString("g"),
                    j.optString("l").ifBlank { null }, j.optString("ua").ifBlank { null }, j.optString("r").ifBlank { null },
                    j.optString("s").ifBlank { null }, j.optBoolean("a"), j.optInt("d"))
            }
            Parental.setLockedGroups("live", o.optJSONArray("lockedLive").strings())
            Parental.setLockedChannels(o.optJSONArray("lockedCh").strings())
            if (Session.title.isEmpty()) Session.title = o.optString("title")
            if (Session.sub.isEmpty()) Session.sub = o.optString("sub")
            list.ifEmpty { null }
        }
    } catch (e: Exception) { null }

    /** Repõe o endereço do servidor e a validade guardados com a lista de canais. */
    fun restoreCachedServer(c: Context, pid: Long, user: String) {
        try {
            val o = JSONObject(file(c, "ch_" + profileKey(pid, user)).readText())
            Session.server = o.optString("server"); Session.sub = o.optString("sub"); Session.expIso = o.optString("exp")
        } catch (_: Exception) {}
    }

    fun clearChannels(c: Context, pid: Long, user: String) { file(c, "ch_" + profileKey(pid, user)).delete() }

    // ---------- Filmes / séries ----------
    fun saveVod(c: Context, series: Boolean, items: List<VodItem>, order: List<String>) {
        try {
            val arr = JSONArray()
            items.forEach { v ->
                arr.put(JSONObject().put("i", v.id).put("n", v.name).put("c", v.cover ?: "").put("g", v.category)
                    .put("r", v.rating).put("e", v.ext).put("a", v.added).put("p", v.plot).put("y", v.year))
            }
            val kind = if (series) "series" else "vod"
            val o = JSONObject().put("items", arr).put("order", JSONArray(order))
                .put("locked", JSONArray(Parental.lockedGroupsOf(kind).toList()))
            file(c, (if (series) "s_" else "m_") + profileKey(Session.providerId, Session.user)).writeText(o.toString())
        } catch (_: Exception) {}
    }

    fun loadVod(c: Context, series: Boolean): Pair<List<VodItem>, List<String>>? = try {
        val f = file(c, (if (series) "s_" else "m_") + profileKey(Session.providerId, Session.user))
        if (!f.exists()) null else {
            val o = JSONObject(f.readText())
            val arr = o.getJSONArray("items")
            val items = (0 until arr.length()).map { i ->
                val j = arr.getJSONObject(i)
                VodItem(j.optString("i"), j.optString("n"), j.optString("c").ifBlank { null }, j.optString("g"),
                    j.optDouble("r", 0.0), j.optString("e"), j.optLong("a"), series, j.optString("p"), j.optString("y"))
            }
            Parental.setLockedGroups(if (series) "series" else "vod", o.optJSONArray("locked").strings())
            items to o.optJSONArray("order").strings()
        }
    } catch (e: Exception) { null }

    private fun JSONArray?.strings(): List<String> =
        if (this == null) emptyList() else (0 until length()).map { optString(it) }
}
