package pt.iptv.player

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Grelha de filmes ou séries com as capas, categorias à esquerda. */
class VodActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_MODE = "mode"
        const val MOVIES = "movies"
        const val SERIES = "series"
        const val ALL = "Todos"
        const val CONTINUE = "▶ Continuar a ver"
        private val cache = HashMap<String, List<VodItem>>()   // guarda as listas enquanto a app está aberta
        var selected: VodItem? = null
    }

    private var isSeries = false
    private val kind get() = if (isSeries) "series" else "vod"
    private var all: List<VodItem> = emptyList()
    private var groups: List<String> = listOf(ALL)
    private var currentGroup = ALL
    private lateinit var adapter: PosterAdapter
    private lateinit var groupList: ListView
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vod)
        isSeries = intent.getStringExtra(EXTRA_MODE) == SERIES
        findViewById<TextView>(R.id.title).text = if (isSeries) "Séries" else "Filmes"
        findViewById<TextView>(R.id.sub).text = Session.title + if (Session.sub.isNotEmpty()) " · ${Session.sub}" else ""
        findViewById<Button>(R.id.backBtn).setOnClickListener { Tabs.goProfiles(this) }
        Tabs.setup(this, if (isSeries) 2 else 1)

        groupList = findViewById(R.id.groupList)
        groupAdapter = GroupAdapter(this, groupList)
        grid = findViewById(R.id.grid)
        search = findViewById(R.id.searchInput)
        status = findViewById(R.id.status)
        search.hint = if (isSeries) "Pesquisar série…" else "Pesquisar filme…"

        adapter = PosterAdapter()
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ ->
            selected = adapter.items[pos]
            startActivity(Intent(this, DetailActivity::class.java))
        }
        groupList.setOnItemClickListener { _, _, pos, _ ->
            val g = groups[pos]
            groupList.setItemChecked(groups.indexOf(currentGroup), true)   // só muda depois do PIN, se for preciso
            val open = {
                currentGroup = g
                buildGroups()
                grid.setSelection(0)
            }
            if (Parental.locked(kind, g)) Parental.ask(this) { open() } else open()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = applyFilter()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        load()
    }

    private fun load() {
        val key = (if (isSeries) "s|" else "m|") + Session.server + "|" + Session.user
        val progress = findViewById<View>(R.id.progress)
        status.text = if (isSeries) "A carregar séries…" else "A carregar filmes…"
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val (items, order) = withContext(Dispatchers.IO) {
                    val c = Api.vodCategories(isSeries)
                    val list = cache[key] ?: (if (isSeries) Api.seriesList(c) else Api.movies(c)).also { cache[key] = it }
                    Api.applyVodGroups(kind, list, c.values.toList())   // ordem / esconder / nome / PIN do painel
                }
                all = items
                catOrder = order
                buildGroups()
                if (items.isEmpty()) status.text = if (isSeries) "Este servidor não tem séries." else "Este servidor não tem filmes."
            } catch (e: Exception) {
                status.text = "Não foi possível carregar: ${e.message ?: "erro"}. Toque aqui para tentar outra vez."
                status.setOnClickListener { status.setOnClickListener(null); load() }
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    private var catOrder: List<String> = emptyList()

    override fun onResume() {
        super.onResume()
        Presence.set(if (isSeries) "A ver lista de séries" else "A ver lista de filmes")
        if (all.isNotEmpty()) buildGroups()      // atualiza "Continuar a ver"
    }

    /** Filmes a meio ou séries vistas recentemente, do mais recente para o mais antigo. */
    private fun continueItems(): List<VodItem> {
        val ids = if (isSeries) Resume.recentSeries(this) else Resume.moviesInProgress(this)
        if (ids.isEmpty()) return emptyList()
        val byId = all.associateBy { it.id }
        return ids.mapNotNull { byId[it] }.filter { !Parental.locked(kind, it.category) }
    }

    private fun buildGroups() {
        val present = all.map { it.category }.toSet()
        val ordered = catOrder.filter { it in present }.distinct()
        val cont = continueItems()
        groups = listOf(ALL) + (if (cont.isNotEmpty()) listOf(CONTINUE) else emptyList()) +
                ordered + (present - ordered.toSet()).sorted()
        if (currentGroup !in groups) currentGroup = ALL
        val counts = all.groupingBy { it.category }.eachCount()
        val visibleAll = all.count { !Parental.locked(kind, it.category) }
        groupAdapter.labels = groups.map {
            when (it) {
                ALL -> "$ALL ($visibleAll)"
                CONTINUE -> "$CONTINUE (${cont.size})"
                else -> "${Parental.label(kind, it)} (${counts[it] ?: 0})"
            }
        }
        groupList.setItemChecked(groups.indexOf(currentGroup), true)
        applyFilter()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim()
        val source = if (currentGroup == CONTINUE) continueItems() else all
        var list = source.filter {
            (currentGroup == ALL || currentGroup == CONTINUE || it.category == currentGroup) &&
                !Parental.locked(kind, it.category) &&
                (q.isEmpty() || it.name.contains(q, ignoreCase = true))
        }
        if (currentGroup == ALL && q.isEmpty()) list = list.sortedByDescending { it.added }   // mais recentes primeiro
        adapter.items = list
        adapter.notifyDataSetChanged()
        status.text = "${list.size} " + (if (isSeries) "séries" else "filmes") + if (currentGroup != ALL) " · $currentGroup" else ""
    }

    inner class PosterAdapter : BaseAdapter() {
        var items: List<VodItem> = emptyList()
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: layoutInflater.inflate(R.layout.item_poster, parent, false)
            val item = items[p]
            v.findViewById<TextView>(R.id.title).text = item.name
            val r = v.findViewById<TextView>(R.id.rating)
            if (item.rating > 0) { r.text = "★ " + String.format(java.util.Locale.US, "%.1f", item.rating); r.visibility = View.VISIBLE }
            else r.visibility = View.GONE
            val noCover = v.findViewById<TextView>(R.id.noCover)
            noCover.text = item.name
            noCover.visibility = if (item.cover == null) View.VISIBLE else View.GONE
            v.findViewById<ImageView>(R.id.cover).load(item.cover) {
                crossfade(true)
                placeholder(R.drawable.poster_placeholder)
                error(R.drawable.poster_placeholder)
                listener(onError = { _, _ -> noCover.visibility = View.VISIBLE })
            }
            return v
        }
    }
}
