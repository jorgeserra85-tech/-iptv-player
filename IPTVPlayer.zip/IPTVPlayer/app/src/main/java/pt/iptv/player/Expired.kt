package pt.iptv.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Avisos de validade da subscrição: aviso 2 dias antes e ecrã quando termina. */
object Expired {
    /** Marca que o ecrã de "terminada" deve aparecer assim que voltar aos perfis. */
    var pending = false
    private var showing = false

    /** Ecrã mostrado quando a subscrição terminou (sem contactos). */
    fun show(a: Activity) {
        if (a.isFinishing || showing) return
        showing = true
        AlertDialog.Builder(a)
            .setTitle("⛔ Subscrição terminada")
            .setMessage("A sua subscrição terminou.\n\nContacte o fornecedor para voltar a ativar.")
            .setPositiveButton("OK", null)
            .setOnDismissListener { showing = false }
            .show()
    }

    /** Dias que faltam até terminar. null = ilimitado/desconhecido. -1 = já terminou. */
    fun daysLeft(expIso: String): Long? {
        if (expIso.isBlank()) return null
        return try {
            val d = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(expIso) ?: return null
            val end = d.time + 24L * 60 * 60 * 1000          // válido até ao fim desse dia
            val diff = end - System.currentTimeMillis()
            if (diff < 0) -1L else diff / (24L * 60 * 60 * 1000)
        } catch (_: Exception) { null }
    }

    fun isExpired(expIso: String) = daysLeft(expIso) == -1L

    /** Avisa o cliente quando faltam 2 dias ou menos. No máximo uma vez por dia. */
    fun warnIfEnding(a: Activity) {
        val left = daysLeft(Session.expIso) ?: return
        if (left < 0 || left > 2) return
        val prefs = a.getSharedPreferences("expwarn", Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        val key = "shown_${Session.providerId}_${Session.user}"
        if (prefs.getString(key, "") == today) return
        prefs.edit().putString(key, today).apply()
        val txt = when (left) {
            0L -> "A sua subscrição termina hoje."
            1L -> "A sua subscrição termina amanhã."
            else -> "A sua subscrição termina dentro de $left dias."
        }
        if (a.isFinishing) return
        AlertDialog.Builder(a)
            .setTitle("⏳ Subscrição a terminar")
            .setMessage("$txt\n\nContacte o fornecedor para renovar e não ficar sem acesso.")
            .setPositiveButton("OK", null)
            .show()
    }
}
