package pt.iptv.player

import android.content.Context

/** Filmes e séries: memória + cópia no aparelho + atualização a partir do servidor. */
object VodRepo {
    private val mem = HashMap<String, Pair<List<VodItem>, List<String>>>()
    private fun key(series: Boolean) = (if (series) "s|" else "m|") + Session.providerId + "|" + Session.user

    /** O que já existe (memória ou cópia guardada). Rápido. */
    fun cached(c: Context, series: Boolean): Pair<List<VodItem>, List<String>>? =
        mem[key(series)] ?: Store.loadVod(c, series)?.also { mem[key(series)] = it }

    /** Vai buscar ao servidor (lento) e guarda. */
    fun fresh(c: Context, series: Boolean): Pair<List<VodItem>, List<String>> {
        val cats = Api.vodCategories(series)
        val list = if (series) Api.seriesList(cats) else Api.movies(cats)
        val r = Api.applyVodGroups(if (series) "series" else "vod", list, cats.values.toList())
        mem[key(series)] = r
        Store.saveVod(c, series, r.first, r.second)
        return r
    }

    /** Para a pesquisa: o que houver, senão vai buscar. */
    fun any(c: Context, series: Boolean): List<VodItem> =
        (cached(c, series) ?: try { fresh(c, series) } catch (e: Exception) { null })?.first ?: emptyList()

    fun clearMemory() = mem.clear()
}
