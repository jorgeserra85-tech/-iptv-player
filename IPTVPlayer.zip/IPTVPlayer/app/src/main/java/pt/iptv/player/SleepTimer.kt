package pt.iptv.player

import android.app.Activity
import android.app.AlertDialog
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.lang.ref.WeakReference

/** Temporizador: fecha a app ao fim de X minutos. */
object SleepTimer {
    private val handler = Handler(Looper.getMainLooper())
    var endAt = 0L; private set
    var current: WeakReference<Activity>? = null      // atividade em primeiro plano (posta pela EcoApp)

    private val fire = Runnable {
        endAt = 0
        current?.get()?.let { it.finishAffinity() }
    }
    private val warn = Runnable {
        current?.get()?.let { Toast.makeText(it, "⏾ A app vai desligar daqui a 1 minuto", Toast.LENGTH_LONG).show() }
    }

    fun set(minutes: Int) {
        handler.removeCallbacks(fire); handler.removeCallbacks(warn)
        if (minutes <= 0) { endAt = 0; return }
        endAt = System.currentTimeMillis() + minutes * 60_000L
        handler.postDelayed(fire, minutes * 60_000L)
        if (minutes > 1) handler.postDelayed(warn, (minutes - 1) * 60_000L)
    }

    fun dialog(a: Activity) {
        val opts = intArrayOf(0, 15, 30, 60, 90, 120)
        val labels = opts.map { if (it == 0) "Desligado" else "$it minutos" }.toTypedArray()
        val left = if (endAt > 0) ((endAt - System.currentTimeMillis()) / 60_000L + 1) else 0
        AlertDialog.Builder(a)
            .setTitle(if (endAt > 0) "⏾ Desliga daqui a $left min" else "⏾ Desligar a app daqui a…")
            .setItems(labels) { _, w ->
                set(opts[w])
                Toast.makeText(a, if (opts[w] == 0) "Temporizador desligado" else "A app desliga daqui a ${opts[w]} minutos", Toast.LENGTH_SHORT).show()
            }.show()
    }
}
