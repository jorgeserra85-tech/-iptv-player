package pt.iptv.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/** Mensagens enviadas no painel para os clientes (mostradas uma vez). */
object Announce {
    private var checked = false

    fun showNew(a: Activity) {
        if (checked || Session.providerId <= 0) return
        checked = true
        val pid = Session.providerId
        Thread {
            val msgs = try {
                val url = "${Config.SUPABASE_URL}/rest/v1/announcements?active=eq.true" +
                        "&or=(provider_id.is.null,provider_id.eq.$pid)&select=id,message&order=id.desc&limit=10"
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                c.setRequestProperty("apikey", Config.SUPABASE_KEY)
                val arr = JSONArray(c.inputStream.bufferedReader().use { it.readText() })
                (0 until arr.length()).map { arr.getJSONObject(it).let { o -> o.getLong("id") to o.getString("message") } }
            } catch (e: Exception) { emptyList() }
            val prefs = a.getSharedPreferences("announce", Context.MODE_PRIVATE)
            val seen = prefs.getStringSet("seen", emptySet())?.toSet() ?: emptySet()
            val fresh = msgs.filter { it.first.toString() !in seen }
            if (fresh.isEmpty()) return@Thread
            a.runOnUiThread {
                if (a.isFinishing) return@runOnUiThread
                AlertDialog.Builder(a)
                    .setTitle("📣 Mensagem do fornecedor")
                    .setMessage(fresh.joinToString("\n\n") { it.second })
                    .setPositiveButton("OK") { _, _ ->
                        prefs.edit().putStringSet("seen", seen + fresh.map { it.first.toString() }).apply()
                    }.show()
            }
        }.start()
    }
}
