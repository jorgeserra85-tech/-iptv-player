package pt.iptv.player

import android.content.Context
import org.json.JSONArray

object Profiles {
    private fun prefs(c: Context) = c.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Profile> {
        val arr = try { JSONArray(prefs(c).getString("list", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).map { Profile.fromJson(arr.getJSONObject(it)) }.toMutableList()
    }

    fun save(c: Context, list: List<Profile>) {
        val arr = JSONArray(); list.forEach { arr.put(it.toJson()) }
        prefs(c).edit().putString("list", arr.toString()).apply()
    }

    fun upsert(c: Context, p: Profile) {
        val l = all(c)
        l.removeAll { it.providerId == p.providerId && it.user == p.user }
        l.add(0, p); save(c, l)
    }

    fun remove(c: Context, p: Profile) {
        val l = all(c); l.removeAll { it.providerId == p.providerId && it.user == p.user }; save(c, l)
    }
}
