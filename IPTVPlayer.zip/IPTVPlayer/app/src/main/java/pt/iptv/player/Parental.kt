package pt.iptv.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.text.InputType
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.security.MessageDigest
import java.text.Normalizer

/** PIN para as categorias de adultos. */
object Parental {
    /** Desbloqueado até voltar aos perfis ou fechar a app. */
    var unlocked = false

    private val adultRegex = Regex("""(?<![a-z])(adult\w*|xxx|porn\w*|er[oó]t\w*|18\s*\+|\+\s*18)""")

    fun isAdult(group: String): Boolean =
        adultRegex.containsMatchIn(Normalizer.normalize(group, Normalizer.Form.NFKC).lowercase())

    // Categorias e canais com PIN, escolhidos no painel (ou pelo nome, se o painel não responder)
    private val lockedGroups = HashMap<String, Set<String>>()   // kind -> nomes
    private var lockedChannels: Set<String> = emptySet()        // chaves dos canais

    fun setLockedGroups(kind: String, names: Collection<String>) { lockedGroups[kind] = names.toSet() }
    fun setLockedChannels(keys: Collection<String>) { lockedChannels = keys.toSet() }

    fun hasLock(kind: String, group: String) = lockedGroups[kind]?.contains(group) == true

    /** true se esta categoria está bloqueada agora. */
    fun locked(kind: String, group: String) = !unlocked && hasLock(kind, group)

    /** true se o canal (ou a categoria dele) está bloqueado agora. */
    fun channelLocked(c: Channel) = !unlocked && (Api.channelKey(c) in lockedChannels || hasLock("live", c.group))

    fun channelHasOwnLock(c: Channel) = Api.channelKey(c) in lockedChannels

    fun label(kind: String, group: String) = if (hasLock(kind, group) && !unlocked) "🔒 $group" else group

    private fun prefs(c: Context) = c.getSharedPreferences("parental", Context.MODE_PRIVATE)
    private fun hash(pin: String) = MessageDigest.getInstance("SHA-256")
        .digest(("eco|$pin").toByteArray()).joinToString("") { "%02x".format(it) }
    private fun hasPin(c: Context) = prefs(c).contains("pin")
    private fun check(c: Context, pin: String) = prefs(c).getString("pin", null) == hash(pin)
    private fun setPin(c: Context, pin: String) = prefs(c).edit().putString("pin", hash(pin)).apply()

    private fun pinField(a: Activity, hint: String) = EditText(a).apply {
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        textSize = 22f
    }

    private fun wrap(a: Activity, vararg fields: EditText) = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        val p = (20 * a.resources.displayMetrics.density).toInt()
        setPadding(p, p / 2, p, 0)
        fields.forEach { addView(it) }
    }

    private fun AlertDialog.showWithKeyboard() {
        window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        show()
    }

    /** Pede o PIN (ou cria-o na primeira vez). Corre [onOk] se ficar desbloqueado. */
    fun ask(a: Activity, onOk: () -> Unit) {
        if (unlocked) { onOk(); return }
        if (!hasPin(a)) { create(a, onOk); return }
        val f = pinField(a, "PIN")
        val forgot = TextView(a).apply {
            text = "Esqueci-me do PIN"
            setTextColor(0xFF3DDC97.toInt()); textSize = 15f
            val p = (12 * a.resources.displayMetrics.density).toInt()
            setPadding(0, p, 0, p)
            isFocusable = true; isClickable = true
        }
        val box = wrap(a, f).apply { addView(forgot) }
        var dialog: AlertDialog? = null
        forgot.setOnClickListener { dialog?.dismiss(); recover(a, onOk) }
        val d = AlertDialog.Builder(a)
            .setTitle("🔒 Conteúdo protegido")
            .setMessage("Introduza o PIN para continuar.")
            .setView(box)
            .setPositiveButton("Desbloquear") { _, _ ->
                if (check(a, f.text.toString())) { unlocked = true; onOk() }
                else Toast.makeText(a, "PIN errado", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Alterar PIN") { _, _ -> change(a) }
            .setNegativeButton("Cancelar", null)
            .create()
        dialog = d
        d.showWithKeyboard()
    }

    /** PIN esquecido: o código de recuperação (definido no painel) apaga o PIN e deixa criar outro. */
    private fun recover(a: Activity, onOk: () -> Unit) {
        val f = EditText(a).apply {
            hint = "Código de recuperação"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            textSize = 18f
        }
        AlertDialog.Builder(a)
            .setTitle("Esqueci-me do PIN")
            .setMessage("Peça o código de recuperação a quem lhe forneceu a app.")
            .setView(wrap(a, f))
            .setPositiveButton("Confirmar") { _, _ ->
                val code = f.text.toString().trim()
                if (code.isEmpty()) return@setPositiveButton
                Thread {
                    val ok = try { Api.checkRecovery(code) } catch (e: Exception) { null }
                    a.runOnUiThread {
                        when (ok) {
                            true -> {
                                prefs(a).edit().remove("pin").apply()
                                Toast.makeText(a, "Código certo ✓ Crie um PIN novo.", Toast.LENGTH_LONG).show()
                                create(a, onOk)
                            }
                            false -> Toast.makeText(a, "Código errado", Toast.LENGTH_LONG).show()
                            null -> Toast.makeText(a, "Sem ligação. Tente outra vez.", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .setNegativeButton("Cancelar", null)
            .create().showWithKeyboard()
    }

    private fun create(a: Activity, onOk: (() -> Unit)?) {
        val f1 = pinField(a, "Novo PIN (4 a 8 números)")
        val f2 = pinField(a, "Repetir PIN")
        AlertDialog.Builder(a)
            .setTitle("🔒 Criar PIN para adultos")
            .setMessage("Este PIN vai ser pedido sempre que abrir as categorias de adultos.")
            .setView(wrap(a, f1, f2))
            .setPositiveButton("Guardar") { _, _ ->
                val p1 = f1.text.toString(); val p2 = f2.text.toString()
                when {
                    p1.length !in 4..8 -> Toast.makeText(a, "O PIN deve ter 4 a 8 números", Toast.LENGTH_LONG).show()
                    p1 != p2 -> Toast.makeText(a, "Os PIN não são iguais", Toast.LENGTH_LONG).show()
                    else -> {
                        setPin(a, p1)
                        Toast.makeText(a, "PIN guardado ✓", Toast.LENGTH_SHORT).show()
                        if (onOk != null) { unlocked = true; onOk() }
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .create().showWithKeyboard()
    }

    private fun change(a: Activity) {
        val old = pinField(a, "PIN atual")
        AlertDialog.Builder(a)
            .setTitle("Alterar PIN")
            .setView(wrap(a, old))
            .setPositiveButton("Continuar") { _, _ ->
                if (check(a, old.text.toString())) create(a, null)
                else Toast.makeText(a, "PIN errado", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .create().showWithKeyboard()
    }
}
