package pt.iptv.player

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.text.InputType
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.security.MessageDigest
import java.text.Normalizer

/** PIN para as categorias de adultos. */
object Parental {
    /** Desbloqueado até voltar aos perfis ou fechar a app. */
    var unlocked = false

    private val adultRegex = Regex("""(?<![a-z])(adult\w*|xxx|porn\w*|er[oó]t\w*|18\s*\+|\+\s*18)""")

    fun isAdult(group: String): Boolean =
        adultRegex.containsMatchIn(Normalizer.normalize(group, Normalizer.Form.NFKC).lowercase())

    // Categorias e canais com PIN vindos do painel (ponto de partida)
    private val lockedGroups = HashMap<String, Set<String>>()   // kind -> nomes
    private var lockedChannels: Set<String> = emptySet()        // chaves dos canais

    fun setLockedGroups(kind: String, names: Collection<String>) { lockedGroups[kind] = names.toSet() }
    fun lockedGroupsOf(kind: String): Set<String> = lockedGroups[kind] ?: emptySet()
    fun lockedChannelKeys(): Set<String> = lockedChannels
    fun setLockedChannels(keys: Collection<String>) { lockedChannels = keys.toSet() }

    // ---- Escolhas do cliente (neste aparelho é o cliente que manda) ----
    private var clientActive = false                             // já personalizou?
    private var autoAdult = true                                 // pedir PIN nos adultos
    private val clientGroups = HashMap<String, MutableSet<String>>()
    private var clientChannels = mutableSetOf<String>()
    private val KINDS = listOf("live", "vod", "series")

    /** Lê as escolhas do cliente para a memória (chamado no arranque e depois do login). */
    fun loadClient(c: Context) {
        val p = prefs(c)
        clientActive = p.getBoolean("cActive", false)
        autoAdult = p.getBoolean("cAuto", true)
        clientChannels = (p.getStringSet("cCh", emptySet()) ?: emptySet()).toMutableSet()
        KINDS.forEach { k -> clientGroups[k] = (p.getStringSet("cg_$k", emptySet()) ?: emptySet()).toMutableSet() }
    }

    private fun saveClient(c: Context) {
        val e = prefs(c).edit()
        e.putBoolean("cActive", clientActive).putBoolean("cAuto", autoAdult)
        e.putStringSet("cCh", HashSet(clientChannels))
        KINDS.forEach { k -> e.putStringSet("cg_$k", HashSet(clientGroups[k] ?: emptySet())) }
        e.apply()
    }

    /** Na primeira vez que o cliente mexe nas definições, copia o que o painel tinha como ponto de partida. */
    private fun ensureSeeded(c: Context) {
        if (clientActive) return
        clientChannels = lockedChannels.toMutableSet()
        KINDS.forEach { k -> clientGroups[k] = (lockedGroups[k] ?: emptySet()).filterNot { isAdult(it) }.toMutableSet() }
        clientActive = true
        saveClient(c)
    }

    fun isAutoAdult() = autoAdult
    fun setAutoAdult(c: Context, on: Boolean) { ensureSeeded(c); autoAdult = on; saveClient(c) }

    /** Liga/desliga o PIN numa categoria (escolha do cliente). */
    fun setGroupLock(c: Context, kind: String, group: String, lock: Boolean) {
        ensureSeeded(c)
        val s = clientGroups.getOrPut(kind) { mutableSetOf() }
        if (lock) s.add(group) else s.remove(group)
        saveClient(c)
    }

    /** Liga/desliga o PIN num canal (escolha do cliente). */
    fun setChannelLock(c: Context, key: String, lock: Boolean) {
        ensureSeeded(c)
        if (lock) clientChannels.add(key) else clientChannels.remove(key)
        saveClient(c)
    }

    fun hasLock(kind: String, group: String): Boolean {
        if (autoAdult && isAdult(group)) return true
        return if (clientActive) clientGroups[kind]?.contains(group) == true
               else lockedGroups[kind]?.contains(group) == true
    }

    /** true se esta categoria está bloqueada agora. */
    fun locked(kind: String, group: String) = !unlocked && hasLock(kind, group)

    /** true se o canal (ou a categoria dele) está bloqueado agora. */
    fun channelLocked(c: Channel) = !unlocked && (channelHasOwnLock(c) || hasLock("live", c.group))

    fun channelHasOwnLock(c: Channel) =
        Api.channelKey(c) in (if (clientActive) clientChannels else lockedChannels)

    /** Canal de adultos / com PIN — independente de já ter sido desbloqueado nesta sessão. */
    fun isProtected(c: Channel): Boolean {
        if (autoAdult && isAdult(c.group)) return true
        val gLocked = if (clientActive) clientGroups["live"]?.contains(c.group) == true
                      else lockedGroups["live"]?.contains(c.group) == true
        return channelHasOwnLock(c) || gLocked
    }

    /**
     * É conteúdo de adultos — marcado no PAINEL (lockedGroups/lockedChannels vêm sempre do painel)
     * ou pelo nome. NÃO depende de o cliente ter tirado o PIN nas definições: mesmo que o cliente
     * desligue o PIN dos adultos, a app continua a SABER que é adultos.
     * Usado para nunca guardar um canal de adultos como "último canal".
     */
    fun isAdultContent(c: Channel): Boolean {
        if (isAdult(c.group)) return true
        if (c.group in (lockedGroups["live"] ?: emptySet())) return true
        if (Api.channelKey(c) in lockedChannels) return true
        return isProtected(c)   // além disso, qualquer bloqueio ativo do cliente
    }

    fun label(kind: String, group: String) = if (hasLock(kind, group) && !unlocked) "🔒 $group" else group

    private fun prefs(c: Context) = c.getSharedPreferences("parental", Context.MODE_PRIVATE)
    private fun hash(pin: String) = MessageDigest.getInstance("SHA-256")
        .digest(("eco|$pin").toByteArray()).joinToString("") { "%02x".format(it) }
    private fun hasPin(c: Context) = prefs(c).contains("pin")
    private fun check(c: Context, pin: String) = prefs(c).getString("pin", null) == hash(pin)
    /** Assistência à distância: apaga o PIN (o cliente cria outro na próxima vez). */
    fun clearPin(c: Context) { prefs(c).edit().remove("pin").apply(); unlocked = false }

    private fun setPin(c: Context, pin: String) = prefs(c).edit().putString("pin", hash(pin)).apply()

    private fun pinField(a: Activity, hint: String) = EditText(a).apply {
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        textSize = 22f
    }

    private fun wrap(a: Activity, vararg fields: EditText) = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        val p = (20 * a.resources.displayMetrics.density).toInt()
        setPadding(p, p / 2, p, 0)
        fields.forEach { addView(it) }
    }

    private fun AlertDialog.showWithKeyboard() {
        window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        show()
    }

    /** Pede o PIN (ou cria-o na primeira vez). Corre [onOk] se ficar desbloqueado. */
    fun ask(a: Activity, onOk: () -> Unit) {
        if (unlocked) { onOk(); return }
        if (!hasPin(a)) { create(a, onOk); return }
        val f = pinField(a, "PIN")
        val forgot = TextView(a).apply {
            text = "Esqueci-me do PIN"
            setTextColor(0xFF3DDC97.toInt()); textSize = 15f
            val p = (12 * a.resources.displayMetrics.density).toInt()
            setPadding(0, p, 0, p)
            isFocusable = true; isClickable = true
        }
        val box = wrap(a, f).apply { addView(forgot) }
        var dialog: AlertDialog? = null
        forgot.setOnClickListener { dialog?.dismiss(); recover(a, onOk) }
        val d = AlertDialog.Builder(a)
            .setTitle("🔒 Conteúdo protegido")
            .setMessage("Introduza o PIN para continuar.")
            .setView(box)
            .setPositiveButton("Desbloquear") { _, _ ->
                if (check(a, f.text.toString())) { unlocked = true; onOk() }
                else Toast.makeText(a, "PIN errado", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Alterar PIN") { _, _ -> change(a) }
            .setNegativeButton("Cancelar", null)
            .create()
        dialog = d
        d.showWithKeyboard()
    }

    /** PIN esquecido: o código de recuperação (definido no painel) apaga o PIN e deixa criar outro. */
    private fun recover(a: Activity, onOk: () -> Unit) {
        val f = EditText(a).apply {
            hint = "Código de recuperação"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            textSize = 18f
        }
        AlertDialog.Builder(a)
            .setTitle("Esqueci-me do PIN")
            .setMessage("Peça o código de recuperação a quem lhe forneceu a app.")
            .setView(wrap(a, f))
            .setPositiveButton("Confirmar") { _, _ ->
                val code = f.text.toString().trim()
                if (code.isEmpty()) return@setPositiveButton
                Thread {
                    val ok = try { Api.checkRecovery(code) } catch (e: Exception) { null }
                    a.runOnUiThread {
                        when (ok) {
                            true -> {
                                prefs(a).edit().remove("pin").apply()
                                Toast.makeText(a, "Código certo ✓ Crie um PIN novo.", Toast.LENGTH_LONG).show()
                                create(a, onOk)
                            }
                            false -> Toast.makeText(a, "Código errado", Toast.LENGTH_LONG).show()
                            null -> Toast.makeText(a, "Sem ligação. Tente outra vez.", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .setNegativeButton("Cancelar", null)
            .create().showWithKeyboard()
    }

    private fun create(a: Activity, onOk: (() -> Unit)?) {
        val f1 = pinField(a, "Novo PIN (4 a 8 números)")
        val f2 = pinField(a, "Repetir PIN")
        AlertDialog.Builder(a)
            .setTitle("🔒 Criar PIN para adultos")
            .setMessage("Este PIN vai ser pedido sempre que abrir as categorias de adultos.")
            .setView(wrap(a, f1, f2))
            .setPositiveButton("Guardar") { _, _ ->
                val p1 = f1.text.toString(); val p2 = f2.text.toString()
                when {
                    p1.length !in 4..8 -> Toast.makeText(a, "O PIN deve ter 4 a 8 números", Toast.LENGTH_LONG).show()
                    p1 != p2 -> Toast.makeText(a, "Os PIN não são iguais", Toast.LENGTH_LONG).show()
                    else -> {
                        setPin(a, p1)
                        Toast.makeText(a, "PIN guardado ✓", Toast.LENGTH_SHORT).show()
                        if (onOk != null) { unlocked = true; onOk() }
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .create().showWithKeyboard()
    }

    // ---- API pública de PIN para a página de Definições ----
    fun hasPinSet(c: Context) = hasPin(c)
    fun createPin(a: Activity, onOk: (() -> Unit)? = null) = create(a, onOk)
    fun changePin(a: Activity) = change(a)

    /** Remover o PIN (pede o PIN atual primeiro). */
    fun removePin(a: Activity, onDone: (() -> Unit)? = null) {
        if (!hasPin(a)) { onDone?.invoke(); return }
        val f = pinField(a, "PIN atual")
        AlertDialog.Builder(a)
            .setTitle("Remover PIN")
            .setMessage("Introduza o PIN atual para o remover.")
            .setView(wrap(a, f))
            .setPositiveButton("Remover") { _, _ ->
                if (check(a, f.text.toString())) {
                    prefs(a).edit().remove("pin").apply(); unlocked = false
                    Toast.makeText(a, "PIN removido ✓", Toast.LENGTH_SHORT).show()
                    onDone?.invoke()
                } else Toast.makeText(a, "PIN errado", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .create().showWithKeyboard()
    }

    private fun change(a: Activity) {
        val old = pinField(a, "PIN atual")
        AlertDialog.Builder(a)
            .setTitle("Alterar PIN")
            .setView(wrap(a, old))
            .setPositiveButton("Continuar") { _, _ ->
                if (check(a, old.text.toString())) create(a, null)
                else Toast.makeText(a, "PIN errado", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .create().showWithKeyboard()
    }
}
