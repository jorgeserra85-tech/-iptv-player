package pt.iptv.player

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Definições do cliente (neste aparelho é o cliente que manda):
 * - ligar/desligar o PIN nos canais de adultos;
 * - escolher outras categorias que pedem PIN;
 * - definir, alterar ou remover o PIN.
 */
class SettingsActivity : AppCompatActivity() {

    private val dens get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens).toInt()
    private lateinit var pinRow: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply {
            setBackgroundResource(R.drawable.bg_gradient)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        // Cabeçalho
        root.addView(TextView(this).apply {
            text = "⚙  Definições"
            setTextColor(0xFF3DDC97.toInt()); textSize = 24f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(note("Aqui é você que decide o que fica protegido por PIN neste aparelho."))

        // ---- PIN ----
        root.addView(section("🔐  Código PIN"))
        pinRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(pinRow)
        refreshPinRow()

        // ---- Adultos ----
        root.addView(section("🔞  Canais de adultos"))
        root.addView(check("Pedir PIN nos canais de adultos", Parental.isAutoAdult()) { on ->
            Parental.setAutoAdult(this, on)
            if (on) { Parental.unlocked = false; if (!Parental.hasPinSet(this)) Parental.createPin(this) }
        })
        root.addView(note("Liga ou desliga a proteção automática de todas as categorias de adultos (TV, filmes e séries)."))

        // ---- Outras categorias ----
        root.addView(section("📺  Outras categorias a pedir PIN"))
        val groups = MainActivity.channelsToShow.filter { !it.custom }
            .map { it.group }.filter { it.isNotBlank() && !Parental.isAdult(it) }.distinct()
        if (groups.isEmpty()) {
            root.addView(note("Sem categorias disponíveis. Entre numa conta para as ver aqui."))
        } else {
            root.addView(note("Marque as categorias que quer esconder atrás do PIN."))
            groups.forEach { g ->
                root.addView(check(g, Parental.hasLock("live", g)) { on ->
                    Parental.setGroupLock(this, "live", g, on)
                    if (on) { Parental.unlocked = false; if (!Parental.hasPinSet(this)) Parental.createPin(this) }
                })
            }
        }

        // Voltar
        root.addView(bigButton("‹  Voltar") { finish() }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = dp(20)
        })
    }

    private fun weighted(start: Int = 0) = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = start }

    private fun refreshPinRow() {
        pinRow.removeAllViews()
        val has = Parental.hasPinSet(this)
        pinRow.addView(bigButton(if (has) "Alterar PIN" else "Definir PIN") {
            if (has) Parental.changePin(this) else Parental.createPin(this) { }
            pinRow.postDelayed({ refreshPinRow() }, 300)
        }.apply { layoutParams = weighted() })
        if (has) pinRow.addView(bigButton("Remover PIN") {
            Parental.removePin(this) { refreshPinRow() }
        }.apply { layoutParams = weighted(dp(10)) })
    }

    // ---- Construtores de vistas ----
    private fun section(t: String) = TextView(this).apply {
        text = t
        setTextColor(0xFFFFFFFF.toInt()); textSize = 18f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        setTextColor(0xFF9FB3AA.toInt()); textSize = 14f
        setPadding(0, dp(2), 0, dp(4))
    }

    private fun check(text: String, on: Boolean, onChange: (Boolean) -> Unit) = CheckBox(this).apply {
        this.text = text
        setTextColor(0xFFFFFFFF.toInt()); textSize = 17f
        isChecked = on
        setPadding(dp(8), dp(10), dp(8), dp(10))
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    private fun bigButton(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setBackgroundResource(R.drawable.button_bg)
        setTextColor(0xFF08150F.toInt())
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        textSize = 16f
        stateListAnimator = null
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(48))
        setOnClickListener { onClick() }
    }
}
