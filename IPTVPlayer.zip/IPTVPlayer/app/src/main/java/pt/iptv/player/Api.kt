package pt.iptv.player

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Sessão atual (servidor + conta do cliente), usada pelo guia e gravações. */
object Session {
    var server = ""; var user = ""; var pass = ""
    var title = ""; var sub = ""
    var providerId = 0L
    var expIso = ""      // validade da conta (dd/MM/aaaa)
}

// ---------- Filmes e séries ----------
data class VodItem(
    val id: String, val name: String, val cover: String?, val category: String,
    val rating: Double, val ext: String, val added: Long, val series: Boolean,
    val plot: String = "", val year: String = ""
)

data class VodInfo(
    val title: String, val plot: String, val cast: String, val director: String, val genre: String,
    val year: String, val duration: String, val rating: Double, val cover: String?, val backdrop: String?
)

data class Episode(
    val id: String, val season: Int, val num: Int, val title: String, val ext: String,
    val plot: String, val duration: String, val image: String?
)

data class Programme(
    val title: String, val desc: String,
    val start: Long, val end: Long,      // segundos (epoch)
    val startRaw: String,                // hora do servidor, ex. "2026-10-27 10:00:00"
    val hasArchive: Boolean
)

data class Provider(val id: Long, val name: String, val serverUrl: String) {
    override fun toString() = name
}

data class Profile(val label: String, val providerId: Long, val providerName: String,
                   val user: String, val pass: String) {
    fun toJson() = JSONObject().put("label", label).put("pid", providerId)
        .put("pname", providerName).put("user", user).put("pass", pass)
    companion object {
        fun fromJson(o: JSONObject) = Profile(o.optString("label"), o.optLong("pid"),
            o.optString("pname"), o.optString("user"), o.optString("pass"))
    }
}

object Api {
    private fun get(url: String, headers: Map<String, String> = emptyMap()): String {
        var target = url
        repeat(5) {
            val c = URL(target).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "IPTVPlayer/1.0 (Android)")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val code = c.responseCode
            if (code in 300..399) {
                target = URL(URL(target), c.getHeaderField("Location")).toString(); c.disconnect(); return@repeat
            }
            if (code !in 200..299) error("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        }
        error("Demasiados redirecionamentos")
    }

    private fun post(url: String, body: String, headers: Map<String, String>) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        c.disconnect()
        if (code !in 200..299) error("HTTP $code")
    }

    /** Pergunta ao painel se o código de recuperação do PIN está certo (o código nunca sai do servidor). */
    fun checkRecovery(code: String): Boolean {
        val c = URL("${Config.SUPABASE_URL}/rest/v1/rpc/check_recovery").openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 15000
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("apikey", Config.SUPABASE_KEY)
        c.outputStream.use { it.write(JSONObject().put("code", code).toString().toByteArray(Charsets.UTF_8)) }
        if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }.trim() == "true"
    }

    private val sbHeaders get() = mapOf("apikey" to Config.SUPABASE_KEY, "Accept" to "application/json")

    /**
     * Aplica a organização de grupos feita no painel (ordem, esconder, novo nome).
     * Grupos novos são registados automaticamente para aparecerem no painel.
     */
    data class GroupConf(val position: Int, val hidden: Boolean, val rename: String?, val locked: Boolean)

    /**
     * Lê a organização de categorias do painel (kind = live / vod / series) e regista as que faltam.
     * As novas que parecem de adultos já ficam com PIN. Devolve null se o painel não responder.
     */
    fun groupSettings(providerId: Long, kind: String, names: List<String>): Map<String, GroupConf>? {
        val settings = LinkedHashMap<String, GroupConf>()
        try {
            val arr = JSONArray(get("${Config.SUPABASE_URL}/rest/v1/group_settings?provider_id=eq.$providerId&kind=eq.$kind" +
                    "&select=name,position,hidden,rename,locked&limit=5000", sbHeaders))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                settings[o.getString("name")] = GroupConf(o.optInt("position"), o.optBoolean("hidden"),
                    if (o.isNull("rename")) null else o.optString("rename").takeIf { it.isNotBlank() },
                    o.optBoolean("locked"))
            }
        } catch (e: Exception) { return null }

        val missing = names.distinct().filter { it !in settings }
        if (missing.isNotEmpty()) try {
            val base = (settings.values.maxOfOrNull { it.position } ?: -1) + 1
            val body = JSONArray()
            missing.forEachIndexed { i, g ->
                val adult = Parental.isAdult(g)
                body.put(JSONObject().put("provider_id", providerId).put("kind", kind).put("name", g.take(200))
                    .put("position", base + i).put("locked", adult))
                settings[g] = GroupConf(base + i, false, null, adult)
            }
            post("${Config.SUPABASE_URL}/rest/v1/group_settings?on_conflict=provider_id,kind,name", body.toString(),
                sbHeaders + mapOf("Prefer" to "resolution=ignore-duplicates,return=minimal"))
        } catch (_: Exception) {}
        return settings
    }

    /** Aplica a organização das categorias de TV feita no painel (ordem, esconder, nome, PIN). */
    fun applyGroupSettings(providerId: Long, channels: List<Channel>): List<Channel> {
        val serverOrder = channels.map { it.group }.distinct()
        val settings = groupSettings(providerId, "live", serverOrder)
        if (settings == null) {   // painel sem resposta: PIN automático pelo nome
            Parental.setLockedGroups("live", serverOrder.filter { Parental.isAdult(it) })
            return channels
        }
        Parental.setLockedGroups("live", settings.filter { it.value.locked }.map { it.value.rename ?: it.key })
        val orderIndex = serverOrder.withIndex().associate { it.value to it.index }
        return channels
            .filter { settings[it.group]?.hidden != true }
            .sortedWith(compareBy({ settings[it.group]?.position ?: Int.MAX_VALUE }, { orderIndex[it.group] ?: 0 }))
            .map { ch -> settings[ch.group]?.rename?.let { ch.copy(group = it) } ?: ch }
    }

    /** Aplica a organização das categorias de filmes/séries (ordem, esconder, nome, PIN). Devolve (itens, ordem das categorias). */
    fun applyVodGroups(kind: String, items: List<VodItem>, catOrder: List<String>): Pair<List<VodItem>, List<String>> {
        val names = (catOrder.filter { c -> items.any { it.category == c } } + items.map { it.category }).distinct()
        val settings = if (Session.providerId > 0) groupSettings(Session.providerId, kind, names) else null
        if (settings == null) {
            Parental.setLockedGroups(kind, names.filter { Parental.isAdult(it) })
            return items to names
        }
        Parental.setLockedGroups(kind, settings.filter { it.value.locked }.map { it.value.rename ?: it.key })
        val order = names.filter { settings[it]?.hidden != true }
            .sortedBy { settings[it]?.position ?: Int.MAX_VALUE }
            .map { settings[it]?.rename ?: it }.distinct()
        val out = items.filter { settings[it.category]?.hidden != true }
            .map { v -> settings[v.category]?.rename?.let { v.copy(category = it) } ?: v }
        return out to order
    }

    fun channelKey(c: Channel) = c.streamId ?: c.url

    /** Envia a lista de canais do servidor para o painel (só quando mudou). Devolve o "hash" enviado. */
    fun uploadChannelList(providerId: Long, channels: List<Channel>, lastHash: String?): String? {
        val arr = JSONArray()
        channels.forEach { c ->
            arr.put(JSONObject().put("k", channelKey(c)).put("n", c.name).put("g", c.group).apply { c.logo?.let { put("l", it) } })
        }
        val hash = arr.toString().hashCode().toString()
        if (hash == lastHash) return hash
        return try {
            val body = JSONObject().put("provider_id", providerId).put("data", arr)
                .put("updated_at", java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
                    .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.format(java.util.Date()))
            post("${Config.SUPABASE_URL}/rest/v1/provider_channels?on_conflict=provider_id", body.toString(),
                sbHeaders + mapOf("Prefer" to "resolution=merge-duplicates,return=minimal"))
            hash
        } catch (e: Exception) { lastHash }
    }

    /** Aplica a organização de canais feita no painel (ordem dentro do grupo, esconder, novo nome). */
    fun applyChannelSettings(providerId: Long, channels: List<Channel>): List<Channel> {
        data class C(val position: Int?, val hidden: Boolean, val rename: String?, val locked: Boolean)
        val settings = HashMap<String, C>()
        try {
            var offset = 0
            while (true) {
                val arr = JSONArray(get("${Config.SUPABASE_URL}/rest/v1/channel_settings?provider_id=eq.$providerId" +
                        "&select=channel_key,position,hidden,rename,locked&order=id&limit=1000&offset=$offset", sbHeaders))
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    settings[o.getString("channel_key")] = C(
                        if (o.isNull("position")) null else o.optInt("position"),
                        o.optBoolean("hidden"),
                        if (o.isNull("rename")) null else o.optString("rename").takeIf { it.isNotBlank() },
                        o.optBoolean("locked"))
                }
                if (arr.length() < 1000) break
                offset += 1000
            }
        } catch (e: Exception) { return channels }
        Parental.setLockedChannels(settings.filter { it.value.locked }.keys)
        if (settings.isEmpty()) return channels

        val groupFirst = HashMap<String, Int>()
        channels.forEachIndexed { i, c -> groupFirst.putIfAbsent(c.group, i) }
        return channels.withIndex()
            .filter { settings[channelKey(it.value)]?.hidden != true }
            .sortedWith(compareBy(
                { groupFirst[it.value.group] ?: 0 },
                { settings[channelKey(it.value)]?.position ?: Int.MAX_VALUE },
                { it.index }))
            .map { iv -> settings[channelKey(iv.value)]?.rename?.let { iv.value.copy(name = it) } ?: iv.value }
    }

    // ---------- Painel (Supabase) ----------
    fun providers(): List<Provider> {
        val url = "${Config.SUPABASE_URL}/rest/v1/providers?select=id,name,server_url&active=eq.true&order=position.asc,name.asc"
        val arr = JSONArray(get(url, mapOf("apikey" to Config.SUPABASE_KEY, "Accept" to "application/json")))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Provider(o.getLong("id"), o.getString("name"), o.getString("server_url"))
        }
    }

    fun provider(id: Long): Provider = providers().firstOrNull { it.id == id }
        ?: error("Este servidor já não está disponível")

    // ---------- Xtream Codes ----------
    /**
     * Endereço base do servidor Xtream (http://servidor:porta). Limpa restos que às vezes vêm
     * colados, como /get.php?..., /player_api.php, /c/ ou /live/...
     */
    fun base(server: String): String {
        var s = server.trim()
        if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "http://$s"
        s = s.substringBefore('?').substringBefore('#')
        val cut = Regex("/(get\\.php|player_api\\.php|xmltv\\.php|panel_api\\.php|c/|live/|movie/|series/).*$", RegexOption.IGNORE_CASE)
        s = s.replace(cut, "")
        return s.trimEnd('/')
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun playerApi(server: String, user: String, pass: String, action: String? = null): String {
        val a = if (action != null) "&action=$action" else ""
        return get("${base(server)}/player_api.php?username=${enc(user)}&password=${enc(pass)}$a")
    }

    /** Devolve a data de validade (texto) ou lança erro se o login falhar. */
    fun login(server: String, user: String, pass: String): String? {
        val txt = try { playerApi(server, user, pass) } catch (e: Exception) {
            val m = e.message ?: ""
            // alguns servidores respondem 401/403/404 quando o utilizador ou a palavra-passe estão errados
            if (Regex("HTTP (401|403|404|512|884)").containsMatchIn(m))
                error("Utilizador ou palavra-passe errados (ou conta sem acesso a este servidor)")
            error("Não foi possível contactar o servidor ($m)")
        }
        val o = try { JSONObject(txt) } catch (e: Exception) { error("Resposta inválida do servidor") }
        val info = o.optJSONObject("user_info") ?: error("Utilizador ou palavra-passe errados")
        if (info.optInt("auth", 0) != 1) error("Utilizador ou palavra-passe errados")
        val status = info.optString("status", "Active")
        if (!status.equals("Active", true)) error("Conta $status")
        val exp = info.optString("exp_date", "").toLongOrNull()
        return exp?.let {
            java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(it * 1000))
        }
    }

    fun liveChannels(server: String, user: String, pass: String): List<Channel> {
        val cats = HashMap<String, String>()
        try {
            val ca = JSONArray(playerApi(server, user, pass, "get_live_categories"))
            for (i in 0 until ca.length()) {
                val o = ca.getJSONObject(i)
                cats[o.optString("category_id")] = o.optString("category_name")
            }
        } catch (_: Exception) {}
        val arr = JSONArray(playerApi(server, user, pass, "get_live_streams"))
        val b = base(server)
        val out = ArrayList<Channel>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("stream_id"); if (id.isEmpty()) continue
            out += Channel(
                name = o.optString("name").ifBlank { "Canal $id" },
                url = "$b/live/${enc(user)}/${enc(pass)}/$id.ts",
                group = cats[o.optString("category_id")] ?: "Sem grupo",
                logo = o.optString("stream_icon").takeIf { it.startsWith("http") },
                streamId = id,
                archive = o.optString("tv_archive") == "1",
                archiveDays = o.optString("tv_archive_duration").toIntOrNull() ?: 0
            )
        }
        return out
    }

    // ---------- Guia (EPG) e gravações ----------
    private fun b64(s: String): String {
        if (s.isBlank()) return s
        return try {
            val d = String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8)
            if (d.isBlank() || d.contains('\uFFFD')) s else d
        } catch (e: Exception) { s }
    }

    private fun parseListings(txt: String): List<Programme> {
        val o = try { JSONObject(txt) } catch (e: Exception) { return emptyList() }
        val arr = o.optJSONArray("epg_listings") ?: return emptyList()
        val out = ArrayList<Programme>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val st = e.optString("start_timestamp").toLongOrNull() ?: continue
            val en = e.optString("stop_timestamp").toLongOrNull() ?: continue
            out += Programme(
                title = b64(e.optString("title")).trim().ifBlank { "Sem título" },
                desc = b64(e.optString("description")).trim(),
                start = st, end = en,
                startRaw = e.optString("start"),
                hasArchive = e.optString("has_archive") == "1"
            )
        }
        return out.distinctBy { it.start }.sortedBy { it.start }
    }

    /** Programação completa do canal (passada + futura). */
    fun epg(streamId: String): List<Programme> {
        val full = try {
            parseListings(playerApi(Session.server, Session.user, Session.pass, "get_simple_data_table&stream_id=$streamId"))
        } catch (e: Exception) { emptyList() }
        if (full.isNotEmpty()) return full
        return try {
            parseListings(playerApi(Session.server, Session.user, Session.pass, "get_short_epg&stream_id=$streamId&limit=50"))
        } catch (e: Exception) { emptyList() }
    }

    /** Programa de agora e o seguinte (para o guia "Agora / A seguir"). */
    fun nowNext(streamId: String): Pair<Programme?, Programme?> {
        val now = System.currentTimeMillis() / 1000
        val list = try {
            parseListings(playerApi(Session.server, Session.user, Session.pass, "get_short_epg&stream_id=$streamId&limit=4"))
        } catch (e: Exception) { emptyList() }
        val upcoming = list.filter { it.end > now }
        val cur = upcoming.firstOrNull { it.start <= now }
        val next = upcoming.firstOrNull { it.start > now }
        return cur to next
    }

    /** Programa que está a dar agora (ou null). */
    fun nowPlaying(streamId: String): Programme? {
        val now = System.currentTimeMillis() / 1000
        val list = try {
            parseListings(playerApi(Session.server, Session.user, Session.pass, "get_short_epg&stream_id=$streamId&limit=2"))
        } catch (e: Exception) { emptyList() }
        return list.firstOrNull { it.start <= now && it.end > now }
    }

    /** Endereços possíveis para ver uma gravação (catch-up / timeshift). */
    fun catchupUrls(streamId: String, p: Programme): List<String> {
        val b = base(Session.server); val u = enc(Session.user); val pw = enc(Session.pass)
        val dur = ((p.end - p.start) / 60).coerceAtLeast(1)
        val st = if (p.startRaw.length >= 16)
            p.startRaw.take(10) + ":" + p.startRaw.substring(11, 16).replace(':', '-')
        else java.text.SimpleDateFormat("yyyy-MM-dd:HH-mm", java.util.Locale.US).format(java.util.Date(p.start * 1000))
        return listOf(
            "$b/timeshift/$u/$pw/$dur/$st/$streamId.ts",
            "$b/timeshift/$u/$pw/$dur/$st/$streamId.m3u8",
            "$b/streaming/timeshift.php?username=$u&password=$pw&stream=$streamId&start=$st&duration=$dur"
        )
    }

    // ---------- Filmes e séries (Xtream) ----------
    private fun api(action: String) = playerApi(Session.server, Session.user, Session.pass, action)
    private fun img(s: String?) = s?.trim()?.takeIf { it.startsWith("http") }
    private fun num(o: JSONObject, k: String) = o.optString(k).replace(',', '.').toDoubleOrNull() ?: 0.0
    private fun str(o: JSONObject, vararg keys: String): String {
        for (k in keys) { val v = o.optString(k); if (v.isNotBlank() && v != "null") return v.trim() }
        return ""
    }

    fun vodCategories(series: Boolean): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        try {
            val a = JSONArray(api(if (series) "get_series_categories" else "get_vod_categories"))
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                m[o.optString("category_id")] = o.optString("category_name")
            }
        } catch (_: Exception) {}
        return m
    }

    fun movies(cats: Map<String, String>): List<VodItem> {
        val a = JSONArray(api("get_vod_streams"))
        val out = ArrayList<VodItem>(a.length())
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("stream_id"); if (id.isEmpty()) continue
            out += VodItem(id, str(o, "name", "title").ifBlank { "Filme $id" }, img(o.optString("stream_icon")),
                cats[o.optString("category_id")] ?: "Sem categoria", num(o, "rating"),
                str(o, "container_extension").ifBlank { "mp4" }, o.optString("added").toLongOrNull() ?: 0L,
                series = false, year = str(o, "year"))
        }
        return out
    }

    fun seriesList(cats: Map<String, String>): List<VodItem> {
        val a = JSONArray(api("get_series"))
        val out = ArrayList<VodItem>(a.length())
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("series_id"); if (id.isEmpty()) continue
            out += VodItem(id, str(o, "name", "title").ifBlank { "Série $id" }, img(o.optString("cover")),
                cats[o.optString("category_id")] ?: "Sem categoria", num(o, "rating"), "",
                o.optString("last_modified").toLongOrNull() ?: 0L, series = true,
                plot = str(o, "plot"), year = str(o, "releaseDate", "release_date", "year").take(4))
        }
        return out
    }

    private fun parseInfo(i: JSONObject, fallbackTitle: String): VodInfo {
        val backdrop = i.optJSONArray("backdrop_path")?.optString(0) ?: i.optString("backdrop_path")
        return VodInfo(
            title = str(i, "name", "title", "o_name").ifBlank { fallbackTitle },
            plot = str(i, "plot", "description"),
            cast = str(i, "cast", "actors"),
            director = str(i, "director"),
            genre = str(i, "genre"),
            year = str(i, "releasedate", "releaseDate", "release_date", "year").take(4),
            duration = str(i, "duration"),
            rating = num(i, "rating"),
            cover = img(i.optString("movie_image")) ?: img(i.optString("cover_big")) ?: img(i.optString("cover")),
            backdrop = img(backdrop)
        )
    }

    fun movieInfo(item: VodItem): VodInfo? = try {
        val o = JSONObject(api("get_vod_info&vod_id=${item.id}"))
        parseInfo(o.optJSONObject("info") ?: JSONObject(), item.name)
    } catch (e: Exception) { null }

    fun seriesInfo(item: VodItem): Pair<VodInfo, java.util.TreeMap<Int, MutableList<Episode>>> {
        val o = JSONObject(api("get_series_info&series_id=${item.id}"))
        val info = parseInfo(o.optJSONObject("info") ?: JSONObject(), item.name)
        val seasons = java.util.TreeMap<Int, MutableList<Episode>>()
        fun add(e: JSONObject, seasonKey: Int) {
            val ei = e.optJSONObject("info") ?: JSONObject()
            val sn = e.optString("season").toIntOrNull() ?: seasonKey
            seasons.getOrPut(sn) { mutableListOf() }.add(Episode(
                id = e.optString("id"), season = sn,
                num = e.optString("episode_num").toIntOrNull() ?: 0,
                title = str(e, "title").ifBlank { "Episódio ${e.optString("episode_num")}" },
                ext = str(e, "container_extension").ifBlank { "mp4" },
                plot = str(ei, "plot", "description"), duration = str(ei, "duration"),
                image = img(ei.optString("movie_image")) ?: img(ei.optString("cover_big"))
            ))
        }
        when (val eps = o.opt("episodes")) {
            is JSONObject -> eps.keys().forEach { k ->
                val arr = eps.optJSONArray(k) ?: return@forEach
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { add(it, k.toIntOrNull() ?: 0) }
            }
            is JSONArray -> for (i in 0 until eps.length()) {
                when (val x = eps.opt(i)) {
                    is JSONArray -> for (j in 0 until x.length()) x.optJSONObject(j)?.let { add(it, i + 1) }
                    is JSONObject -> add(x, 0)
                }
            }
        }
        seasons.values.forEach { l -> l.sortBy { it.num } }
        return info to seasons
    }

    fun movieUrl(item: VodItem) =
        "${base(Session.server)}/movie/${enc(Session.user)}/${enc(Session.pass)}/${item.id}.${item.ext}"

    fun episodeUrl(e: Episode) =
        "${base(Session.server)}/series/${enc(Session.user)}/${enc(Session.pass)}/${e.id}.${e.ext}"
}
