package pt.iptv.player

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Sessão atual (servidor + conta do cliente), usada pelo guia e gravações. */
object Session {
    var server = ""; var user = ""; var pass = ""
}

data class Programme(
    val title: String, val desc: String,
    val start: Long, val end: Long,      // segundos (epoch)
    val startRaw: String,                // hora do servidor, ex. "2026-10-27 10:00:00"
    val hasArchive: Boolean
)

data class Provider(val id: Long, val name: String, val serverUrl: String) {
    override fun toString() = name
}

data class Profile(val label: String, val providerId: Long, val providerName: String,
                   val user: String, val pass: String) {
    fun toJson() = JSONObject().put("label", label).put("pid", providerId)
        .put("pname", providerName).put("user", user).put("pass", pass)
    companion object {
        fun fromJson(o: JSONObject) = Profile(o.optString("label"), o.optLong("pid"),
            o.optString("pname"), o.optString("user"), o.optString("pass"))
    }
}

object Api {
    private fun get(url: String, headers: Map<String, String> = emptyMap()): String {
        var target = url
        repeat(5) {
            val c = URL(target).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "IPTVPlayer/1.0 (Android)")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val code = c.responseCode
            if (code in 300..399) {
                target = URL(URL(target), c.getHeaderField("Location")).toString(); c.disconnect(); return@repeat
            }
            if (code !in 200..299) error("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        }
        error("Demasiados redirecionamentos")
    }

    private fun post(url: String, body: String, headers: Map<String, String>) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        c.disconnect()
        if (code !in 200..299) error("HTTP $code")
    }

    private val sbHeaders get() = mapOf("apikey" to Config.SUPABASE_KEY, "Accept" to "application/json")

    /**
     * Aplica a organização de grupos feita no painel (ordem, esconder, novo nome).
     * Grupos novos são registados automaticamente para aparecerem no painel.
     */
    fun applyGroupSettings(providerId: Long, channels: List<Channel>): List<Channel> {
        data class G(val position: Int, val hidden: Boolean, val rename: String?)
        val settings = HashMap<String, G>()
        try {
            val arr = JSONArray(get("${Config.SUPABASE_URL}/rest/v1/group_settings?provider_id=eq.$providerId&select=name,position,hidden,rename", sbHeaders))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                settings[o.getString("name")] = G(o.optInt("position"), o.optBoolean("hidden"),
                    o.optString("rename").takeIf { !o.isNull("rename") && it.isNotBlank() })
            }
        } catch (e: Exception) { return channels }      // sem tabela/ligação: fica como vem do servidor

        val serverOrder = channels.map { it.group }.distinct()
        val missing = serverOrder.filter { it !in settings }
        if (missing.isNotEmpty()) try {
            val base = (settings.values.maxOfOrNull { it.position } ?: -1) + 1
            val body = JSONArray()
            missing.forEachIndexed { i, g ->
                body.put(JSONObject().put("provider_id", providerId).put("name", g.take(200)).put("position", base + i))
                settings[g] = G(base + i, false, null)
            }
            post("${Config.SUPABASE_URL}/rest/v1/group_settings?on_conflict=provider_id,name", body.toString(),
                sbHeaders + mapOf("Prefer" to "resolution=ignore-duplicates,return=minimal"))
        } catch (_: Exception) {}

        val orderIndex = serverOrder.withIndex().associate { it.value to it.index }
        return channels
            .filter { settings[it.group]?.hidden != true }
            .sortedWith(compareBy({ settings[it.group]?.position ?: Int.MAX_VALUE }, { orderIndex[it.group] ?: 0 }))
            .map { ch -> settings[ch.group]?.rename?.let { ch.copy(group = it) } ?: ch }
    }

    // ---------- Painel (Supabase) ----------
    fun providers(): List<Provider> {
        val url = "${Config.SUPABASE_URL}/rest/v1/providers?select=id,name,server_url&active=eq.true&order=position.asc,name.asc"
        val arr = JSONArray(get(url, mapOf("apikey" to Config.SUPABASE_KEY, "Accept" to "application/json")))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Provider(o.getLong("id"), o.getString("name"), o.getString("server_url"))
        }
    }

    fun provider(id: Long): Provider = providers().firstOrNull { it.id == id }
        ?: error("Este servidor já não está disponível")

    // ---------- Xtream Codes ----------
    fun base(server: String): String {
        var s = server.trim().trimEnd('/')
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        return s
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun playerApi(server: String, user: String, pass: String, action: String? = null): String {
        val a = if (action != null) "&action=$action" else ""
        return get("${base(server)}/player_api.php?username=${enc(user)}&password=${enc(pass)}$a")
    }

    /** Devolve a data de validade (texto) ou lança erro se o login falhar. */
    fun login(server: String, user: String, pass: String): String? {
        val txt = try { playerApi(server, user, pass) } catch (e: Exception) {
            error("Não foi possível contactar o servidor (${e.message})")
        }
        val o = try { JSONObject(txt) } catch (e: Exception) { error("Resposta inválida do servidor") }
        val info = o.optJSONObject("user_info") ?: error("Utilizador ou palavra-passe errados")
        if (info.optInt("auth", 0) != 1) error("Utilizador ou palavra-passe errados")
        val status = info.optString("status", "Active")
        if (!status.equals("Active", true)) error("Conta $status")
        val exp = info.optString("exp_date", "").toLongOrNull()
        return exp?.let {
            java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(it * 1000))
        }
    }

    fun liveChannels(server: String, user: String, pass: String): List<Channel> {
        val cats = HashMap<String, String>()
        try {
            val ca = JSONArray(playerApi(server, user, pass, "get_live_categories"))
            for (i in 0 until ca.length()) {
                val o = ca.getJSONObject(i)
                cats[o.optString("category_id")] = o.optString("category_name")
            }
        } catch (_: Exception) {}
        val arr = JSONArray(playerApi(server, user, pass, "get_live_streams"))
        val b = base(server)
        val out = ArrayList<Channel>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("stream_id"); if (id.isEmpty()) continue
            out += Channel(
                name = o.optString("name").ifBlank { "Canal $id" },
                url = "$b/live/${enc(user)}/${enc(pass)}/$id.ts",
                group = cats[o.optString("category_id")] ?: "Sem grupo",
                logo = o.optString("stream_icon").takeIf { it.startsWith("http") },
                streamId = id,
                archive = o.optString("tv_archive") == "1",
                archiveDays = o.optString("tv_archive_duration").toIntOrNull() ?: 0
            )
        }
        return out
    }

    // ---------- Guia (EPG) e gravações ----------
    private fun b64(s: String): String {
        if (s.isBlank()) return s
        return try {
            val d = String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8)
            if (d.isBlank() || d.contains('\uFFFD')) s else d
        } catch (e: Exception) { s }
    }

    private fun parseListings(txt: String): List<Programme> {
        val o = try { JSONObject(txt) } catch (e: Exception) { return emptyList() }
        val arr = o.optJSONArray("epg_listings") ?: return emptyList()
        val out = ArrayList<Programme>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val st = e.optString("start_timestamp").toLongOrNull() ?: continue
            val en = e.optString("stop_timestamp").toLongOrNull() ?: continue
            out += Programme(
                title = b64(e.optString("title")).trim().ifBlank { "Sem título" },
                desc = b64(e.optString("description")).trim(),
                start = st, end = en,
                startRaw = e.optString("start"),
                hasArchive = e.optString("has_archive") == "1"
            )
        }
        return out.distinctBy { it.start }.sortedBy { it.start }
    }

    /** Programação completa do canal (passada + futura). */
    fun epg(streamId: String): List<Programme> {
        val full = try {
            parseListings(playerApi(Session.server, Session.user, Session.pass, "get_simple_data_table&stream_id=$streamId"))
        } catch (e: Exception) { emptyList() }
        if (full.isNotEmpty()) return full
        return try {
            parseListings(playerApi(Session.server, Session.user, Session.pass, "get_short_epg&stream_id=$streamId&limit=50"))
        } catch (e: Exception) { emptyList() }
    }

    /** Programa que está a dar agora (ou null). */
    fun nowPlaying(streamId: String): Programme? {
        val now = System.currentTimeMillis() / 1000
        val list = try {
            parseListings(playerApi(Session.server, Session.user, Session.pass, "get_short_epg&stream_id=$streamId&limit=2"))
        } catch (e: Exception) { emptyList() }
        return list.firstOrNull { it.start <= now && it.end > now }
    }

    /** Endereços possíveis para ver uma gravação (catch-up / timeshift). */
    fun catchupUrls(streamId: String, p: Programme): List<String> {
        val b = base(Session.server); val u = enc(Session.user); val pw = enc(Session.pass)
        val dur = ((p.end - p.start) / 60).coerceAtLeast(1)
        val st = if (p.startRaw.length >= 16)
            p.startRaw.take(10) + ":" + p.startRaw.substring(11, 16).replace(':', '-')
        else java.text.SimpleDateFormat("yyyy-MM-dd:HH-mm", java.util.Locale.US).format(java.util.Date(p.start * 1000))
        return listOf(
            "$b/timeshift/$u/$pw/$dur/$st/$streamId.ts",
            "$b/timeshift/$u/$pw/$dur/$st/$streamId.m3u8",
            "$b/streaming/timeshift.php?username=$u&password=$pw&stream=$streamId&start=$st&duration=$dur"
        )
    }
}
