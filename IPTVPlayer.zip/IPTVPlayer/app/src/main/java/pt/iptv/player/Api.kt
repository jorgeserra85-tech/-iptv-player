package pt.iptv.player

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Provider(val id: Long, val name: String, val serverUrl: String) {
    override fun toString() = name
}

data class Profile(val label: String, val providerId: Long, val providerName: String,
                   val user: String, val pass: String) {
    fun toJson() = JSONObject().put("label", label).put("pid", providerId)
        .put("pname", providerName).put("user", user).put("pass", pass)
    companion object {
        fun fromJson(o: JSONObject) = Profile(o.optString("label"), o.optLong("pid"),
            o.optString("pname"), o.optString("user"), o.optString("pass"))
    }
}

object Api {
    private fun get(url: String, headers: Map<String, String> = emptyMap()): String {
        var target = url
        repeat(5) {
            val c = URL(target).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "IPTVPlayer/1.0 (Android)")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val code = c.responseCode
            if (code in 300..399) {
                target = URL(URL(target), c.getHeaderField("Location")).toString(); c.disconnect(); return@repeat
            }
            if (code !in 200..299) error("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        }
        error("Demasiados redirecionamentos")
    }

    // ---------- Painel (Supabase) ----------
    fun providers(): List<Provider> {
        val url = "${Config.SUPABASE_URL}/rest/v1/providers?select=id,name,server_url&active=eq.true&order=position.asc,name.asc"
        val arr = JSONArray(get(url, mapOf("apikey" to Config.SUPABASE_KEY, "Accept" to "application/json")))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Provider(o.getLong("id"), o.getString("name"), o.getString("server_url"))
        }
    }

    fun provider(id: Long): Provider = providers().firstOrNull { it.id == id }
        ?: error("Este fornecedor já não está disponível")

    // ---------- Xtream Codes ----------
    fun base(server: String): String {
        var s = server.trim().trimEnd('/')
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        return s
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun playerApi(server: String, user: String, pass: String, action: String? = null): String {
        val a = if (action != null) "&action=$action" else ""
        return get("${base(server)}/player_api.php?username=${enc(user)}&password=${enc(pass)}$a")
    }

    /** Devolve a data de validade (texto) ou lança erro se o login falhar. */
    fun login(server: String, user: String, pass: String): String? {
        val txt = try { playerApi(server, user, pass) } catch (e: Exception) {
            error("Não foi possível contactar o fornecedor (${e.message})")
        }
        val o = try { JSONObject(txt) } catch (e: Exception) { error("Resposta inválida do fornecedor") }
        val info = o.optJSONObject("user_info") ?: error("Utilizador ou palavra-passe errados")
        if (info.optInt("auth", 0) != 1) error("Utilizador ou palavra-passe errados")
        val status = info.optString("status", "Active")
        if (!status.equals("Active", true)) error("Conta $status")
        val exp = info.optString("exp_date", "").toLongOrNull()
        return exp?.let {
            java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(it * 1000))
        }
    }

    fun liveChannels(server: String, user: String, pass: String): List<Channel> {
        val cats = HashMap<String, String>()
        try {
            val ca = JSONArray(playerApi(server, user, pass, "get_live_categories"))
            for (i in 0 until ca.length()) {
                val o = ca.getJSONObject(i)
                cats[o.optString("category_id")] = o.optString("category_name")
            }
        } catch (_: Exception) {}
        val arr = JSONArray(playerApi(server, user, pass, "get_live_streams"))
        val b = base(server)
        val out = ArrayList<Channel>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("stream_id"); if (id.isEmpty()) continue
            out += Channel(
                name = o.optString("name").ifBlank { "Canal $id" },
                url = "$b/live/${enc(user)}/${enc(pass)}/$id.ts",
                group = cats[o.optString("category_id")] ?: "Sem grupo",
                logo = o.optString("stream_icon").takeIf { it.startsWith("http") }
            )
        }
        return out
    }
}
