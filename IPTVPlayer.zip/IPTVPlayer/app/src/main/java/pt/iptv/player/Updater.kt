package pt.iptv.player

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageInstaller
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Atualização da app: vê a versão publicada no GitHub, descarrega o APK e abre o instalador. */
object Updater {
    private const val BASE = "https://github.com/jorgeserra85-tech/-iptv-player/releases/download/app"
    private const val VERSION_URL = "$BASE/version.json"
    const val APK_URL = "$BASE/eco_player.apk"

    var latestCode = 0; var latestName = ""
    private var offered = false

    fun installedCode(a: Activity): Long = try {
        val pi = a.packageManager.getPackageInfo(a.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
    } catch (e: Exception) { 0 }

    private fun open(url: String): HttpURLConnection {
        var target = url
        repeat(6) {
            val c = URL(target).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 30000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "eco_player")
            val code = c.responseCode
            if (code in 300..399) { target = URL(URL(target), c.getHeaderField("Location")).toString(); c.disconnect(); return@repeat }
            if (code !in 200..299) error("HTTP $code")
            return c
        }
        error("Demasiados redirecionamentos")
    }

    /** Lê a versão publicada (corre fora do ecrã). true se houver versão mais recente. */
    fun check(a: Activity): Boolean {
        val txt = open("$VERSION_URL?t=${System.currentTimeMillis()}").inputStream.bufferedReader().use { it.readText() }
        val o = JSONObject(txt)
        latestCode = o.optInt("versionCode"); latestName = o.optString("versionName")
        return latestCode > installedCode(a)
    }

    /** Verifica em segundo plano e, se houver versão nova, pergunta uma vez por sessão. */
    fun offerIfAvailable(a: Activity) {
        if (offered) return
        Thread {
            val has = try { check(a) } catch (e: Exception) { false }
            if (has) a.runOnUiThread {
                if (offered || a.isFinishing) return@runOnUiThread
                offered = true
                Toast.makeText(a, "Nova versão v$latestName — a atualizar automaticamente…", Toast.LENGTH_LONG).show()
                download(a)
            }
        }.start()
    }

    /** Botão "Atualizar app": verifica e, se houver, descarrega. */
    fun manual(a: Activity) {
        Toast.makeText(a, "A procurar atualizações…", Toast.LENGTH_SHORT).show()
        Thread {
            val has = try { check(a) } catch (e: Exception) { null }
            a.runOnUiThread {
                when (has) {
                    true -> download(a)
                    false -> Toast.makeText(a, "Já tem a versão mais recente.", Toast.LENGTH_LONG).show()
                    null -> Toast.makeText(a, "Não foi possível verificar. Tente outra vez.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    fun download(a: Activity) {
        // Android 8+: é preciso autorizar a app a instalar apps
        if (Build.VERSION.SDK_INT >= 26 && !a.packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(a)
                .setTitle("Autorizar atualizações")
                .setMessage("Na janela seguinte ative \"Permitir desta fonte\" e depois volte e carregue outra vez em Atualizar.")
                .setPositiveButton("Continuar") { _, _ ->
                    try {
                        a.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${a.packageName}")))
                    } catch (_: Exception) {}
                }
                .setNegativeButton("Cancelar", null).show()
            return
        }
        val pad = (20 * a.resources.displayMetrics.density).toInt()
        val bar = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; isIndeterminate = true }
        val label = TextView(a).apply { text = "A descarregar…"; setPadding(0, 0, 0, pad / 2) }
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, 0); addView(label); addView(bar) }
        val dlg = AlertDialog.Builder(a).setTitle("A atualizar a eco_player").setView(box).setCancelable(false).show()

        Thread {
            try {
                val dir = a.getExternalFilesDir(null) ?: a.cacheDir
                val file = File(dir, "eco_player_update.apk")
                val c = open("$APK_URL?t=${System.currentTimeMillis()}")
                val total = c.contentLength
                c.inputStream.use { input ->
                    file.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024); var done = 0L; var n: Int
                        while (input.read(buf).also { n = it } >= 0) {
                            out.write(buf, 0, n); done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                a.runOnUiThread { bar.isIndeterminate = false; bar.progress = pct; label.text = "A descarregar… $pct%" }
                            }
                        }
                    }
                }
                a.runOnUiThread { dlg.dismiss(); install(a, file) }
            } catch (e: Exception) {
                a.runOnUiThread {
                    dlg.dismiss()
                    Toast.makeText(a, "Erro ao descarregar a atualização (${e.message})", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Último APK descarregado, para o instalador clássico poder recuperar se a via silenciosa falhar. */
    private var pendingApk: File? = null

    private fun install(a: Activity, file: File) {
        pendingApk = file
        // Android 12+: instalação sem toque. Android mais antigo (boxes): ecrã "Instalar" clássico, que é o fiável.
        if (Build.VERSION.SDK_INT >= 31) {
            try { installSession(a, file); return } catch (_: Exception) {}
        }
        installClassic(a, file)
    }

    /** Chamado pelo InstallReceiver quando a instalação silenciosa falha (Play Protect, verificação…):
     *  abre o instalador clássico "Instalar", que é fiável, para o cliente não ter de repetir. */
    fun fallbackToClassic(c: Context) {
        val f = pendingApk ?: File(c.getExternalFilesDir(null) ?: c.cacheDir, "eco_player_update.apk")
        if (f.exists()) installClassic(c, f)
        else Toast.makeText(c, "Carregue outra vez em Atualizar.", Toast.LENGTH_LONG).show()
    }

    /** Android 12+: atualiza sem pedir nada (a partir da 2.ª atualização feita pela app). */
    private fun installSession(a: Activity, file: File) {
        val pi = a.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        val id = pi.createSession(params)
        pi.openSession(id).use { session ->
            session.openWrite("eco_player", 0, file.length()).use { out ->
                file.inputStream().use { it.copyTo(out) }
                session.fsync(out)
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(a, id, Intent(a, InstallReceiver::class.java), flags)
            session.commit(pending.intentSender)
        }
    }

    private fun installClassic(c: Context, file: File) {
        val i = Intent(Intent.ACTION_VIEW)
        if (Build.VERSION.SDK_INT >= 24) {
            val uri = FileProvider.getUriForFile(c, "${c.packageName}.files", file)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else {
            file.setReadable(true, false)
            i.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive")
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(i) }
        catch (e: Exception) { Toast.makeText(c, "Não foi possível abrir o instalador.", Toast.LENGTH_LONG).show() }
    }
}
