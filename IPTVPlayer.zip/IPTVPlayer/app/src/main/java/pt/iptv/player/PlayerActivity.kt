package pt.iptv.player

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var title: TextView
    private var index = 0
    private val channels get() = MainActivity.playlist
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        playerView = findViewById(R.id.playerView)
        title = findViewById(R.id.title)
        index = intent.getIntExtra("index", 0)
        if (channels.isEmpty()) { finish(); return }
    }

    override fun onStart() { super.onStart(); play(index) }
    override fun onStop() { super.onStop(); player?.release(); player = null }

    private fun play(i: Int) {
        if (channels.isEmpty()) return
        index = (i + channels.size) % channels.size
        val ch = channels[index]
        player?.release()

        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
            .setUserAgent(ch.userAgent ?: "IPTVPlayer/1.0 (Android) ExoPlayer")
        ch.referer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@PlayerActivity, "Não foi possível reproduzir: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
            }
        })
        playerView.player = p
        p.setMediaItem(MediaItem.fromUri(ch.url))
        p.playWhenReady = true
        p.prepare()
        player = p

        title.text = "${index + 1}. ${ch.name}"
        title.visibility = View.VISIBLE
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ title.visibility = View.GONE }, 4000)
    }

    // Comando de TV / teclado: canal seguinte/anterior
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> { play(index + 1); true }
        KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> { play(index - 1); true }
        KeyEvent.KEYCODE_DPAD_UP -> if (!playerView.isControllerFullyVisible) { play(index + 1); true } else super.onKeyDown(keyCode, event)
        KeyEvent.KEYCODE_DPAD_DOWN -> if (!playerView.isControllerFullyVisible) { play(index - 1); true } else super.onKeyDown(keyCode, event)
        else -> super.onKeyDown(keyCode, event)
    }
}
