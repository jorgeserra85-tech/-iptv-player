package pt.iptv.player

import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var topBar: View
    private lateinit var title: TextView
    private lateinit var nowText: TextView
    private var index = 0
    private val channels get() = MainActivity.playlist
    private val handler = Handler(Looper.getMainLooper())
    private var epgJob: Job? = null

    // Modo gravação / filme / episódio: endereços fixos em vez da lista de canais
    private var recordingUrls: List<String>? = null
    private var isVod = false
    private var resumeKey: String? = null      // para continuar onde ficou
    private var seriesKey: String? = null
    private var pendingSeek = 0L
    private var openStart = 0L
    private var started = false
    private lateinit var prevBtn: View
    private lateinit var numBox: TextView
    private var numBuf = ""
    private var prevIndex = -1
    private val numRun = Runnable { goToNumber() }
    private lateinit var overlay: View
    private lateinit var overlayList: ListView
    private lateinit var overlayGroups: ListView
    private lateinit var ovGroupAdapter: GroupAdapter
    private var ovGroupNames: List<String> = emptyList()
    private var ovGroup = MainActivity.ALL
    private var ovChannels: List<Channel> = emptyList()
    private val hideOverlayRun = Runnable { hideOverlay() }
    private val hideInfoRun = Runnable { if (!playerView.isControllerFullyVisible) topBar.visibility = View.GONE }
    private lateinit var nextBtn: View
    private val saveTick = object : Runnable {
        override fun run() { savePosition(); handler.postDelayed(this, 15_000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        playerView = findViewById(R.id.playerView)
        topBar = findViewById(R.id.topBar)
        title = findViewById(R.id.title)
        nowText = findViewById(R.id.nowText)
        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }

        // Back no comando: se as informações estão no ecrã, primeiro só as esconde
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    overlay.visibility == View.VISIBLE -> hideOverlay()
                    playerView.isControllerFullyVisible || topBar.visibility == View.VISIBLE -> {
                        playerView.hideController(); topBar.visibility = View.GONE
                    }
                    else -> finish()
                }
            }
        })

        // Botão de ecrã inteiro: roda para horizontal e preenche o ecrã (a escolha fica guardada)
        val fullBtn = findViewById<ImageView>(R.id.fullBtn)
        val prefs = getSharedPreferences("player", MODE_PRIVATE)
        fun applyFull(full: Boolean) {
            requestedOrientation = if (full) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                   else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            playerView.resizeMode = if (full) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                    else AspectRatioFrameLayout.RESIZE_MODE_FIT
            fullBtn.setImageResource(if (full) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen)
            fullBtn.contentDescription = if (full) "Sair do ecrã inteiro" else "Ecrã inteiro"
        }
        applyFull(prefs.getBoolean("full", false))
        fullBtn.setOnClickListener {
            val full = !prefs.getBoolean("full", false)
            prefs.edit().putBoolean("full", full).apply()
            applyFull(full)
            playerView.showController()
        }

        recordingUrls = intent.getStringArrayListExtra("urls")
        isVod = intent.getBooleanExtra("vod", false)
        resumeKey = intent.getStringExtra("resumeKey")
        seriesKey = intent.getStringExtra("seriesKey")
        index = intent.getIntExtra("index", 0)
        if (recordingUrls == null && channels.isEmpty()) { finish(); return }
        val live = recordingUrls == null

        // Setas para mudar de canal (só em direto)
        prevBtn = findViewById(R.id.prevBtn)
        nextBtn = findViewById(R.id.nextBtn)
        prevBtn.setOnClickListener { play(index - 1, -1) }

        // Lista de canais por cima do vídeo
        overlay = findViewById(R.id.overlay)
        overlayList = findViewById(R.id.overlayList)
        val dm = resources.displayMetrics
        overlay.layoutParams = overlay.layoutParams.apply {
            width = minOf((dm.widthPixels * 0.72f).toInt(), (720 * dm.density).toInt())
        }
        overlayGroups = findViewById(R.id.overlayGroups)
        ovGroupAdapter = GroupAdapter(this, overlayGroups)
        // cursor nos grupos: os canais à direita mudam logo (exceto grupos com PIN)
        ovGroupAdapter.onSelect = { pos ->
            val g = ovGroupNames.getOrNull(pos)
            if (g != null && !Parental.locked("live", g)) fillOverlayChannels(g, -1)
            bumpOverlay()
        }
        overlayGroups.setOnItemClickListener { _, _, pos, _ ->
            val g = ovGroupNames[pos]
            val open = {
                fillOverlayChannels(g, 0)
                overlayGroups.setItemChecked(pos, true)
                overlayList.requestFocus(); overlayList.setSelection(0)
            }
            if (Parental.locked("live", g)) Parental.ask(this) { refreshOverlayGroups(); open() } else open()
        }
        overlayList.setOnItemClickListener { _, _, pos, _ ->
            val target = ovChannels.getOrNull(pos) ?: return@setOnItemClickListener
            hideOverlay()
            val playing = channels.getOrNull(index)
            val list = ovChannels
            val go = {
                MainActivity.playlist = list                // as setas passam a andar neste grupo
                val i = list.indexOf(target)
                if (target.url != playing?.url) play(i, 1) else index = i
            }
            if (Parental.channelLocked(target)) Parental.ask(this) { go() } else go()
        }
        overlayList.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) = bumpOverlay()
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        })
        numBox = findViewById(R.id.numBox)
        findViewById<View>(R.id.tracksBtn).setOnClickListener { tracksDialog() }
        findViewById<View>(R.id.sleepBtn).setOnClickListener { SleepTimer.dialog(this) }
        val listBtn = findViewById<View>(R.id.listBtn)
        listBtn.visibility = if (live) View.VISIBLE else View.GONE
        listBtn.setOnClickListener { playerView.hideController(); showOverlay() }
        nextBtn.setOnClickListener { play(index + 1, 1) }

        // Botões do leitor: em direto sem avançar/recuar; em filmes/séries com avançar/recuar 10 s
        playerView.setShowPreviousButton(false)
        playerView.setShowNextButton(false)
        playerView.setShowRewindButton(!live)
        playerView.setShowFastForwardButton(!live)

        // A barra de cima (voltar + nome) e as setas aparecem junto com os controlos do vídeo
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = vis
            if (live && vis == View.VISIBLE && !topBar.hasFocus()) playerView.post {
                if (!topBar.hasFocus()) { currentFocus?.clearFocus(); playerView.requestFocus() }
            }
            val arrows = if (live) vis else View.GONE
            prevBtn.visibility = View.GONE; nextBtn.visibility = View.GONE   // setas retiradas (telemóvel desliza, box usa ⬆⬇)
        })
    }

    override fun onStart() {
        super.onStart()
        val rec = recordingUrls
        if (rec != null) {
            title.text = intent.getStringExtra("title") ?: "Gravação"
            nowText.text = intent.getStringExtra("sub") ?: ""
            val key = resumeKey
            val saved = if (key != null && !started) Resume.position(this, key) else null
            if (saved != null) {
                // Ficou a meio: perguntar se quer continuar
                AlertDialog.Builder(this)
                    .setTitle("Continuar a ver?")
                    .setMessage("Ficou em ${Resume.fmt(saved)}.")
                    .setPositiveButton("▶ Continuar") { _, _ -> pendingSeek = saved; startVod(rec) }
                    .setNegativeButton("Desde o início") { _, _ -> pendingSeek = 0; startVod(rec) }
                    .setOnCancelListener { pendingSeek = saved; startVod(rec) }
                    .show()
            } else {
                if (started) pendingSeek = lastPosition   // voltar à app depois de sair
                startVod(rec)
            }
        } else play(index)
    }

    private var lastPosition = 0L

    private fun startVod(urls: List<String>) {
        started = true
        Presence.set((intent.getStringExtra("sub")?.let { if (it == "Filme") "Filme: " else "Série: " } ?: "")
            + (intent.getStringExtra("title") ?: "") + (intent.getStringExtra("sub")?.takeIf { it != "Filme" }?.let { " · $it" } ?: ""))
        playAttempt(null, urls, 0)
        playerView.showController()
        if (resumeKey != null) { handler.removeCallbacks(saveTick); handler.postDelayed(saveTick, 15_000) }
    }

    private fun savePosition() {
        val p = player ?: return
        val key = resumeKey ?: return
        if (p.duration <= 0) return
        lastPosition = p.currentPosition
        Resume.save(this, key, p.currentPosition, p.duration, seriesKey)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(saveTick)
        savePosition()
        player?.release(); player = null
    }

    // ---- Picture in Picture (ver TV numa janelinha enquanto usa o telemóvel) ----
    private fun pipSupported(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    /** Ao sair para o telemóvel (botão home), o vídeo continua numa janela a flutuar. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val p = player ?: return
        if (overlay.visibility == View.VISIBLE) return      // se está a escolher canal, não entra
        if (pipSupported() && p.isPlaying) {
            try { enterPictureInPictureMode(pipParams()) } catch (_: Exception) {}
        }
    }

    private fun pipParams(): PictureInPictureParams {
        val b = PictureInPictureParams.Builder()
        val vf = player?.videoFormat
        val w = vf?.width ?: 0; val h = vf?.height ?: 0
        val ratio = if (w > 0 && h > 0) w.toFloat() / h else 16f / 9f
        // O Android só aceita rácios entre ~0.42 e ~2.39
        if (ratio in 0.42f..2.39f && w > 0 && h > 0) b.setAspectRatio(Rational(w, h))
        else b.setAspectRatio(Rational(16, 9))
        return b.build()
    }

    override fun onPictureInPictureModeChanged(isInPip: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPip, newConfig)
        if (isInPip) {
            // Na janelinha: só o vídeo, sem controlos nem barras
            playerView.useController = false
            playerView.hideController()
            topBar.visibility = View.GONE
            hideOverlay()
            numBox.visibility = View.GONE
            if (::prevBtn.isInitialized) { prevBtn.visibility = View.GONE; nextBtn.visibility = View.GONE }
        } else {
            playerView.useController = true
        }
    }

    private fun play(i: Int, dir: Int = 1) {
        if (channels.isEmpty()) return
        var j = ((i % channels.size) + channels.size) % channels.size
        // ao mudar de canal, salta os canais com PIN (se ainda não foi desbloqueado)
        var tries = 0
        while (Parental.channelLocked(channels[j]) && tries < channels.size) {
            j = ((j + dir) % channels.size + channels.size) % channels.size; tries++
        }
        if (tries >= channels.size) return
        if (index != j && index in channels.indices) prevIndex = index
        index = j
        // lembrar o último canal visto — mas nunca um canal de adultos (marcado no painel
        // ou pelo nome), mesmo que o cliente tenha tirado o PIN, para reabrir no último NORMAL
        if (!Parental.isAdultContent(channels[j])) {
            getSharedPreferences("last", MODE_PRIVATE).edit()
                .putString("ch_${Session.providerId}", Api.channelKey(channels[j]))
                .putString("grp_${Session.providerId}", channels[j].group).apply()
        }
        val ch = channels[index]
        Presence.set("TV: ${ch.name}")
        title.text = "${index + 1}. ${ch.name}"
        nowText.text = ""
        playAttempt(ch, candidates(ch.url), 0)
        showInfo()
        loadNowPlaying(ch)
    }

    /** Vai para o canal com o número escrito no comando. */
    private fun goToNumber() {
        val n = numBuf.toIntOrNull() ?: 0
        numBuf = ""; numBox.visibility = View.GONE
        if (n in 1..channels.size) play(n - 1, 1)
        else Toast.makeText(this, "Não existe o canal $n nesta lista", Toast.LENGTH_SHORT).show()
    }

    /** Escolher idioma do áudio e legendas. */
    private fun tracksDialog() {
        val p = player ?: return
        val prefs = getSharedPreferences("player", MODE_PRIVATE)
        val pt = Locale("pt", "PT")
        fun name(f: Format, i: Int): String =
            f.label?.takeIf { it.isNotBlank() }
                ?: f.language?.takeIf { it.isNotBlank() && it != "und" }?.let { Locale(it).getDisplayLanguage(pt).replaceFirstChar { c -> c.uppercase() } }
                ?: "Faixa ${i + 1}"
        val labels = ArrayList<String>(); val actions = ArrayList<() -> Unit>()
        var textSelected = false
        for (g in p.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                labels += (if (g.isTrackSelected(i)) "✓  " else "     ") + "🔊  Áudio: " + name(f, i) +
                        (if (f.channelCount > 2) " (${f.channelCount} canais)" else "")
                actions += {
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                    f.language?.let { prefs.edit().putString("audioLang", it).apply() }
                }
            }
        }
        val textItems = ArrayList<Pair<String, () -> Unit>>()
        for (g in p.currentTracks.groups) {
            if (g.type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                if (g.isTrackSelected(i)) textSelected = true
                textItems += ((if (g.isTrackSelected(i)) "✓  " else "     ") + "💬  Legendas: " + name(f, i)) to {
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                    prefs.edit().putBoolean("textOff", false).putString("textLang", f.language).apply()
                }
            }
        }
        if (textItems.isNotEmpty()) {
            labels += (if (!textSelected) "✓  " else "     ") + "💬  Legendas: desligadas"
            actions += {
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                prefs.edit().putBoolean("textOff", true).apply()
            }
            textItems.forEach { labels += it.first; actions += it.second }
        }
        if (labels.isEmpty()) { Toast.makeText(this, "Este conteúdo não tem outras faixas de áudio ou legendas", Toast.LENGTH_LONG).show(); return }
        android.app.AlertDialog.Builder(this).setTitle("Áudio e legendas")
            .setItems(labels.toTypedArray()) { _, w -> actions[w]() }.show()
    }

    /** Mostra só o nome do canal em cima durante uns segundos. */
    private fun showInfo() {
        topBar.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfoRun)
        handler.postDelayed(hideInfoRun, 4000)
    }

    // ---------- Lista de canais por cima do vídeo ----------
    private fun showOverlay() {
        if (recordingUrls != null || channels.isEmpty()) return
        val all = MainActivity.channelsToShow.ifEmpty { channels }
        val current = channels.getOrNull(index)
        // grupo atual: "Todos" se a lista em uso tem vários grupos
        ovGroup = if (channels.map { it.group }.distinct().size > 1) MainActivity.ALL else current?.group ?: MainActivity.ALL
        ovGroupNames = listOf(MainActivity.ALL) + all.map { it.group }.distinct()
        refreshOverlayGroups()
        val gi = ovGroupNames.indexOf(ovGroup).coerceAtLeast(0)
        overlayGroups.setItemChecked(gi, true)
        overlayGroups.setSelection(gi)
        fillOverlayChannels(ovGroup, -1)
        overlay.visibility = View.VISIBLE
        overlayList.requestFocus()
        overlayList.setSelection(ovChannels.indexOf(current).coerceAtLeast(0))
        bumpOverlay()
    }

    private fun refreshOverlayGroups() {
        val all = MainActivity.channelsToShow.ifEmpty { channels }
        val counts = all.groupingBy { it.group }.eachCount()
        val visibleAll = all.count { !it.custom && !Parental.locked("live", it.group) }
        ovGroupAdapter.labels = ovGroupNames.map {
            if (it == MainActivity.ALL) "${MainActivity.ALL} ($visibleAll)" else "${Parental.label("live", it)} (${counts[it] ?: 0})"
        }
    }

    /** Mostra os canais de um grupo na coluna da direita. */
    private fun fillOverlayChannels(g: String, select: Int) {
        val all = MainActivity.channelsToShow.ifEmpty { channels }
        ovGroup = g
        ovChannels = all.filter {
            (if (it.custom) it.group == g else g == MainActivity.ALL || it.group == g) && !Parental.locked("live", it.group)
        }
        findViewById<TextView>(R.id.overlayTitle).text = if (g == MainActivity.ALL) "Canais" else g
        overlayList.adapter = ArrayAdapter(this, R.layout.item_overlay_channel, R.id.ovName,
            ovChannels.mapIndexed { i, c -> (if (Parental.channelLocked(c)) "🔒 " else "") + "${i + 1}. ${c.name}" })
        if (select >= 0) overlayList.setSelection(select)
    }

    private fun hideOverlay() {
        handler.removeCallbacks(hideOverlayRun)
        overlay.visibility = View.GONE
        playerView.requestFocus()
    }

    /** A lista fecha sozinha depois de 10 s sem mexer. */
    private fun bumpOverlay() {
        handler.removeCallbacks(hideOverlayRun)
        handler.postDelayed(hideOverlayRun, 10_000)
    }

    private fun loadNowPlaying(ch: Channel) {
        epgJob?.cancel()
        val sid = ch.streamId ?: return
        epgJob = lifecycleScope.launch {
            val p = withContext(Dispatchers.IO) { Api.nowPlaying(sid) } ?: return@launch
            val f = SimpleDateFormat("HH:mm", Locale.getDefault())
            nowText.text = "Agora: ${p.title}  (${f.format(Date(p.start * 1000))}–${f.format(Date(p.end * 1000))})"
        }
    }

    /** Formas alternativas de pedir o mesmo canal (servidores Xtream aceitam .m3u8, .ts ou sem extensão). */
    private fun candidates(url: String): List<String> {
        val live = url.contains("/live/")
        val list = when {
            live && url.endsWith(".ts") -> listOf(url.removeSuffix(".ts") + ".m3u8", url, url.removeSuffix(".ts"))
            live && url.endsWith(".m3u8") -> listOf(url, url.removeSuffix(".m3u8") + ".ts")
            else -> listOf(url)
        }
        // usar primeiro o formato que da última vez funcionou neste servidor (troca de canal mais rápida)
        val fmt = getSharedPreferences("last", MODE_PRIVATE).getString("fmt_${Session.providerId}", null) ?: return list
        return list.sortedBy { if (formatOf(it) == fmt) 0 else 1 }
    }

    private fun formatOf(u: String): String {
        val path = u.substringBefore('?')
        return when { path.endsWith(".m3u8") -> "m3u8"; path.endsWith(".ts") -> "ts"; else -> "raw" }
    }

    private val tsFlags = DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
            DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS

    /**
     * Tenta reproduzir urls[attempt]. Se falhar passa ao formato seguinte; no fim, espera 2 s e
     * faz uma segunda volta (muitos servidores só aceitam 1 ligação e demoram a largar a anterior).
     */
    private fun playAttempt(ch: Channel?, urls: List<String>, attempt: Int, round: Int = 0) {
        player?.release(); player = null
        val url = urls[attempt]
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
            .setUserAgent(ch?.userAgent ?: "VLC/3.0.20 LibVLC/3.0.20")
        ch?.referer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }

        // Se o descodificador do telemóvel falhar, tenta outro (ex.: o de software do Android)
        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_000, 2_000)   // arranca com ~1 s de vídeo (antes 2,5 s)
            .build()
        val p = ExoPlayer.Builder(this, renderers).setLoadControl(loadControl).build()
        // idioma de áudio / legendas escolhidos antes
        val tp = getSharedPreferences("player", MODE_PRIVATE)
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().apply {
            tp.getString("audioLang", null)?.let { setPreferredAudioLanguage(it) }
            if (tp.getBoolean("textOff", false)) setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            else tp.getString("textLang", null)?.let { setPreferredTextLanguage(it) }
        }.build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                // funcionou: guardar o formato para as próximas trocas de canal
                if (state == Player.STATE_READY && ch != null) {
                    getSharedPreferences("last", MODE_PRIVATE).edit()
                        .putString("fmt_${Session.providerId}", formatOf(url)).apply()
                    if (openStart > 0) { Diag.opened(ch.name, System.currentTimeMillis() - openStart); openStart = 0 }
                }
                // chegou ao fim do filme/episódio: marcar como visto
                if (state == Player.STATE_ENDED) resumeKey?.let { Resume.markWatched(this@PlayerActivity, it, p.duration) }
            }
            override fun onPlayerError(error: PlaybackException) {
                // Erro de descodificação (telemóvel sem força para esta qualidade): baixar qualidade
                if (ch != null && error.errorCode in 4000..4999) {
                    val lower = lowerQuality(ch)
                    if (lower != null) {
                        Toast.makeText(this@PlayerActivity,
                            "Este aparelho não reproduz ${ch.name}.\nA mudar para ${lower.name}…", Toast.LENGTH_LONG).show()
                        Diag.error("${ch.name}: o aparelho não descodifica (${error.errorCodeName}) — mudou para ${lower.name}")
                        handler.post { if (player === p) switchTo(lower) }
                        return
                    }
                }
                when {
                    attempt + 1 < urls.size ->     // tenta o formato seguinte
                        handler.post { if (player === p) playAttempt(ch, urls, attempt + 1, round) }
                    round < 2 -> handler.post {   // nova volta, dando mais tempo ao servidor (até 3 tentativas)
                        if (player !== p) return@post
                        nowText.text = "A ligar outra vez… (${round + 2}/3)"
                        p.release(); player = null
                        val wait = if (round == 0) 2000L else 4000L
                        handler.postDelayed({
                            if (player == null && lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
                                playAttempt(ch, urls, 0, round + 1)
                        }, wait)
                    }
                    else -> {
                        val msg = when (error.errorCode) {
                            in 2000..2999 -> "O servidor não respondeu. Verifique a internet."
                            in 3000..3999 -> "O servidor não enviou vídeo válido para este canal.\n" +
                                    "Pode estar indisponível agora ou a conta já estar a ser usada noutro aparelho."
                            else -> "Não foi possível reproduzir."
                        }
                        Toast.makeText(this@PlayerActivity, "$msg\n(${error.errorCodeName})", Toast.LENGTH_LONG).show()
                        Diag.error("${title.text}: ${error.errorCodeName}" +
                            (error.cause?.message?.take(80)?.let { " — $it" } ?: ""))
                        nowText.text = ""
                    }
                }
            }
        })
        // Em direto não há pausa: sem botão ⏸ e sem pausa pelo comando
        val live = recordingUrls == null
        playerView.player = if (live) object : ForwardingPlayer(p) {
            override fun getAvailableCommands(): Player.Commands =
                super.getAvailableCommands().buildUpon().remove(Player.COMMAND_PLAY_PAUSE).build()
            override fun isCommandAvailable(command: Int) =
                command != Player.COMMAND_PLAY_PAUSE && super.isCommandAvailable(command)
        } else p
        playerView.findViewById<View>(androidx.media3.ui.R.id.exo_play_pause)?.visibility =
            if (live) View.GONE else View.VISIBLE
        // Em direto também não faz sentido a barra de tempo (00:00 · 00:00)
        // Em direto a roda dentada não faz falta (áudio/legendas estão no botão de cima): sem cursor em lado nenhum
        playerView.findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.visibility = if (live) View.GONE else View.VISIBLE
        if (live) { playerView.setShowSubtitleButton(false); playerView.setShowVrButton(false) }
        for (name in listOf("exo_progress", "exo_time", "exo_position", "exo_duration", "exo_progress_placeholder", "exo_bottom_bar")) {
            val id = resources.getIdentifier(name, "id", packageName)
            if (id != 0) playerView.findViewById<View>(id)?.visibility = if (live) View.GONE else View.VISIBLE
        }
        val item = MediaItem.Builder().setUri(url)
        if (recordingUrls == null) item.setLiveConfiguration(
            MediaItem.LiveConfiguration.Builder()
                .setTargetOffsetMs(6_000)          // ~6 s atrás do "agora" do servidor (antes ~3 segmentos)
                .setMinPlaybackSpeed(0.97f).setMaxPlaybackSpeed(1.03f)
                .build())
        val path = url.substringBefore('?')
        val source = when {
            path.endsWith(".m3u8") || path.contains("/hls/") -> {
                item.setMimeType(MimeTypes.APPLICATION_M3U8)
                HlsMediaSource.Factory(http)
                    .setExtractorFactory(DefaultHlsExtractorFactory(tsFlags, true))
                    .setAllowChunklessPreparation(true)
                    .createMediaSource(item.build())
            }
            path.endsWith(".mpd") ->
                DefaultMediaSourceFactory(this).setDataSourceFactory(http).createMediaSource(item.build())
            else -> {
                if (path.endsWith(".ts")) item.setMimeType(MimeTypes.VIDEO_MP2T)
                val extractors = DefaultExtractorsFactory().setTsExtractorFlags(tsFlags)
                ProgressiveMediaSource.Factory(http, extractors).createMediaSource(item.build())
            }
        }
        p.setMediaSource(source)
        if (pendingSeek > 0) { p.seekTo(pendingSeek); pendingSeek = 0 }
        openStart = System.currentTimeMillis()
        p.playWhenReady = true
        p.prepare()
        player = p
    }

    // ---------- Baixar qualidade automaticamente ----------
    private fun normalized(name: String) =
        Normalizer.normalize(name, Normalizer.Form.NFKC).lowercase()   // ᶠᴴᴰ -> fhd

    private val wordStart = "(?<![a-z])"; private val wordEnd = "(?![a-z])"

    private fun rank(name: String): Int {
        val n = normalized(name)
        return when {
            Regex("$wordStart(uhd|4k|2160p?)$wordEnd").containsMatchIn(n) -> 4
            Regex("$wordStart(fhd|1080p?)$wordEnd").containsMatchIn(n) -> 3
            Regex("$wordStart(hd|720p?)$wordEnd").containsMatchIn(n) -> 2
            else -> 1
        }
    }

    private fun baseName(name: String) = normalized(name)
        .replace(Regex("$wordStart(uhd|4k|2160p?|fhd|1080p?|hd|720p?|sd|576p?|hevc|h\\.?265|h\\.?264)$wordEnd"), " ")
        .replace(Regex("[^\\p{L}\\p{N}]+"), "")

    /** Mesmo canal noutra qualidade mais baixa (ex.: fHD -> HD -> SD). */
    private fun lowerQuality(ch: Channel): Channel? {
        val base = baseName(ch.name); val r = rank(ch.name)
        if (base.isEmpty()) return null
        return MainActivity.channelsToShow
            .filter { it.url != ch.url && baseName(it.name) == base && rank(it.name) < r }
            .maxByOrNull { rank(it.name) }
    }

    private fun switchTo(ch: Channel) {
        val i = channels.indexOfFirst { it.url == ch.url }
        if (i >= 0) { play(i); return }
        // canal não está na lista atual (outro grupo): toca-o diretamente
        title.text = ch.name; nowText.text = ""
        playAttempt(ch, candidates(ch.url), 0)
        showInfo()
        loadNowPlaying(ch)
    }

    // Comando de TV / teclado: canal seguinte/anterior (só em direto)
    /**
     * Comando da TV (só em direto):
     * ⬆⬇ mudam sempre de canal; OK abre a lista de canais; com a lista aberta, ⬅ ou Back fecham-na.
     */
    private val swipe by lazy {
        android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: android.view.MotionEvent?, e2: android.view.MotionEvent, vx: Float, vy: Float): Boolean {
                if (recordingUrls != null || overlay.visibility == View.VISIBLE || e1 == null) return false
                val dx = e2.x - e1.x; val dy = e2.y - e1.y
                val min = 80 * resources.displayMetrics.density
                if (Math.abs(dx) > min && Math.abs(dx) > Math.abs(dy) * 1.5f && Math.abs(vx) > 300) {
                    if (dx > 0) play(index + 1, 1) else play(index - 1, -1)   // 👉 seguinte · 👈 anterior
                    return true
                }
                return false
            }
        })
    }

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        if (swipe.onTouchEvent(ev)) {
            ev.action = android.view.MotionEvent.ACTION_CANCEL      // não abrir os controlos ao deslizar
            super.dispatchTouchEvent(ev)
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (recordingUrls != null) {
            // Filmes / séries / gravações: OK mostra os controlos (pausa, tempo, informações)
            val k = e.keyCode
            val ok = k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER
            if (ok && !playerView.isControllerFullyVisible && !topBar.hasFocus()) {
                if (e.action == KeyEvent.ACTION_UP) {
                    playerView.showController(); topBar.visibility = View.VISIBLE
                    playerView.findViewById<View>(androidx.media3.ui.R.id.exo_play_pause)?.requestFocus()
                }
                return true
            }
            if (k == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || k == KeyEvent.KEYCODE_SPACE) {
                if (e.action == KeyEvent.ACTION_DOWN) { player?.let { it.playWhenReady = !it.playWhenReady }; playerView.showController() }
                return true
            }
            return super.dispatchKeyEvent(e)
        }
        val code = e.keyCode
        val down = e.action == KeyEvent.ACTION_DOWN
        if (overlay.visibility == View.VISIBLE) {
            bumpOverlay()
            val inGroups = overlayGroups.hasFocus()
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) {
                if (down) { if (inGroups) hideOverlay() else overlayGroups.requestFocus() }
                return true
            }
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (down && inGroups) {
                    val g = ovGroupNames.getOrNull(overlayGroups.selectedItemPosition)
                    if (g != null && Parental.locked("live", g)) overlayGroups.performItemClick(null, overlayGroups.selectedItemPosition, 0)
                    else { overlayList.requestFocus(); overlayList.setSelection(0) }
                }
                return true
            }
            return super.dispatchKeyEvent(e)
        }
        // Botões de cima (áudio, temporizador, lista, ecrã inteiro) com o comando
        if (topBar.hasFocus()) {
            playerView.showController()                          // mantém a barra aberta
            if (code == KeyEvent.KEYCODE_DPAD_DOWN || code == KeyEvent.KEYCODE_DPAD_UP) {
                if (down) { playerView.hideController(); topBar.visibility = View.GONE; playerView.requestFocus() }
                return true
            }
            return super.dispatchKeyEvent(e)
        }
        if ((code == KeyEvent.KEYCODE_DPAD_RIGHT || code == KeyEvent.KEYCODE_MENU) && !playerView.isControllerFullyVisible) {
            if (down && e.repeatCount == 0) {
                playerView.showController(); topBar.visibility = View.VISIBLE
                findViewById<View>(R.id.tracksBtn).requestFocus()
            }
            return true
        }
        // números do comando: escrever o número do canal
        val digit = when (code) {
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> code - KeyEvent.KEYCODE_0
            in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> code - KeyEvent.KEYCODE_NUMPAD_0
            else -> -1
        }
        if (digit >= 0) {
            if (down && e.repeatCount == 0 && numBuf.length < 4) {
                numBuf += digit
                numBox.text = numBuf; numBox.visibility = View.VISIBLE
                handler.removeCallbacks(numRun); handler.postDelayed(numRun, 1500)
            }
            return true
        }
        when (code) {
            KeyEvent.KEYCODE_LAST_CHANNEL -> {          // tecla "canal anterior"
                if (down && e.repeatCount == 0 && prevIndex in channels.indices) play(prevIndex, 1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                if (down && e.repeatCount == 0) { playerView.hideController(); play(index + 1, 1) }
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                if (down && e.repeatCount == 0) { playerView.hideController(); play(index - 1, -1) }
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                // com os controlos abertos, o OK carrega no botão selecionado; senão abre a lista
                if (!playerView.isControllerFullyVisible) {
                    if (!down) showOverlay()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }
}
