package pt.iptv.player

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var title: TextView
    private var index = 0
    private val channels get() = MainActivity.playlist
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        playerView = findViewById(R.id.playerView)
        title = findViewById(R.id.title)
        index = intent.getIntExtra("index", 0)
        if (channels.isEmpty()) { finish(); return }
    }

    override fun onStart() { super.onStart(); play(index) }
    override fun onStop() { super.onStop(); player?.release(); player = null }

    private fun play(i: Int) {
        if (channels.isEmpty()) return
        index = (i + channels.size) % channels.size
        val ch = channels[index]
        title.text = "${index + 1}. ${ch.name}"
        title.visibility = View.VISIBLE
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ title.visibility = View.GONE }, 4000)
        playAttempt(ch, candidates(ch.url), 0)
    }

    /** Formas alternativas de pedir o mesmo canal (servidores Xtream aceitam .m3u8, .ts ou sem extensão). */
    private fun candidates(url: String): List<String> {
        val live = url.contains("/live/")
        return when {
            live && url.endsWith(".ts") -> listOf(url.removeSuffix(".ts") + ".m3u8", url, url.removeSuffix(".ts"))
            live && url.endsWith(".m3u8") -> listOf(url, url.removeSuffix(".m3u8") + ".ts")
            else -> listOf(url)
        }
    }

    private fun playAttempt(ch: Channel, urls: List<String>, attempt: Int) {
        player?.release()
        val url = urls[attempt]
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
            .setUserAgent(ch.userAgent ?: "VLC/3.0.20 LibVLC/3.0.20")
        ch.referer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (attempt + 1 < urls.size) {
                    handler.post { if (player === p) playAttempt(ch, urls, attempt + 1) }  // tenta o formato seguinte
                } else {
                    val cause = error.cause?.message?.take(80) ?: ""
                    Toast.makeText(this@PlayerActivity,
                        "Não foi possível reproduzir: ${error.errorCodeName}\n$cause", Toast.LENGTH_LONG).show()
                }
            }
        })
        playerView.player = p
        val item = MediaItem.Builder().setUri(url)
        when {
            url.endsWith(".m3u8") -> item.setMimeType(MimeTypes.APPLICATION_M3U8)
            url.endsWith(".ts") -> item.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        p.setMediaItem(item.build())
        p.playWhenReady = true
        p.prepare()
        player = p
    }

    // Comando de TV / teclado: canal seguinte/anterior
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> { play(index + 1); true }
        KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> { play(index - 1); true }
        KeyEvent.KEYCODE_DPAD_UP -> if (!playerView.isControllerFullyVisible) { play(index + 1); true } else super.onKeyDown(keyCode, event)
        KeyEvent.KEYCODE_DPAD_DOWN -> if (!playerView.isControllerFullyVisible) { play(index - 1); true } else super.onKeyDown(keyCode, event)
        else -> super.onKeyDown(keyCode, event)
    }
}
