package pt.iptv.player

import android.app.AlertDialog
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var topBar: View
    private lateinit var title: TextView
    private lateinit var nowText: TextView
    private var index = 0
    private val channels get() = MainActivity.playlist
    private val handler = Handler(Looper.getMainLooper())
    private var epgJob: Job? = null

    // Modo gravação / filme / episódio: endereços fixos em vez da lista de canais
    private var recordingUrls: List<String>? = null
    private var isVod = false
    private var resumeKey: String? = null      // para continuar onde ficou
    private var seriesKey: String? = null
    private var pendingSeek = 0L
    private var started = false
    private lateinit var prevBtn: View
    private lateinit var overlay: View
    private lateinit var overlayList: ListView
    private val hideOverlayRun = Runnable { hideOverlay() }
    private val hideInfoRun = Runnable { if (!playerView.isControllerFullyVisible) topBar.visibility = View.GONE }
    private lateinit var nextBtn: View
    private val saveTick = object : Runnable {
        override fun run() { savePosition(); handler.postDelayed(this, 15_000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        playerView = findViewById(R.id.playerView)
        topBar = findViewById(R.id.topBar)
        title = findViewById(R.id.title)
        nowText = findViewById(R.id.nowText)
        findViewById<View>(R.id.backBtn).setOnClickListener { finish() }

        // Back no comando: se as informações estão no ecrã, primeiro só as esconde
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    overlay.visibility == View.VISIBLE -> hideOverlay()
                    playerView.isControllerFullyVisible || topBar.visibility == View.VISIBLE -> {
                        playerView.hideController(); topBar.visibility = View.GONE
                    }
                    else -> finish()
                }
            }
        })

        // Botão de ecrã inteiro: roda para horizontal e preenche o ecrã (a escolha fica guardada)
        val fullBtn = findViewById<ImageView>(R.id.fullBtn)
        val prefs = getSharedPreferences("player", MODE_PRIVATE)
        fun applyFull(full: Boolean) {
            requestedOrientation = if (full) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                   else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            playerView.resizeMode = if (full) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                    else AspectRatioFrameLayout.RESIZE_MODE_FIT
            fullBtn.setImageResource(if (full) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen)
            fullBtn.contentDescription = if (full) "Sair do ecrã inteiro" else "Ecrã inteiro"
        }
        applyFull(prefs.getBoolean("full", false))
        fullBtn.setOnClickListener {
            val full = !prefs.getBoolean("full", false)
            prefs.edit().putBoolean("full", full).apply()
            applyFull(full)
            playerView.showController()
        }

        recordingUrls = intent.getStringArrayListExtra("urls")
        isVod = intent.getBooleanExtra("vod", false)
        resumeKey = intent.getStringExtra("resumeKey")
        seriesKey = intent.getStringExtra("seriesKey")
        index = intent.getIntExtra("index", 0)
        if (recordingUrls == null && channels.isEmpty()) { finish(); return }
        val live = recordingUrls == null

        // Setas para mudar de canal (só em direto)
        prevBtn = findViewById(R.id.prevBtn)
        nextBtn = findViewById(R.id.nextBtn)
        prevBtn.setOnClickListener { play(index - 1, -1) }

        // Lista de canais por cima do vídeo
        overlay = findViewById(R.id.overlay)
        overlayList = findViewById(R.id.overlayList)
        val dm = resources.displayMetrics
        overlay.layoutParams = overlay.layoutParams.apply {
            width = minOf((dm.widthPixels * 0.45f).toInt(), (420 * dm.density).toInt()).coerceAtLeast((240 * dm.density).toInt())
        }
        overlayList.setOnItemClickListener { _, _, pos, _ ->
            hideOverlay()
            if (pos == index) return@setOnItemClickListener
            val go = { play(pos, if (pos < index) -1 else 1) }
            if (Parental.channelLocked(channels[pos])) Parental.ask(this) { go() } else go()
        }
        overlayList.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) = bumpOverlay()
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        })
        val listBtn = findViewById<View>(R.id.listBtn)
        listBtn.visibility = if (live) View.VISIBLE else View.GONE
        listBtn.setOnClickListener { playerView.hideController(); showOverlay() }
        nextBtn.setOnClickListener { play(index + 1, 1) }

        // Botões do leitor: em direto sem avançar/recuar; em filmes/séries com avançar/recuar 10 s
        playerView.setShowPreviousButton(false)
        playerView.setShowNextButton(false)
        playerView.setShowRewindButton(!live)
        playerView.setShowFastForwardButton(!live)

        // A barra de cima (voltar + nome) e as setas aparecem junto com os controlos do vídeo
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = vis
            val arrows = if (live) vis else View.GONE
            prevBtn.visibility = arrows; nextBtn.visibility = arrows
        })
    }

    override fun onStart() {
        super.onStart()
        val rec = recordingUrls
        if (rec != null) {
            title.text = intent.getStringExtra("title") ?: "Gravação"
            nowText.text = intent.getStringExtra("sub") ?: ""
            val key = resumeKey
            val saved = if (key != null && !started) Resume.position(this, key) else null
            if (saved != null) {
                // Ficou a meio: perguntar se quer continuar
                AlertDialog.Builder(this)
                    .setTitle("Continuar a ver?")
                    .setMessage("Ficou em ${Resume.fmt(saved)}.")
                    .setPositiveButton("▶ Continuar") { _, _ -> pendingSeek = saved; startVod(rec) }
                    .setNegativeButton("Desde o início") { _, _ -> pendingSeek = 0; startVod(rec) }
                    .setOnCancelListener { pendingSeek = saved; startVod(rec) }
                    .show()
            } else {
                if (started) pendingSeek = lastPosition   // voltar à app depois de sair
                startVod(rec)
            }
        } else play(index)
    }

    private var lastPosition = 0L

    private fun startVod(urls: List<String>) {
        started = true
        playAttempt(null, urls, 0)
        playerView.showController()
        if (resumeKey != null) { handler.removeCallbacks(saveTick); handler.postDelayed(saveTick, 15_000) }
    }

    private fun savePosition() {
        val p = player ?: return
        val key = resumeKey ?: return
        if (p.duration <= 0) return
        lastPosition = p.currentPosition
        Resume.save(this, key, p.currentPosition, p.duration, seriesKey)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(saveTick)
        savePosition()
        player?.release(); player = null
    }

    private fun play(i: Int, dir: Int = 1) {
        if (channels.isEmpty()) return
        var j = ((i % channels.size) + channels.size) % channels.size
        // ao mudar de canal, salta os canais com PIN (se ainda não foi desbloqueado)
        var tries = 0
        while (Parental.channelLocked(channels[j]) && tries < channels.size) {
            j = ((j + dir) % channels.size + channels.size) % channels.size; tries++
        }
        if (tries >= channels.size) return
        index = j
        // lembrar o último canal visto (para o cursor voltar a ele na lista)
        getSharedPreferences("last", MODE_PRIVATE).edit()
            .putString("ch_${Session.providerId}", Api.channelKey(channels[j]))
            .putString("grp_${Session.providerId}", channels[j].group).apply()
        val ch = channels[index]
        title.text = "${index + 1}. ${ch.name}"
        nowText.text = ""
        playAttempt(ch, candidates(ch.url), 0)
        showInfo()
        loadNowPlaying(ch)
    }

    /** Mostra só o nome do canal em cima durante uns segundos. */
    private fun showInfo() {
        topBar.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfoRun)
        handler.postDelayed(hideInfoRun, 4000)
    }

    // ---------- Lista de canais por cima do vídeo ----------
    private fun showOverlay() {
        if (recordingUrls != null || channels.isEmpty()) return
        overlayList.adapter = ArrayAdapter(this, R.layout.item_overlay_channel, R.id.ovName,
            channels.mapIndexed { i, c -> (if (Parental.channelLocked(c)) "🔒 " else "") + "${i + 1}. ${c.name}" })
        overlay.visibility = View.VISIBLE
        overlayList.requestFocus()
        overlayList.setSelection(index)
        bumpOverlay()
    }

    private fun hideOverlay() {
        handler.removeCallbacks(hideOverlayRun)
        overlay.visibility = View.GONE
        playerView.requestFocus()
    }

    /** A lista fecha sozinha depois de 10 s sem mexer. */
    private fun bumpOverlay() {
        handler.removeCallbacks(hideOverlayRun)
        handler.postDelayed(hideOverlayRun, 10_000)
    }

    private fun loadNowPlaying(ch: Channel) {
        epgJob?.cancel()
        val sid = ch.streamId ?: return
        epgJob = lifecycleScope.launch {
            val p = withContext(Dispatchers.IO) { Api.nowPlaying(sid) } ?: return@launch
            val f = SimpleDateFormat("HH:mm", Locale.getDefault())
            nowText.text = "Agora: ${p.title}  (${f.format(Date(p.start * 1000))}–${f.format(Date(p.end * 1000))})"
        }
    }

    /** Formas alternativas de pedir o mesmo canal (servidores Xtream aceitam .m3u8, .ts ou sem extensão). */
    private fun candidates(url: String): List<String> {
        val live = url.contains("/live/")
        return when {
            live && url.endsWith(".ts") -> listOf(url.removeSuffix(".ts") + ".m3u8", url, url.removeSuffix(".ts"))
            live && url.endsWith(".m3u8") -> listOf(url, url.removeSuffix(".m3u8") + ".ts")
            else -> listOf(url)
        }
    }

    private val tsFlags = DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
            DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS

    /**
     * Tenta reproduzir urls[attempt]. Se falhar passa ao formato seguinte; no fim, espera 2 s e
     * faz uma segunda volta (muitos servidores só aceitam 1 ligação e demoram a largar a anterior).
     */
    private fun playAttempt(ch: Channel?, urls: List<String>, attempt: Int, round: Int = 0) {
        player?.release(); player = null
        val url = urls[attempt]
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
            .setUserAgent(ch?.userAgent ?: "VLC/3.0.20 LibVLC/3.0.20")
        ch?.referer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }

        // Se o descodificador do telemóvel falhar, tenta outro (ex.: o de software do Android)
        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, renderers).build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                // chegou ao fim do filme/episódio: marcar como visto
                if (state == Player.STATE_ENDED) resumeKey?.let { Resume.markWatched(this@PlayerActivity, it, p.duration) }
            }
            override fun onPlayerError(error: PlaybackException) {
                // Erro de descodificação (telemóvel sem força para esta qualidade): baixar qualidade
                if (ch != null && error.errorCode in 4000..4999) {
                    val lower = lowerQuality(ch)
                    if (lower != null) {
                        Toast.makeText(this@PlayerActivity,
                            "Este aparelho não reproduz ${ch.name}.\nA mudar para ${lower.name}…", Toast.LENGTH_LONG).show()
                        handler.post { if (player === p) switchTo(lower) }
                        return
                    }
                }
                when {
                    attempt + 1 < urls.size ->     // tenta o formato seguinte
                        handler.post { if (player === p) playAttempt(ch, urls, attempt + 1, round) }
                    round == 0 -> handler.post {   // segunda volta, depois de dar tempo ao servidor
                        if (player !== p) return@post
                        nowText.text = "A ligar outra vez…"
                        p.release(); player = null
                        handler.postDelayed({
                            if (player == null && lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
                                playAttempt(ch, urls, 0, 1)
                        }, 2000)
                    }
                    else -> {
                        val msg = when (error.errorCode) {
                            in 2000..2999 -> "O servidor não respondeu. Verifique a internet."
                            in 3000..3999 -> "O servidor não enviou vídeo válido para este canal.\n" +
                                    "Pode estar indisponível agora ou a conta já estar a ser usada noutro aparelho."
                            else -> "Não foi possível reproduzir."
                        }
                        Toast.makeText(this@PlayerActivity, "$msg\n(${error.errorCodeName})", Toast.LENGTH_LONG).show()
                        nowText.text = ""
                    }
                }
            }
        })
        playerView.player = p
        val item = MediaItem.Builder().setUri(url)
        val path = url.substringBefore('?')
        val source = when {
            path.endsWith(".m3u8") || path.contains("/hls/") -> {
                item.setMimeType(MimeTypes.APPLICATION_M3U8)
                HlsMediaSource.Factory(http)
                    .setExtractorFactory(DefaultHlsExtractorFactory(tsFlags, true))
                    .setAllowChunklessPreparation(true)
                    .createMediaSource(item.build())
            }
            path.endsWith(".mpd") ->
                DefaultMediaSourceFactory(this).setDataSourceFactory(http).createMediaSource(item.build())
            else -> {
                if (path.endsWith(".ts")) item.setMimeType(MimeTypes.VIDEO_MP2T)
                val extractors = DefaultExtractorsFactory().setTsExtractorFlags(tsFlags)
                ProgressiveMediaSource.Factory(http, extractors).createMediaSource(item.build())
            }
        }
        p.setMediaSource(source)
        if (pendingSeek > 0) { p.seekTo(pendingSeek); pendingSeek = 0 }
        p.playWhenReady = true
        p.prepare()
        player = p
    }

    // ---------- Baixar qualidade automaticamente ----------
    private fun normalized(name: String) =
        Normalizer.normalize(name, Normalizer.Form.NFKC).lowercase()   // ᶠᴴᴰ -> fhd

    private val wordStart = "(?<![a-z])"; private val wordEnd = "(?![a-z])"

    private fun rank(name: String): Int {
        val n = normalized(name)
        return when {
            Regex("$wordStart(uhd|4k|2160p?)$wordEnd").containsMatchIn(n) -> 4
            Regex("$wordStart(fhd|1080p?)$wordEnd").containsMatchIn(n) -> 3
            Regex("$wordStart(hd|720p?)$wordEnd").containsMatchIn(n) -> 2
            else -> 1
        }
    }

    private fun baseName(name: String) = normalized(name)
        .replace(Regex("$wordStart(uhd|4k|2160p?|fhd|1080p?|hd|720p?|sd|576p?|hevc|h\\.?265|h\\.?264)$wordEnd"), " ")
        .replace(Regex("[^\\p{L}\\p{N}]+"), "")

    /** Mesmo canal noutra qualidade mais baixa (ex.: fHD -> HD -> SD). */
    private fun lowerQuality(ch: Channel): Channel? {
        val base = baseName(ch.name); val r = rank(ch.name)
        if (base.isEmpty()) return null
        return MainActivity.channelsToShow
            .filter { it.url != ch.url && baseName(it.name) == base && rank(it.name) < r }
            .maxByOrNull { rank(it.name) }
    }

    private fun switchTo(ch: Channel) {
        val i = channels.indexOfFirst { it.url == ch.url }
        if (i >= 0) { play(i); return }
        // canal não está na lista atual (outro grupo): toca-o diretamente
        title.text = ch.name; nowText.text = ""
        playAttempt(ch, candidates(ch.url), 0)
        showInfo()
        loadNowPlaying(ch)
    }

    // Comando de TV / teclado: canal seguinte/anterior (só em direto)
    /**
     * Comando da TV (só em direto):
     * ⬆⬇ mudam sempre de canal; OK abre a lista de canais; com a lista aberta, ⬅ ou Back fecham-na.
     */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (recordingUrls != null) return super.dispatchKeyEvent(e)
        val code = e.keyCode
        val down = e.action == KeyEvent.ACTION_DOWN
        if (overlay.visibility == View.VISIBLE) {
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) { if (down) hideOverlay(); return true }
            bumpOverlay()
            return super.dispatchKeyEvent(e)
        }
        when (code) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                if (down && e.repeatCount == 0) { playerView.hideController(); play(index + 1, 1) }
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                if (down && e.repeatCount == 0) { playerView.hideController(); play(index - 1, -1) }
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                // com os controlos abertos, o OK carrega no botão selecionado; senão abre a lista
                if (!playerView.isControllerFullyVisible) {
                    if (!down) showOverlay()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }
}
