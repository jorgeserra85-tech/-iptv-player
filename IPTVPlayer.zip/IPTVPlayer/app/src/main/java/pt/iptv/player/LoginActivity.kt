package pt.iptv.player

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var user: EditText
    private lateinit var pass: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var loginBtn: Button
    private var providers: List<Provider> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        spinner = findViewById(R.id.providerSpinner)
        user = findViewById(R.id.userInput)
        pass = findViewById(R.id.passInput)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        loginBtn = findViewById(R.id.loginBtn)

        // cartão com largura confortável em telemóvel e TV
        val dm = resources.displayMetrics
        val w = minOf(dm.widthPixels - (40 * dm.density).toInt(), (380 * dm.density).toInt())
        listOf(R.id.card, R.id.profilesBox).forEach { id ->
            val v = findViewById<View>(id); v.layoutParams = v.layoutParams.apply { width = w }
        }

        loginBtn.setOnClickListener { loginNew() }
        pass.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_GO) { loginNew(); true } else false }
        loadProviders()
    }

    override fun onResume() { super.onResume(); showProfiles() }

    private fun loadProviders() {
        status.text = "A carregar servidores…"
        lifecycleScope.launch {
            try {
                providers = withContext(Dispatchers.IO) { Api.providers() }
                spinner.adapter = ArrayAdapter(this@LoginActivity, R.layout.spinner_item_login,
                    if (providers.isEmpty()) listOf("Sem servidores disponíveis")
                    else listOf("Escolha o servidor") + providers.map { it.name }
                ).apply { setDropDownViewResource(R.layout.spinner_dropdown_login) }
                status.text = ""
            } catch (e: Exception) {
                status.text = "Sem ligação ao servidor. Toque aqui para tentar outra vez."
                status.setOnClickListener { status.setOnClickListener(null); loadProviders() }
            }
        }
    }

    private fun showProfiles() {
        val box = findViewById<LinearLayout>(R.id.profilesBox)
        box.removeAllViews()
        val list = Profiles.all(this)
        findViewById<View>(R.id.profilesTitle).visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (p in list) {
            val v = layoutInflater.inflate(R.layout.item_profile, box, false)
            v.findViewById<TextView>(R.id.pName).text = p.providerName
            v.findViewById<TextView>(R.id.pUser).text = p.user
            v.setOnClickListener { enter(p) }
            v.findViewById<View>(R.id.pDelete).setOnClickListener {
                AlertDialog.Builder(this).setMessage("Apagar o perfil ${p.providerName} (${p.user})?")
                    .setPositiveButton("Apagar") { _, _ -> Profiles.remove(this, p); showProfiles() }
                    .setNegativeButton("Cancelar", null).show()
            }
            box.addView(v)
        }
    }

    private fun loginNew() {
        val pos = spinner.selectedItemPosition - 1   // posição 0 = "Escolha o servidor"
        if (providers.isEmpty() || pos < 0 || pos >= providers.size) { status.text = "Escolha o servidor"; return }
        val u = user.text.toString().trim(); val pw = pass.text.toString().trim()
        if (u.isEmpty() || pw.isEmpty()) { status.text = "Introduza o utilizador e a palavra-passe"; return }
        val prov = providers[pos]
        enter(Profile(prov.name, prov.id, prov.name, u, pw), isNew = true)
    }

    private fun enter(p: Profile, isNew: Boolean = false) {
        progress.visibility = View.VISIBLE; loginBtn.isEnabled = false
        status.text = "A entrar em ${p.providerName}…"
        lifecycleScope.launch {
            try {
                val (prov, exp, channels) = withContext(Dispatchers.IO) {
                    val prov = Api.provider(p.providerId)          // endereço sempre atualizado do painel
                    val exp = Api.login(prov.serverUrl, p.user, p.pass)
                    Triple(prov, exp, Api.liveChannels(prov.serverUrl, p.user, p.pass))
                }
                if (channels.isEmpty()) error("Este servidor não devolveu canais")
                Profiles.upsert(this@LoginActivity, p.copy(providerName = prov.name, label = prov.name))
                if (isNew) { user.text.clear(); pass.text.clear() }
                Session.server = prov.serverUrl; Session.user = p.user; Session.pass = p.pass
                MainActivity.channelsToShow = channels
                startActivity(Intent(this@LoginActivity, MainActivity::class.java)
                    .putExtra("title", prov.name)
                    .putExtra("sub", "${p.user}" + (exp?.let { " · válido até $it" } ?: "")))
                status.text = ""
            } catch (e: Exception) {
                status.text = e.message ?: "Erro ao entrar"
            } finally {
                progress.visibility = View.GONE; loginBtn.isEnabled = true
            }
        }
    }
}
