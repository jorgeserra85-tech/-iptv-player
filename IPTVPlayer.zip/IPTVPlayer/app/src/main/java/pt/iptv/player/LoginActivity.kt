package pt.iptv.player

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var user: AutoCompleteTextView
    private lateinit var pass: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var loginBtn: Button
    private var providers: List<Provider> = emptyList()
    private var passVisible = false
    private var enterJob: Job? = null
    private val settings by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        spinner = findViewById(R.id.providerSpinner)
        user = findViewById(R.id.userInput)
        pass = findViewById(R.id.passInput)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        loginBtn = findViewById(R.id.loginBtn)

        // cartão com largura confortável em telemóvel e TV
        val dm = resources.displayMetrics
        val w = minOf(dm.widthPixels - (40 * dm.density).toInt(), (380 * dm.density).toInt())
        listOf(R.id.card, R.id.profilesBox).forEach { id ->
            val v = findViewById<View>(id); v.layoutParams = v.layoutParams.apply { width = w }
        }
        // Ecrã deitado (TV / box): cartão à esquerda e perfis à direita, para caber tudo sem deslizar
        if (dm.widthPixels > dm.heightPixels && dm.widthPixels / dm.density >= 700) {
            val root = findViewById<LinearLayout>(R.id.loginRoot)
            root.orientation = LinearLayout.HORIZONTAL
            root.setPadding(root.paddingLeft, (16 * dm.density).toInt(), root.paddingRight, (16 * dm.density).toInt())
            val side = findViewById<LinearLayout>(R.id.side)
            side.layoutParams = (side.layoutParams as LinearLayout.LayoutParams).apply {
                marginStart = (40 * dm.density).toInt(); gravity = android.view.Gravity.CENTER_VERTICAL
            }
            (findViewById<View>(R.id.profilesTitle).layoutParams as LinearLayout.LayoutParams).topMargin = 0
        }

        // Olho: mostrar / esconder palavra-passe
        val eye = findViewById<ImageView>(R.id.eyeBtn)
        eye.setOnClickListener {
            passVisible = !passVisible
            pass.inputType = InputType.TYPE_CLASS_TEXT or
                (if (passVisible) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
            pass.setSelection(pass.text.length)
            eye.setImageResource(if (passVisible) R.drawable.ic_eye_off else R.drawable.ic_eye)
        }

        // Histórico: sugerir utilizadores já usados no servidor escolhido
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = refreshUserHistory()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        user.setOnItemClickListener { _, _, _, _ -> fillPasswordFor(user.text.toString()) }
        // Teclado: só abre quando se carrega em OK (ou se toca) no campo
        user.showSoftInputOnFocus = false
        pass.showSoftInputOnFocus = false
        user.setOnClickListener {
            showKeyboard(it)
            if (user.text.isEmpty() && (user.adapter?.count ?: 0) > 0) user.showDropDown()
        }
        pass.setOnClickListener { showKeyboard(it) }
        // alguns comandos enviam ENTER em vez de OK
        val okKey = View.OnKeyListener { v, code, e ->
            if (code == android.view.KeyEvent.KEYCODE_ENTER || code == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER) {
                if (e.action == android.view.KeyEvent.ACTION_UP) showKeyboard(v)
                true
            } else false
        }
        user.setOnKeyListener(okKey)
        pass.setOnKeyListener(okKey)

        findViewById<Button>(R.id.updateBtn).setOnClickListener { Updater.manual(this) }
        // número da versão (para saber se a app está atualizada)
        findViewById<TextView>(R.id.version).text = try {
            "eco_player v" + packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) { "" }

        loginBtn.setOnClickListener { loginNew() }

        // Ao abrir: cursor no perfil guardado (ou na escolha do servidor), nunca num campo de texto
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        findViewById<View>(R.id.profilesBox).post {
            val box = findViewById<LinearLayout>(R.id.profilesBox)
            if (box.childCount > 0) box.getChildAt(0).requestFocus() else spinner.requestFocus()
        }
        pass.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_GO) { loginNew(); true } else false }
        loadProviders()

        // Entrar automaticamente no último perfil usado (só ao abrir a app)
        val auto = findViewById<CheckBox>(R.id.autoLogin)
        auto.isChecked = settings.getBoolean("autoLogin", true)
        auto.setOnCheckedChangeListener { _, on -> settings.edit().putBoolean("autoLogin", on).apply() }
        val last = Profiles.all(this).firstOrNull()
        val force = intent.getBooleanExtra("forceAuto", false)
        if (savedInstanceState == null && (auto.isChecked || force) && last != null) enter(last, auto = true)
    }

    override fun onResume() {
        super.onResume()
        Parental.unlocked = false        // ao voltar aos perfis, volta a bloquear os adultos
        showProfiles(); refreshUserHistory()
    }

    private fun showKeyboard(v: View) {
        v.requestFocus()
        v.post { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(v, 0) }
    }

    private fun selectedProvider(): Provider? {
        val pos = spinner.selectedItemPosition - 1
        return providers.getOrNull(pos)
    }

    private fun refreshUserHistory() {
        val prov = selectedProvider()
        val all = Profiles.all(this)
        val users = (if (prov != null) all.filter { it.providerId == prov.id } else all).map { it.user }.distinct()
        user.setAdapter(object : ArrayAdapter<String>(this, R.layout.item_user_suggestion, users.toMutableList()) {
            // mostra sempre todas as sugestões que começam pelo texto escrito
            override fun getFilter(): Filter = object : Filter() {
                override fun performFiltering(c: CharSequence?): FilterResults {
                    val q = c?.toString()?.trim() ?: ""
                    val r = users.filter { q.isEmpty() || it.startsWith(q, ignoreCase = true) }
                    return FilterResults().apply { values = r; count = r.size }
                }
                @Suppress("UNCHECKED_CAST")
                override fun publishResults(c: CharSequence?, r: FilterResults?) {
                    clear(); addAll((r?.values as? List<String>) ?: emptyList()); notifyDataSetChanged()
                }
                override fun convertResultToString(v: Any?): CharSequence = v?.toString() ?: ""
            }
        })
    }

    private fun fillPasswordFor(u: String) {
        val prov = selectedProvider()
        val match = Profiles.all(this).firstOrNull { it.user == u && (prov == null || it.providerId == prov.id) }
        if (match != null) {
            pass.setText(match.pass)
            if (prov == null) {   // escolhe o servidor deste utilizador
                val i = providers.indexOfFirst { it.id == match.providerId }
                if (i >= 0) spinner.setSelection(i + 1)
            }
            pass.requestFocus(); pass.setSelection(pass.text.length)
        }
    }

    private fun loadProviders() {
        status.text = "A carregar servidores…"
        lifecycleScope.launch {
            try {
                providers = withContext(Dispatchers.IO) { Api.providers() }
                spinner.adapter = ArrayAdapter(this@LoginActivity, R.layout.spinner_item_login,
                    if (providers.isEmpty()) listOf("Sem servidores disponíveis")
                    else listOf("Escolha o servidor") + providers.map { it.name }
                ).apply { setDropDownViewResource(R.layout.spinner_dropdown_login) }
                status.text = ""
            } catch (e: Exception) {
                status.text = "Sem ligação ao servidor. Toque aqui para tentar outra vez."
                status.setOnClickListener { status.setOnClickListener(null); loadProviders() }
            }
        }
    }

    private fun showProfiles() {
        val box = findViewById<LinearLayout>(R.id.profilesBox)
        box.removeAllViews()
        val list = Profiles.all(this)
        findViewById<View>(R.id.profilesTitle).visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (p in list) {
            val v = layoutInflater.inflate(R.layout.item_profile, box, false)
            v.findViewById<TextView>(R.id.pName).text = p.providerName
            v.findViewById<TextView>(R.id.pUser).text = p.user
            v.setOnClickListener { enter(p) }
            val del = v.findViewById<View>(R.id.pDelete)
            val askDelete = {
                AlertDialog.Builder(this).setTitle("Apagar perfil")
                    .setMessage("Apagar o perfil ${p.providerName} (${p.user}) deste aparelho?")
                    .setPositiveButton("Apagar") { _, _ ->
                        Profiles.remove(this, p)
                        Store.clearChannels(this, p.providerId, p.user)
                        Toast.makeText(this, "Perfil apagado", Toast.LENGTH_SHORT).show()
                        showProfiles()
                    }
                    .setNegativeButton("Cancelar", null).show()
                Unit
            }
            v.setOnLongClickListener { askDelete(); true }          // manter OK carregado = apagar
            v.setOnKeyListener { _, code, e ->
                when (code) {
                    android.view.KeyEvent.KEYCODE_DPAD_CENTER, android.view.KeyEvent.KEYCODE_ENTER,
                    android.view.KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        if (e.action == android.view.KeyEvent.ACTION_UP && !e.isCanceled && e.eventTime - e.downTime < 600) enter(p)
                        else if (e.action == android.view.KeyEvent.ACTION_DOWN && e.repeatCount == 8) askDelete()
                        true
                    }
                    android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {        // ➡ vai para o ✕
                        if (e.action == android.view.KeyEvent.ACTION_DOWN) del.requestFocus()
                        true
                    }
                    else -> false
                }
            }
            del.setOnClickListener { askDelete() }
            del.setOnKeyListener { _, code, e ->
                if (code == android.view.KeyEvent.KEYCODE_DPAD_LEFT) { if (e.action == android.view.KeyEvent.ACTION_DOWN) v.requestFocus(); true }
                else false
            }
            box.addView(v)
        }
    }

    private fun loginNew() {
        val pos = spinner.selectedItemPosition - 1   // posição 0 = "Escolha o servidor"
        if (providers.isEmpty() || pos < 0 || pos >= providers.size) { status.text = "Escolha o servidor"; return }
        val u = user.text.toString().trim(); val pw = pass.text.toString().trim()
        if (u.isEmpty() || pw.isEmpty()) { status.text = "Introduza o utilizador e a palavra-passe"; return }
        val prov = providers[pos]
        enter(Profile(prov.name, prov.id, prov.name, u, pw), isNew = true)
    }

    private fun enter(p: Profile, isNew: Boolean = false, auto: Boolean = false) {
        enterJob?.cancel()
        progress.visibility = View.VISIBLE; loginBtn.isEnabled = false
        if (auto) {
            status.text = "A entrar automaticamente em ${p.providerName} (${p.user})…\nToque aqui para cancelar."
            status.setOnClickListener {
                enterJob?.cancel()
                status.text = "Entrada automática cancelada."
                status.setOnClickListener(null)
            }
        } else status.text = "A entrar em ${p.providerName}…"
        if (!auto) Toast.makeText(this, "A entrar em ${p.providerName} (${p.user})…", Toast.LENGTH_SHORT).show()
        enterJob = lifecycleScope.launch {
            try {
                // 1) Abrir logo com a cópia guardada no aparelho (a lista atualiza-se depois, por trás)
                if (!isNew) {
                    val cached = withContext(Dispatchers.IO) { Store.loadChannels(this@LoginActivity, p.providerId, p.user) }
                    if (cached != null) {
                        Session.user = p.user; Session.pass = p.pass; Session.providerId = p.providerId
                        Store.restoreCachedServer(this@LoginActivity, p.providerId, p.user)
                        Session.title = p.providerName
                        Store.saveSession(this@LoginActivity)
                        Profiles.upsert(this@LoginActivity, p)            // fica como "último perfil"
                        MainActivity.channelsToShow = cached
                        startActivity(Intent(this@LoginActivity, MainActivity::class.java).putExtra("refresh", true))
                        status.text = ""
                        return@launch
                    }
                }
                // 2) Primeira vez com este perfil: ir buscar tudo ao servidor
                val r = withContext(Dispatchers.IO) { Sync.fetch(this@LoginActivity, p.providerId, p.user, p.pass) }
                Profiles.upsert(this@LoginActivity, p.copy(providerName = r.prov.name, label = r.prov.name))
                if (isNew) { user.text.clear(); pass.text.clear() }
                withContext(Dispatchers.IO) { Sync.apply(this@LoginActivity, r, p.user, p.pass) }
                MainActivity.channelsToShow = r.channels
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                status.text = ""
            } catch (e: CancellationException) {
                // cancelado pelo utilizador
            } catch (e: Exception) {
                status.text = e.message ?: "Erro ao entrar"
                Toast.makeText(this@LoginActivity, status.text, Toast.LENGTH_LONG).show()
            } finally {
                progress.visibility = View.GONE; loginBtn.isEnabled = true
                if (auto) status.setOnClickListener(null)
            }
        }
    }
}
