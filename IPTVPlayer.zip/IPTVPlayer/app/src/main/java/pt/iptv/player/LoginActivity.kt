package pt.iptv.player

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var user: AutoCompleteTextView
    private lateinit var pass: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var loginBtn: Button
    private var providers: List<Provider> = emptyList()
    private var passVisible = false
    private var enterJob: Job? = null
    private val settings by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        spinner = findViewById(R.id.providerSpinner)
        user = findViewById(R.id.userInput)
        pass = findViewById(R.id.passInput)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        loginBtn = findViewById(R.id.loginBtn)

        // cartão com largura confortável em telemóvel e TV
        val dm = resources.displayMetrics
        val w = minOf(dm.widthPixels - (40 * dm.density).toInt(), (380 * dm.density).toInt())
        listOf(R.id.card, R.id.profilesBox).forEach { id ->
            val v = findViewById<View>(id); v.layoutParams = v.layoutParams.apply { width = w }
        }

        // Olho: mostrar / esconder palavra-passe
        val eye = findViewById<ImageView>(R.id.eyeBtn)
        eye.setOnClickListener {
            passVisible = !passVisible
            pass.inputType = InputType.TYPE_CLASS_TEXT or
                (if (passVisible) InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_TEXT_VARIATION_PASSWORD)
            pass.setSelection(pass.text.length)
            eye.setImageResource(if (passVisible) R.drawable.ic_eye_off else R.drawable.ic_eye)
        }

        // Histórico: sugerir utilizadores já usados no servidor escolhido
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = refreshUserHistory()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        user.setOnItemClickListener { _, _, _, _ -> fillPasswordFor(user.text.toString()) }
        // Na box (comando), abrir o teclado sempre que um campo recebe o foco
        user.setOnFocusChangeListener { v, has ->
            if (!has) return@setOnFocusChangeListener
            showKeyboard(v)
            if (user.text.isEmpty() && (user.adapter?.count ?: 0) > 0) user.showDropDown()
        }
        pass.setOnFocusChangeListener { v, has -> if (has) showKeyboard(v) }
        user.setOnClickListener { if (user.text.isEmpty() && (user.adapter?.count ?: 0) > 0) user.showDropDown() }

        // número da versão (para saber se a app está atualizada)
        findViewById<TextView>(R.id.version).text = try {
            "eco_player v" + packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) { "" }

        loginBtn.setOnClickListener { loginNew() }
        pass.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_GO) { loginNew(); true } else false }
        loadProviders()

        // Entrar automaticamente no último perfil usado (só ao abrir a app)
        val auto = findViewById<CheckBox>(R.id.autoLogin)
        auto.isChecked = settings.getBoolean("autoLogin", true)
        auto.setOnCheckedChangeListener { _, on -> settings.edit().putBoolean("autoLogin", on).apply() }
        val last = Profiles.all(this).firstOrNull()
        if (savedInstanceState == null && auto.isChecked && last != null) enter(last, auto = true)
    }

    override fun onResume() {
        super.onResume()
        Parental.unlocked = false        // ao voltar aos perfis, volta a bloquear os adultos
        showProfiles(); refreshUserHistory()
    }

    private fun showKeyboard(v: View) {
        v.postDelayed({
            if (v.hasFocus()) (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(v, 0)
        }, 150)
    }

    private fun selectedProvider(): Provider? {
        val pos = spinner.selectedItemPosition - 1
        return providers.getOrNull(pos)
    }

    private fun refreshUserHistory() {
        val prov = selectedProvider()
        val all = Profiles.all(this)
        val users = (if (prov != null) all.filter { it.providerId == prov.id } else all).map { it.user }.distinct()
        user.setAdapter(object : ArrayAdapter<String>(this, R.layout.item_user_suggestion, users.toMutableList()) {
            // mostra sempre todas as sugestões que começam pelo texto escrito
            override fun getFilter(): Filter = object : Filter() {
                override fun performFiltering(c: CharSequence?): FilterResults {
                    val q = c?.toString()?.trim() ?: ""
                    val r = users.filter { q.isEmpty() || it.startsWith(q, ignoreCase = true) }
                    return FilterResults().apply { values = r; count = r.size }
                }
                @Suppress("UNCHECKED_CAST")
                override fun publishResults(c: CharSequence?, r: FilterResults?) {
                    clear(); addAll((r?.values as? List<String>) ?: emptyList()); notifyDataSetChanged()
                }
                override fun convertResultToString(v: Any?): CharSequence = v?.toString() ?: ""
            }
        })
    }

    private fun fillPasswordFor(u: String) {
        val prov = selectedProvider()
        val match = Profiles.all(this).firstOrNull { it.user == u && (prov == null || it.providerId == prov.id) }
        if (match != null) {
            pass.setText(match.pass)
            if (prov == null) {   // escolhe o servidor deste utilizador
                val i = providers.indexOfFirst { it.id == match.providerId }
                if (i >= 0) spinner.setSelection(i + 1)
            }
            pass.requestFocus(); pass.setSelection(pass.text.length)
        }
    }

    private fun loadProviders() {
        status.text = "A carregar servidores…"
        lifecycleScope.launch {
            try {
                providers = withContext(Dispatchers.IO) { Api.providers() }
                spinner.adapter = ArrayAdapter(this@LoginActivity, R.layout.spinner_item_login,
                    if (providers.isEmpty()) listOf("Sem servidores disponíveis")
                    else listOf("Escolha o servidor") + providers.map { it.name }
                ).apply { setDropDownViewResource(R.layout.spinner_dropdown_login) }
                status.text = ""
            } catch (e: Exception) {
                status.text = "Sem ligação ao servidor. Toque aqui para tentar outra vez."
                status.setOnClickListener { status.setOnClickListener(null); loadProviders() }
            }
        }
    }

    private fun showProfiles() {
        val box = findViewById<LinearLayout>(R.id.profilesBox)
        box.removeAllViews()
        val list = Profiles.all(this)
        findViewById<View>(R.id.profilesTitle).visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (p in list) {
            val v = layoutInflater.inflate(R.layout.item_profile, box, false)
            v.findViewById<TextView>(R.id.pName).text = p.providerName
            v.findViewById<TextView>(R.id.pUser).text = p.user
            v.setOnClickListener { enter(p) }
            v.findViewById<View>(R.id.pDelete).setOnClickListener {
                AlertDialog.Builder(this).setMessage("Apagar o perfil ${p.providerName} (${p.user})?")
                    .setPositiveButton("Apagar") { _, _ -> Profiles.remove(this, p); showProfiles() }
                    .setNegativeButton("Cancelar", null).show()
            }
            box.addView(v)
        }
    }

    private fun loginNew() {
        val pos = spinner.selectedItemPosition - 1   // posição 0 = "Escolha o servidor"
        if (providers.isEmpty() || pos < 0 || pos >= providers.size) { status.text = "Escolha o servidor"; return }
        val u = user.text.toString().trim(); val pw = pass.text.toString().trim()
        if (u.isEmpty() || pw.isEmpty()) { status.text = "Introduza o utilizador e a palavra-passe"; return }
        val prov = providers[pos]
        enter(Profile(prov.name, prov.id, prov.name, u, pw), isNew = true)
    }

    private fun enter(p: Profile, isNew: Boolean = false, auto: Boolean = false) {
        enterJob?.cancel()
        progress.visibility = View.VISIBLE; loginBtn.isEnabled = false
        if (auto) {
            status.text = "A entrar automaticamente em ${p.providerName} (${p.user})…\nToque aqui para cancelar."
            status.setOnClickListener {
                enterJob?.cancel()
                status.text = "Entrada automática cancelada."
                status.setOnClickListener(null)
            }
        } else status.text = "A entrar em ${p.providerName}…"
        enterJob = lifecycleScope.launch {
            try {
                val (prov, exp, channels) = withContext(Dispatchers.IO) {
                    val prov = Api.provider(p.providerId)          // endereço sempre atualizado do painel
                    val exp = Api.login(prov.serverUrl, p.user, p.pass)
                    val raw = Api.liveChannels(prov.serverUrl, p.user, p.pass)
                    // envia a lista de canais para o painel (só se mudou desde a última vez)
                    val prefs = getSharedPreferences("sync", MODE_PRIVATE)
                    val key = "channels_${prov.id}"
                    Api.uploadChannelList(prov.id, raw, prefs.getString(key, null))
                        ?.let { prefs.edit().putString(key, it).apply() }
                    // organização do painel: primeiro canais, depois grupos
                    val organized = Api.applyGroupSettings(prov.id, Api.applyChannelSettings(prov.id, raw))
                    Triple(prov, exp, organized)
                }
                if (channels.isEmpty()) error("Este servidor não devolveu canais")
                Profiles.upsert(this@LoginActivity, p.copy(providerName = prov.name, label = prov.name))
                if (isNew) { user.text.clear(); pass.text.clear() }
                Session.server = prov.serverUrl; Session.user = p.user; Session.pass = p.pass
                Session.providerId = prov.id
                Session.title = prov.name
                Session.sub = p.user + (exp?.let { " · válido até $it" } ?: "")
                MainActivity.channelsToShow = channels
                startActivity(Intent(this@LoginActivity, MainActivity::class.java)
                    .putExtra("title", prov.name)
                    .putExtra("sub", "${p.user}" + (exp?.let { " · válido até $it" } ?: "")))
                status.text = ""
            } catch (e: CancellationException) {
                // cancelado pelo utilizador
            } catch (e: Exception) {
                status.text = e.message ?: "Erro ao entrar"
            } finally {
                progress.visibility = View.GONE; loginBtn.isEnabled = true
                if (auto) status.setOnClickListener(null)
            }
        }
    }
}
