package pt.iptv.player

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Pesquisa ao mesmo tempo em canais, filmes e séries. */
class SearchActivity : AppCompatActivity() {
    private sealed class Row {
        class Header(val text: String) : Row()
        class Ch(val ch: Channel, val pos: Int) : Row()
        class Vod(val item: VodItem) : Row()
    }

    private var rows: List<Row> = emptyList()
    private var chResults: List<Channel> = emptyList()
    private var job: Job? = null
    private lateinit var status: TextView
    private lateinit var adapter: BaseAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Store.restoreSession(this)) { finish(); return }
        setContentView(R.layout.activity_search)
        findViewById<Button>(R.id.backBtn).setOnClickListener { finish() }
        status = findViewById(R.id.status)
        val list = findViewById<ListView>(R.id.results)
        adapter = Adapter(); list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> open(rows[pos]) }
        val q = findViewById<EditText>(R.id.query)
        q.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = search(s?.toString()?.trim() ?: "")
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        q.requestFocus()
    }

    private fun search(text: String) {
        job?.cancel()
        if (text.length < 2) { rows = emptyList(); adapter.notifyDataSetChanged(); status.text = "Escreva pelo menos 2 letras."; return }
        job = lifecycleScope.launch {
            delay(350)                                  // espera que acabe de escrever
            status.text = "A procurar…"
            val (r, chs) = withContext(Dispatchers.IO) {
                val channels = MainActivity.channelsToShow.ifEmpty {
                    Store.loadChannels(this@SearchActivity, Session.providerId, Session.user) ?: emptyList()
                }
                val ch = channels.filter { !Parental.locked("live", it.group) && it.name.contains(text, true) }.take(80)
                val mv = VodRepo.any(this@SearchActivity, false)
                    .filter { !Parental.locked("vod", it.category) && it.name.contains(text, true) }.take(80)
                val sr = VodRepo.any(this@SearchActivity, true)
                    .filter { !Parental.locked("series", it.category) && it.name.contains(text, true) }.take(80)
                val out = ArrayList<Row>()
                if (ch.isNotEmpty()) { out += Row.Header("📺  Canais (${ch.size})"); ch.forEachIndexed { i, c -> out += Row.Ch(c, i) } }
                if (mv.isNotEmpty()) { out += Row.Header("🎬  Filmes (${mv.size})"); mv.forEach { out += Row.Vod(it) } }
                if (sr.isNotEmpty()) { out += Row.Header("🎞  Séries (${sr.size})"); sr.forEach { out += Row.Vod(it) } }
                out to ch
            }
            rows = r; chResults = chs
            adapter.notifyDataSetChanged()
            status.text = if (r.isEmpty()) "Nada encontrado para «$text»." else "Resultados para «$text»"
        }
    }

    private fun open(r: Row) {
        when (r) {
            is Row.Header -> {}
            is Row.Ch -> {
                val go = {
                    MainActivity.playlist = chResults
                    startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", r.pos))
                }
                if (Parental.channelLocked(r.ch)) Parental.ask(this) { go() } else go()
            }
            is Row.Vod -> {
                VodActivity.selected = r.item
                startActivity(Intent(this, DetailActivity::class.java))
            }
        }
    }

    inner class Adapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(p: Int): Any = rows[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(p: Int) = if (rows[p] is Row.Header) 0 else 1
        override fun isEnabled(p: Int) = rows[p] !is Row.Header
        override fun areAllItemsEnabled() = false
        override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
            val r = rows[p]
            if (r is Row.Header) {
                val v = (convert ?: layoutInflater.inflate(R.layout.item_search_header, parent, false)) as TextView
                v.text = r.text; return v
            }
            val v = convert ?: layoutInflater.inflate(R.layout.item_search, parent, false)
            val t = v.findViewById<TextView>(R.id.title); val s = v.findViewById<TextView>(R.id.sub)
            val img = v.findViewById<ImageView>(R.id.thumb)
            when (r) {
                is Row.Ch -> {
                    t.text = (if (Parental.channelLocked(r.ch)) "🔒 " else "") + r.ch.name; s.text = "Canal · ${r.ch.group}"
                    img.scaleType = ImageView.ScaleType.FIT_CENTER; img.load(r.ch.logo)
                }
                is Row.Vod -> {
                    t.text = r.item.name
                    s.text = (if (r.item.series) "Série" else "Filme") + " · ${r.item.category}" +
                            (if (r.item.year.isNotBlank()) " · ${r.item.year}" else "")
                    img.scaleType = ImageView.ScaleType.CENTER_CROP
                    img.load(r.item.cover) { placeholder(R.drawable.poster_placeholder); error(R.drawable.poster_placeholder) }
                }
                else -> {}
            }
            return v
        }
    }
}
