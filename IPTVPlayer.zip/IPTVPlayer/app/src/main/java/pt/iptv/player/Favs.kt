package pt.iptv.player

import android.content.Context

/** Favoritos (canais, filmes, séries), guardados no aparelho por perfil. */
object Favs {
    const val GROUP = "⭐ Favoritos"
    private fun prefs(c: Context) = c.getSharedPreferences("favs", Context.MODE_PRIVATE)
    private fun key(kind: String) = "${kind}_${Session.providerId}_${Session.user}"

    fun all(c: Context, kind: String): Set<String> = prefs(c).getStringSet(key(kind), emptySet())?.toSet() ?: emptySet()
    fun has(c: Context, kind: String, id: String) = id in all(c, kind)

    /** Liga/desliga. Devolve true se ficou nos favoritos. */
    fun toggle(c: Context, kind: String, id: String): Boolean {
        val s = all(c, kind).toMutableSet()
        val now = if (id in s) { s.remove(id); false } else { s.add(id); true }
        prefs(c).edit().putStringSet(key(kind), s).apply()
        return now
    }
}
