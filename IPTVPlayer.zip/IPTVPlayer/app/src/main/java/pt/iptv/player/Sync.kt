package pt.iptv.player

import android.content.Context

/** Vai buscar ao servidor a lista de canais já organizada pelo painel. */
object Sync {
    class Result(val prov: Provider, val expText: String?, val channels: List<Channel>)

    class AuthException(msg: String) : Exception(msg)

    fun fetch(c: Context, providerId: Long, user: String, pass: String): Result {
        val prov = Api.provider(providerId)                       // endereço sempre atualizado do painel
        val exp = try { Api.login(prov.serverUrl, user, pass) } catch (e: Exception) {
            val m = e.message ?: ""
            if (m.contains("errados") || m.startsWith("Conta")) throw AuthException(m) else throw e
        }
        if (Presence.send(prov.id, prov.name, user) == true)
            throw AuthException("⛔ Este aparelho foi bloqueado pelo fornecedor. Contacte-o para mais informações.")
        val raw = Api.liveChannels(prov.serverUrl, user, pass)
        // envia a lista de canais para o painel (só se mudou desde a última vez)
        val prefs = c.getSharedPreferences("sync", Context.MODE_PRIVATE)
        val key = "channels_${prov.id}"
        Api.uploadChannelList(prov.id, raw, prefs.getString(key, null))?.let { prefs.edit().putString(key, it).apply() }
        // organização do painel: primeiro canais, depois grupos
        val organized = Api.applyGroupSettings(prov.id, Api.applyChannelSettings(prov.id, raw))
        if (organized.isEmpty()) error("Este servidor não devolveu canais")
        return Result(prov, exp, organized)
    }

    /** Aplica o resultado à sessão e guarda tudo no aparelho. */
    fun apply(c: Context, r: Result, user: String, pass: String) {
        Session.server = r.prov.serverUrl; Session.user = user; Session.pass = pass
        Session.providerId = r.prov.id; Session.title = r.prov.name
        Session.sub = user + (r.expText?.let { " · válido até $it" } ?: "")
        Session.expIso = r.expText ?: ""
        Store.saveSession(c)
        Store.saveChannels(c, r.prov.id, user, r.channels)
    }
}
