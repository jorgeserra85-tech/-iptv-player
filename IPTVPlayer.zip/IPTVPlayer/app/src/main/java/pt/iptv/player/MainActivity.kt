package pt.iptv.player

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var searchInput: EditText
    private lateinit var status: TextView
    private lateinit var groupList: ListView
    private lateinit var adapter: ChannelAdapter
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var channelList: ListView

    private var all: List<Channel> = emptyList()
    private var groups: List<String> = emptyList()
    private var currentGroup = ALL

    companion object {
        const val ALL = "Todos"
        var channelsToShow: List<Channel> = emptyList()   // vem do login
        var playlist: List<Channel> = emptyList()         // partilhada com o leitor
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        all = channelsToShow
        if (all.isEmpty()) { finish(); return }          // ex.: app reaberta pelo sistema
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.title).text = intent.getStringExtra("title") ?: getString(R.string.app_name)
        findViewById<TextView>(R.id.sub).text = intent.getStringExtra("sub") ?: ""
        findViewById<Button>(R.id.backBtn).setOnClickListener { finish() }
        Tabs.setup(this, 0)
        searchInput = findViewById(R.id.searchInput)
        status = findViewById(R.id.status)
        groupList = findViewById(R.id.groupList)
        val list = findViewById<ListView>(R.id.channelList)
        channelList = list
        groupAdapter = GroupAdapter(this, groupList)

        // ----- Grupos (coluna da esquerda) -----
        groups = listOf(ALL) + all.map { it.group }.distinct()
        // abrir no grupo do último canal visto
        val lastGroup = lastPrefs().getString("grp_${Session.providerId}", null)
        if (lastGroup != null && lastGroup in groups && !Parental.locked("live", lastGroup)) currentGroup = lastGroup
        refreshGroupLabels()
        groupList.setOnItemClickListener { _, _, pos, _ ->
            val g = groups[pos]
            groupList.setItemChecked(groups.indexOf(currentGroup), true)   // só muda depois do PIN, se for preciso
            val open = {
                currentGroup = g
                refreshGroupLabels()
                groupList.setItemChecked(pos, true)
                applyFilter()
                list.setSelection(0)
            }
            if (Parental.locked("live", g)) Parental.ask(this) { open() } else open()
        }

        // ----- Canais (coluna da direita) -----
        adapter = ChannelAdapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val items = adapter.items
            val go = {
                playlist = items
                adapter.notifyDataSetChanged()
                startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", pos))
            }
            if (Parental.channelLocked(items[pos])) Parental.ask(this) { go() } else go()
        }
        // No comando da TV: seta para a direita (ou manter OK carregado) abre o guia
        list.setOnItemLongClickListener { _, _, pos, _ -> guarded(adapter.items, pos); true }
        list.setOnKeyListener { _, code, e ->
            if (code == android.view.KeyEvent.KEYCODE_DPAD_RIGHT && list.selectedItemPosition >= 0) {
                if (e.action == android.view.KeyEvent.ACTION_UP) guarded(adapter.items, list.selectedItemPosition)
                true
            } else false
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = applyFilter()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        applyFilter()
    }

    private fun guarded(items: List<Channel>, pos: Int) {
        if (Parental.channelLocked(items[pos])) Parental.ask(this) { openGuide(items, pos) } else openGuide(items, pos)
    }

    private fun openGuide(items: List<Channel>, pos: Int) {
        val ch = items[pos]
        if (ch.streamId == null) { Toast.makeText(this, "Este canal não tem guia", Toast.LENGTH_SHORT).show(); return }
        playlist = items
        EpgActivity.channel = ch
        EpgActivity.channelIndex = pos
        startActivity(Intent(this, EpgActivity::class.java))
    }

    private fun lastPrefs() = getSharedPreferences("last", MODE_PRIVATE)

    override fun onResume() {
        super.onResume()
        if (!::adapter.isInitialized) return
        Updater.offerIfAvailable(this)      // avisa se houver versão nova da app
        refreshGroupLabels(); applyFilter()
        // cursor no último canal visto
        val key = lastPrefs().getString("ch_${Session.providerId}", null)
        val idx = if (key != null) adapter.items.indexOfFirst { Api.channelKey(it) == key } else -1
        channelList.post {
            channelList.requestFocus()
            channelList.setSelection(if (idx >= 0) idx else 0)
        }
        groupList.setSelection(groups.indexOf(currentGroup).coerceAtLeast(0))
    }

    private fun refreshGroupLabels() {
        val counts = all.groupingBy { it.group }.eachCount()
        val visibleAll = all.count { !Parental.locked("live", it.group) }
        val labels = groups.map { g -> if (g == ALL) "$ALL ($visibleAll)" else "${Parental.label("live", g)} (${counts[g] ?: 0})" }
        groupAdapter.labels = labels
        groupList.setItemChecked(groups.indexOf(currentGroup).coerceAtLeast(0), true)
    }

    private fun applyFilter() {
        val q = searchInput.text.toString().trim()
        val filtered = all.filter {
            (currentGroup == ALL || it.group == currentGroup) && !Parental.locked("live", it.group) &&
                (q.isEmpty() || it.name.contains(q, ignoreCase = true))
        }
        adapter.items = filtered
        adapter.notifyDataSetChanged()
        status.text = "${filtered.size} canais" + if (currentGroup != ALL) " · $currentGroup" else ""
    }

    // ---------- Lista com logótipos ----------
    private val logoCache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    inner class ChannelAdapter : BaseAdapter() {
        var items: List<Channel> = emptyList()
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: layoutInflater.inflate(R.layout.item_channel, parent, false)
            val ch = items[p]
            v.findViewById<TextView>(R.id.name).text =
                if (!Parental.unlocked && Parental.channelHasOwnLock(ch)) "🔒 ${ch.name}" else ch.name
            v.findViewById<View>(R.id.rec).visibility = if (ch.archive) View.VISIBLE else View.GONE
            val guide = v.findViewById<View>(R.id.guideBtn)
            guide.visibility = if (ch.streamId != null) View.VISIBLE else View.GONE
            guide.setOnClickListener { guarded(items, p) }
            val img = v.findViewById<ImageView>(R.id.logo)
            img.tag = ch.logo
            img.setImageBitmap(ch.logo?.let { logoCache.get(it) })
            val logo = ch.logo
            if (logo != null && logoCache.get(logo) == null) lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    try {
                        val c = URL(logo).openConnection().apply { connectTimeout = 8000; readTimeout = 8000 }
                        c.getInputStream().use { BitmapFactory.decodeStream(it) }
                            ?.let { Bitmap.createScaledBitmap(it, 88, (88f * it.height / it.width).toInt().coerceAtLeast(1), true) }
                    } catch (e: Exception) { null }
                }
                if (bmp != null) { logoCache.put(logo, bmp); if (img.tag == logo) img.setImageBitmap(bmp) }
            }
            return v
        }
    }
}
