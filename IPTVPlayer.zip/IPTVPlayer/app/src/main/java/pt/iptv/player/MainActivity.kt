package pt.iptv.player

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var searchInput: EditText
    private lateinit var status: TextView
    private lateinit var groupSpinner: Spinner
    private lateinit var adapter: ChannelAdapter

    private var all: List<Channel> = emptyList()
    private var currentGroup = ALL

    companion object {
        const val ALL = "Todos os grupos"
        var channelsToShow: List<Channel> = emptyList()   // vem do login
        var playlist: List<Channel> = emptyList()         // partilhada com o leitor
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        all = channelsToShow
        if (all.isEmpty()) { finish(); return }          // ex.: app reaberta pelo sistema
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.title).text = intent.getStringExtra("title") ?: getString(R.string.app_name)
        findViewById<TextView>(R.id.sub).text = intent.getStringExtra("sub") ?: ""
        findViewById<Button>(R.id.backBtn).setOnClickListener { finish() }
        searchInput = findViewById(R.id.searchInput)
        status = findViewById(R.id.status)
        groupSpinner = findViewById(R.id.groupSpinner)
        val list = findViewById<ListView>(R.id.channelList)

        adapter = ChannelAdapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            playlist = adapter.items
            startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", pos))
        }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = applyFilter()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        groupSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                currentGroup = p?.getItemAtPosition(pos) as? String ?: ALL; applyFilter()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        val groups = listOf(ALL) + all.map { it.group }.distinct()
        groupSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups)
        applyFilter()
    }

    private fun applyFilter() {
        val q = searchInput.text.toString().trim()
        val filtered = all.filter {
            (currentGroup == ALL || it.group == currentGroup) && (q.isEmpty() || it.name.contains(q, ignoreCase = true))
        }
        adapter.items = filtered
        adapter.notifyDataSetChanged()
        status.text = "${filtered.size} de ${all.size} canais"
    }

    // ---------- Lista com logótipos ----------
    private val logoCache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    inner class ChannelAdapter : BaseAdapter() {
        var items: List<Channel> = emptyList()
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: layoutInflater.inflate(R.layout.item_channel, parent, false)
            val ch = items[p]
            v.findViewById<TextView>(R.id.name).text = ch.name
            v.findViewById<TextView>(R.id.group).text = ch.group
            val img = v.findViewById<ImageView>(R.id.logo)
            img.tag = ch.logo
            img.setImageBitmap(ch.logo?.let { logoCache.get(it) })
            val logo = ch.logo
            if (logo != null && logoCache.get(logo) == null) lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    try {
                        val c = URL(logo).openConnection().apply { connectTimeout = 8000; readTimeout = 8000 }
                        c.getInputStream().use { BitmapFactory.decodeStream(it) }
                            ?.let { Bitmap.createScaledBitmap(it, 96, (96f * it.height / it.width).toInt().coerceAtLeast(1), true) }
                    } catch (e: Exception) { null }
                }
                if (bmp != null) { logoCache.put(logo, bmp); if (img.tag == logo) img.setImageBitmap(bmp) }
            }
            return v
        }
    }
}
