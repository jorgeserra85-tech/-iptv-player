package pt.iptv.player

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var urlInput: EditText
    private lateinit var searchInput: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var groupSpinner: Spinner
    private lateinit var adapter: ChannelAdapter

    private var all: List<Channel> = emptyList()
    private var currentGroup = ALL
    private val prefs by lazy { getSharedPreferences("iptv", MODE_PRIVATE) }
    private val cacheFile by lazy { File(filesDir, "last.m3u") }

    companion object {
        const val ALL = "Todos os grupos"
        const val PICK_FILE = 42
        var playlist: List<Channel> = emptyList()   // partilhada com o leitor
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        urlInput = findViewById(R.id.urlInput)
        searchInput = findViewById(R.id.searchInput)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        groupSpinner = findViewById(R.id.groupSpinner)
        val list = findViewById<ListView>(R.id.channelList)

        adapter = ChannelAdapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val visible = adapter.items
            playlist = visible
            startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", pos))
        }

        urlInput.setText(prefs.getString("url", ""))
        findViewById<Button>(R.id.loadBtn).setOnClickListener { loadFromUrl() }
        urlInput.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO || ev?.keyCode == KeyEvent.KEYCODE_ENTER) { loadFromUrl(); true } else false
        }
        findViewById<Button>(R.id.fileBtn).setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            try { startActivityForResult(i, PICK_FILE) } catch (e: Exception) { toast("Sem gestor de ficheiros") }
        }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = applyFilter()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        groupSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                currentGroup = p?.getItemAtPosition(pos) as? String ?: ALL; applyFilter()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // abre a última lista guardada
        if (cacheFile.exists()) lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { cacheFile.readText() }
            setPlaylist(M3uParser.parse(text), save = null)
        }
    }

    private fun loadFromUrl() {
        val url = urlInput.text.toString().trim()
        if (url.isEmpty()) { toast("Escreve o URL da lista"); return }
        prefs.edit().putString("url", url).apply()
        load { download(url) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri: Uri = data?.data ?: return
        if (requestCode == PICK_FILE && resultCode == RESULT_OK) load {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Não foi possível ler o ficheiro")
        }
    }

    private fun load(fetch: () -> String) {
        progress.visibility = View.VISIBLE
        status.text = "A carregar…"
        lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) { fetch() }
                val channels = withContext(Dispatchers.Default) { M3uParser.parse(text) }
                if (channels.isEmpty()) error("A lista não tem canais (é mesmo um M3U?)")
                setPlaylist(channels, save = text)
            } catch (e: Exception) {
                status.text = "Erro: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    private fun download(url: String): String {
        var target = url
        repeat(5) {   // segue redirecionamentos (incluindo http <-> https)
            val c = URL(target).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 30000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "IPTVPlayer/1.0 (Android)")
            val code = c.responseCode
            if (code in 300..399) { target = URL(URL(target), c.getHeaderField("Location")).toString(); c.disconnect(); return@repeat }
            if (code !in 200..299) error("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        }
        error("Demasiados redirecionamentos")
    }

    private suspend fun setPlaylist(channels: List<Channel>, save: String?) {
        all = channels
        if (save != null) withContext(Dispatchers.IO) { cacheFile.writeText(save) }
        val groups = listOf(ALL) + channels.map { it.group }.distinct()
        groupSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups)
        currentGroup = ALL
        applyFilter()
    }

    private fun applyFilter() {
        val q = searchInput.text.toString().trim()
        val filtered = all.filter {
            (currentGroup == ALL || it.group == currentGroup) && (q.isEmpty() || it.name.contains(q, ignoreCase = true))
        }
        adapter.items = filtered
        adapter.notifyDataSetChanged()
        status.text = if (all.isEmpty()) "Cola o URL da tua lista ou abre um ficheiro .m3u"
                      else "${filtered.size} de ${all.size} canais"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- Lista com logótipos ----------
    private val logoCache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    inner class ChannelAdapter : BaseAdapter() {
        var items: List<Channel> = emptyList()
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: layoutInflater.inflate(R.layout.item_channel, parent, false)
            val ch = items[p]
            v.findViewById<TextView>(R.id.name).text = ch.name
            v.findViewById<TextView>(R.id.group).text = ch.group
            val img = v.findViewById<ImageView>(R.id.logo)
            img.tag = ch.logo
            img.setImageBitmap(ch.logo?.let { logoCache.get(it) })
            val logo = ch.logo
            if (logo != null && logoCache.get(logo) == null) lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    try {
                        val c = URL(logo).openConnection().apply { connectTimeout = 8000; readTimeout = 8000 }
                        val opts = BitmapFactory.Options().apply { inSampleSize = 1 }
                        c.getInputStream().use { BitmapFactory.decodeStream(it, null, opts) }
                            ?.let { Bitmap.createScaledBitmap(it, 96, (96f * it.height / it.width).toInt().coerceAtLeast(1), true) }
                    } catch (e: Exception) { null }
                }
                if (bmp != null) { logoCache.put(logo, bmp); if (img.tag == logo) img.setImageBitmap(bmp) }
            }
            return v
        }
    }
}
