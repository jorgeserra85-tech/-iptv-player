package pt.iptv.player

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var searchInput: EditText
    private lateinit var status: TextView
    private lateinit var groupList: ListView
    private lateinit var adapter: ChannelAdapter

    private var all: List<Channel> = emptyList()
    private var groups: List<String> = emptyList()
    private var currentGroup = ALL

    companion object {
        const val ALL = "Todos"
        var channelsToShow: List<Channel> = emptyList()   // vem do login
        var playlist: List<Channel> = emptyList()         // partilhada com o leitor
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        all = channelsToShow
        if (all.isEmpty()) { finish(); return }          // ex.: app reaberta pelo sistema
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.title).text = intent.getStringExtra("title") ?: getString(R.string.app_name)
        findViewById<TextView>(R.id.sub).text = intent.getStringExtra("sub") ?: ""
        findViewById<Button>(R.id.backBtn).setOnClickListener { finish() }
        searchInput = findViewById(R.id.searchInput)
        status = findViewById(R.id.status)
        groupList = findViewById(R.id.groupList)
        val list = findViewById<ListView>(R.id.channelList)

        // ----- Grupos (coluna da esquerda) -----
        val counts = all.groupingBy { it.group }.eachCount()
        groups = listOf(ALL) + all.map { it.group }.distinct()
        val labels = groups.map { g -> if (g == ALL) "$ALL (${all.size})" else "$g (${counts[g] ?: 0})" }
        groupList.adapter = ArrayAdapter(this, R.layout.item_group, R.id.groupName, labels)
        groupList.setItemChecked(0, true)
        groupList.setOnItemClickListener { _, _, pos, _ ->
            currentGroup = groups[pos]
            groupList.setItemChecked(pos, true)
            applyFilter()
            list.setSelection(0)
        }

        // ----- Canais (coluna da direita) -----
        adapter = ChannelAdapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            playlist = adapter.items
            startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", pos))
        }
        // No comando da TV: manter OK carregado abre o guia
        list.setOnItemLongClickListener { _, _, pos, _ -> openGuide(adapter.items, pos); true }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = applyFilter()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        applyFilter()
    }

    private fun openGuide(items: List<Channel>, pos: Int) {
        val ch = items[pos]
        if (ch.streamId == null) { Toast.makeText(this, "Este canal não tem guia", Toast.LENGTH_SHORT).show(); return }
        playlist = items
        EpgActivity.channel = ch
        EpgActivity.channelIndex = pos
        startActivity(Intent(this, EpgActivity::class.java))
    }

    private fun applyFilter() {
        val q = searchInput.text.toString().trim()
        val filtered = all.filter {
            (currentGroup == ALL || it.group == currentGroup) && (q.isEmpty() || it.name.contains(q, ignoreCase = true))
        }
        adapter.items = filtered
        adapter.notifyDataSetChanged()
        status.text = "${filtered.size} canais" + if (currentGroup != ALL) " · $currentGroup" else ""
    }

    // ---------- Lista com logótipos ----------
    private val logoCache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    inner class ChannelAdapter : BaseAdapter() {
        var items: List<Channel> = emptyList()
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
            val v = convert ?: layoutInflater.inflate(R.layout.item_channel, parent, false)
            val ch = items[p]
            v.findViewById<TextView>(R.id.name).text = ch.name
            v.findViewById<View>(R.id.rec).visibility = if (ch.archive) View.VISIBLE else View.GONE
            val guide = v.findViewById<View>(R.id.guideBtn)
            guide.visibility = if (ch.streamId != null) View.VISIBLE else View.GONE
            guide.setOnClickListener { openGuide(items, p) }
            val img = v.findViewById<ImageView>(R.id.logo)
            img.tag = ch.logo
            img.setImageBitmap(ch.logo?.let { logoCache.get(it) })
            val logo = ch.logo
            if (logo != null && logoCache.get(logo) == null) lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    try {
                        val c = URL(logo).openConnection().apply { connectTimeout = 8000; readTimeout = 8000 }
                        c.getInputStream().use { BitmapFactory.decodeStream(it) }
                            ?.let { Bitmap.createScaledBitmap(it, 88, (88f * it.height / it.width).toInt().coerceAtLeast(1), true) }
                    } catch (e: Exception) { null }
                }
                if (bmp != null) { logoCache.put(logo, bmp); if (img.tag == logo) img.setImageBitmap(bmp) }
            }
            return v
        }
    }
}
