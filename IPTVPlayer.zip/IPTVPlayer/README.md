# IPTV Player (M3U)

App Android simples para listas IPTV M3U/M3U8.

- Carrega lista por URL ou ficheiro local; guarda a última lista
- Filtro por grupo (group-title) e pesquisa por nome
- Logótipos (tvg-logo), suporte a #EXTVLCOPT user-agent/referrer
- Leitor ExoPlayer (HLS, DASH, MPEG-TS, MP4), ecrã inteiro
- Funciona em Android TV / Fire TV (comando: ▲▼ ou CH+/CH- muda de canal)
- Android 5.0+

## Obter o APK sem instalar nada (GitHub Actions)
1. Cria um repositório novo em github.com
2. "Add file" → "Upload files" → arrasta todo o conteúdo desta pasta (incluindo a pasta .github)
3. Separador **Actions** → espera ~5 min que o "Build APK" fique verde
4. Abre a execução → em **Artifacts** descarrega `IPTVPlayer-apk` (zip com o .apk)

## Compilar no PC
Android Studio → Open → esta pasta → Build → Build APK(s).
Ou: `./gradlew assembleRelease` → `app/build/outputs/apk/release/`.
